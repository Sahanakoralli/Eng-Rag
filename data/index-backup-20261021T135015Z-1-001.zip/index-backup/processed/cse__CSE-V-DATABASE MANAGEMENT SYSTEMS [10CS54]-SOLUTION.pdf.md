## s n o i t u l o S r e p a P n o i t s e u Q

## UN T I -I

## ) 1 m r e t g n i w o l l o f e h t e n i f e D s:

y l u J / n u J ( s k r a M 0 2 1 0 2 3)

## ) i b a t a D a e s

: s n A A a d t e s a b a s i a co n o i t c e l l f o d e t a l e r dat , a e h w re a d ta me s n a r c e o d e d r f c a t . s e t u p m o C r-. a t a d r o f s e i r o t i s o p e r d e s a b I l l a c i g o l s i t y . d e h c a t t a s i g n i n a e m e m o s h c i h w o t a t a d t n e r e h o c

## : n o i t c a s n a r t d e n n a C ) i i

: s n A e s e h T e r a e h t n a r t s s n o i t c a t a h t e r a a c r l u f e ly g o r p r d e m m a d n a t e t s e d in a v d a n . e c x E k n a b s t i s o p e d / s l a w a r d h t i w t s o p s e c n a l a b t n u o c c a k c e h c , r e l l e t .

## d o m a t a D ) i i i e : l

: s n A t I s i a n o i t c e l l o c f o s t p e c n o c t a h t n a c e b d e s u o t e b i r c s e d e h t l a c i g o l / s t p e c n o c e r u t c u r t s f o a r a s s e c e n e h t s e d i v o r p h c i h w e s a b a t a d y . n o i t c a r t s b a r i e h t e v e i h c a o t s n a e m

## ) v i a t a d a t e M :

: s n A t I s i e h t a t a d t u o b a a t a d h c i h w s i d e r o t s n i y s s m e t c l a t a og h w ich o c nta n i s e d s r c t p i n o i f o t e h e r u t c u r t s f o h c a e e l i f e h t t e p y d n a e h t e g a r o t s t a m r o f f o h c a e i f le d n a t e h r a v i u o s n o c t s a r i s t n on d e h t ata.

## i s e d e s a b a t a D ) v g e n r:

: s n A h T ey r a te e l b i s n o p s e r r o f i t n e d i f i y ng e h t a d ta o t e b o t s r d e d n a r o f ch g n i s o o n a p a p o r priat e way r o o t g t i e z i n a . e h T y e t a c t n e r e f f i d r o f s w e i v e n i f e d o s l a g . s r e s u f o s e i r o

## 2) a l p x E i p a e s a b a t a d f o s c i t s i r e t c a r a h c e h t n r p h c a o .

## s k r a M 4 / n u J ( y l u J 2 ) 5 1 0 2 y l u J / e n u J / 4 1 0

1. f l e S - g n i b i r c s e D e r u t a N f o a b a t a D a e s Sy t s em - t i s a h a o c m e t e l p n i f e d t i i n o r o n o i t p i r c s e d f o e h t a t a d b e s a u t c u r t s re d n a t s n o c raint . s s i h T n o i t i n i f e d s i d e r o t s in e h t m e t s y s g o l a t a c , h c i h w s n i a t n o c n o i t a m r o f n i c u s h s a e h t r t s u e r u t c of e c a h i f l , e e h t t e p y d n a e g a r o t s t a m r o f f o h c a e a t a d , m e t i d n a s u o i r a v a r t s n o c t n i s n o e h t a d ta. i h T s n o i t a m r o f n i d e r o t s n i e h t s m e t s y l a t a c og s i c , d e l l a M t e a- a d ta d n a it s e b i r c s e d t e h e r u t c u r t s f o e h t a m i r p ry . e s a b a t a d s i h T s w o l l a e h t S M B D e r a w t f o s o t work i w h t di t n e r e f f ( s e s a b a t a d Fig ) 1 . 1
2. n o i t a l u s n I n e e w t e b a r g o r P ms d n a a t a D d n a a D a t Abstr c a tion - d e l l a C a r g o r p m- a d ta

<!-- page-break -->

c n e d n e p e d n i e. s w o l l A g n i g n a h c a t a d e g a r o t s s e r u t c u r t s d n a s n o i t a r e p o t u o h t i w g n i v a h to e g n a h c e h t S M B D ac e c ss g o r p r . s m a e h T e r u t c u r t s f o a t a d s e l i f s i d e r o t s n i t e h S M B D l e t a r a p e s g o l a t a c y s m a r g o r p s s e c c a e h t m o r f .

3. a t a D A a r t s b t c ion: A a t a d l e d o m s i d e s u o t e d i h e g a r o t s s l i a t e d d n a e r p sent t e h r e s u s wi h t w e i v l a u t p e c n o c a e s a b a t a d e h t f o .
4. t r o p p u S f o e l p i t l u M i V e s w of h t e D t a a - h c a E s r e s u may e e s a f i d f r e ent vi w e of e h t l n o s e b i r c s e d h c i h w , e s a b a t a d y t t s e r e t n i f o a t a d e h t r e s u t a h t o . i f ( g 4 . 1 )
5. g n i r a h S f o a t a D and t l u M i-u e s r n o i t c a s n a r T s e c o r P s g n i - e h t DBMS u m t s i c n l e d u n o c c c n e r r u y c l o r t n o i t l u m f o t l u s e r e h t t a h t e r u s n e o t e r a w t f o s - t c e r r o c s i s s e c c a r e s u .

## 3) o t a r t s i n i m d a e s a b a t a d a f o s e i t i l i b i s n o p s e r e h t e r a t a h W . s r

## y l u J / n u J , 4 1 0 2 n a J / c e D ( s k r a M 4 2 ) 3 1 0

: s n A A a t a D e s a b r o t a r t s i n i m d a r e v o s s e e d n a n a m a s e g h t e a t a d a b se s s y te . m e i t u D s e d u l c n i s r e s u g n i z i r o h t u a e h t s s e c c a o t e s a b a t a d o c o g n i r o t i n o m / g n i t a n i d r s t i , e s u a u q c ir n i g H/ W d n a / S w r o f . e d a r g p u A B D t s u m e v a h g n i t r o p p u s st . f f a e h T A B D s i e l b i s n o p s e r r o f m e l b o r p s h c u s s a s r o o p r o y t i r u c e s f o h c a e r b y . e m i t e s n o p s e r m e t s

## 4) a r g a i d t a e n a h t i w S M B D a f o s t n e n o p m o c l a c i p y t e h t n i a l p x E m.

## n a J / c e D ( s k r a M 8 0 2 4 1 0 2 n a J / c e D , 3 1 5 1 0 2 n a J / 4 1 0 2 c e D , )

## l u d o M t n e n o p m o C S M B D es

- A r e h g i h - l e v e l d e r o t s d a t a r e g a n a m e l u d o m of e h t S M B D s l o r t n o c ac s s e c o t B D MS d n o d e r o t s s i t a h t n o i t a m r o f n i i k s .
- e h T L D D i p m o c r e l r p o s e s s e c a m e h c s de , s n o i t i n i f d e i f i c e p s n i e h t DD , L d n a s e r o t s a t e m ( s a m e h c s e h t f o s n o i t p i r c s e d - o l a t a c S M B D e h t n i ) a t a d g .
- e h T n u r - e m i t a t a d b e s a r o s s e c o r p h s e l d n a a t a d b e s a s e s s e c c a t a n u r m i t . e e h T e u q r y h g i h s e l d n a h r e l i p m o c - r a t a h t s e i r e u q l e v e l . y l e v i t c a r e t n i d e r e t n e e
- e r p e h T - c a r t x e r e l i p m o c t D s ML s d n a m m o c o r f m n a i l p p a c n o i t a r p ogram i r w t t en n i a o h st g n i m m a r g o r p u g n a l ag . e e s e h T s d n a m m o c e r a e s nt o t e h t DML r e l i p m o c r o f c m o t a l i p i n o c c a e s a b a t a d r o f e d o c t c e j b o o t n i e s s

<!-- page-break -->



## 5 r e t g n i w o l l o f e h t n i a l p x e d n a e n i f e D ) m a x e n a h t i w s m . h c a e r o f e l p

## s k r a M 8 ( n a J / c e D 0 2 y l u J / n u J , 3 1 2 4 1 0 )

- i) a n S p : t o h s e h T a t a d n i e h t a b a t a d se t a a u c i t r a p l r a t n e m o m in m i t e is l a c l d e t a d a abase e t a t s or s o h s p a n t. A e s a b a t a d e t a t s a ( l o s a c l d e l c n a t s n i es) s e g n a h c r e v e y , d e t r e s n i s i a t a d e m i t d e i f i d o m r o , d e t e l e d
2. i i ) e t n I n o i s n: e h T n o i t c n i t s i d e e w t e b n a t a d b e s a s h c e a m d n a d s a b a t a e e t a t s s i t t a h n e h w e w e n i f e d a w e n , e s a b a t a d we i c e p s fy e h t e s a b a t a d c s h a m e n o ly to s i a m e h c s e h T S M B D e h t e h t d e l l a c s e m i t e m o s n o i s n e t n i .
3. i i i ) t x E e : n o i s n n e h w t a h t s i e t a t s e s a b a t a d d n a a m e h c s e s a b a t a d n e e w t e b n o i t c n i t s i d e h T e w e n i f e d a w e n , e s a b a t a d we i c e p s fy e h t e s a b a t a d c s h a m e n o ly to S M B D e h t e h t ( cu t n e r r e t a t s f o e h t a t a d b e s a s i t e h y t p m e e t a t s h t i w o n a d t ) a . e h T e s a b a t a d c s i e t a t s a l l e n a d x e e t n o i s n e h t f o h c s e a m

## 6 s i t a h W ) m a r g o r p r o f e g a r o t s t n e t s i s r e p " y b t n a e m " s t c e j b o . E i a l p x n .

4 s k r a M n a J / c e D ( 0 2 3 1 )

v o r P g n i d i t n e t s i s r e P e g a r o t S r o f r P ogr m a e j b O c s t d n a a t a D s e r u t c u r t S - s t c e j b o su v r i e v t e h n o i t a n i m r e t f o r p o m a r g ex n o i t u c e d n a n a c r e t a l e b e i r t e r v d e e h T p t s i s r e e t n st e g a r o f o r p o a r g ms s e s a b a t a d f o n o i t c n u f t n a t r o p m i n a s i s e r u t c u r t s a t a d d n a s t c e j b o y s m e t s .

## ) 7 l f i e r B y a t n a v d a e h t s s u c s i d g n i s u f o s e g D e h t B S M

s k r a M 8 / c e D ( 4 1 0 2 n a J )

<!-- page-break -->

1. g n i l l o r t n o C : y c n a d n u d e R a t a D n u d e r d n a cy h c u s ( s a s d n e t o t c c o ur n i h t e i f " le

i s s e c o r p n " g r p p a o ) h c a l s d a e o t d e t s a w g a r o t s e sp e c a , n o i t a c i l p u d f o f e f t r o n e h w ( e l p i t l u m s e i p o c f o a m u t a d d e e n o t e b , ) d e t a d p u d n a a r e h g i h d o o h i l k i l f o e h t n i tr u d o c i t n o f o n e t s i s n o c n i cy n O . e h t r e h t o , d n a h a d n u d e r ncy n a c e b us d e o t e v o r p m i a m r o f r e p n e c of u q r e ie . s e d n I x , s e r o f ex , e l p m a e r a e r i t n e ly r u d e n , t n a d t u b p l e h e h t B D MS n i g n i s s e c o r p l k c i u q e r o m s e i r e u q y .

r e h t o n A e l p m a x e of i s u ng a d n u d e r ncy o t o r p m i ve f r e p o n a m r ce s i o t o t s re n a e " x a r t " field n i r e d r o o t d i o v a e h t e e n d o t s s e c c a r e h t o s e l b a t ( s a n e h w g n i o d a JO , N I r o f ex m a l p . ) e See i F g a p ( 6 . 1 e r u g e h t : ) 8 1 e m a N t n e d u t S e d n a r u o C s e b m u N e r i f e e n s d l e h t e b t o n d ere .

A S M B D d l u o h s e d i v o r p e h t i l i b a p a c ty o t au l a c i t a m o t ly f n e orce h t e e l u r t a h t o n s e i c n e t s i s n o c n i e r a d e c u d o r t n i n e h w d a t a is u d p . d e t a g i F ( u e r 6 . 1 a , n i a g n i i h w ch m a n \_ t n e d u t S e o d e m t o n s atc h r e b m u n \_ t n e d u t S .)

2. Restr g n i t c i i r o h t u a n U e z d : s s e c c A A B D MS l u o h s d pr e d i v o a e s cur y t i d n a n o i t a z i r o h t u a m e t s y s b u s , c i h w h s i d e s u o f r s i c e p f i y ng e r t s t c i r n o i s on u e s r ac t n u o c s. n o m m o C s d n i k f o s n o i t c i r t s e r e r a o t w o l l a r d a e -only a s s e c c o n ( i t a d p u n ) g , r o ac e c ss n o l y o t a t e s b u s f o e h t a t a d e ( . , . g re l l a c e h t s r u B a ' r s d n a a r t s i g e R r s ' of e c i f ex s e l p m a m o r f a v o b ) e .
3. g n i d i v o r P t n e t s i s r e P St e g a r o f r o r g o r P am b O j s t c e : t c e j b O - e t n e i r o d a d t e s a b a s s y tems e k a m t i r e i s a e r o f m o c p e l x e m i t n u r s t c e j b o g . e ( ., , s t s i l ) s e e r t o t e b s v a ed n i a d n o c e s r y e m i t r e t a l a t a e l b a v e i r t e r e b o t d n a n o i t a n i m r e t m a r g o r p d n o y e b e v i v r u s o t s a o s e g a r o t s .
4. g n i d i v o r P e g a r o t S s e r u t c u r t S f r o E f f t n e i c i y r e u Q s e c o r P n i s : g e h T D S M B ma t n i ai s n e d n i x s e (t l a c i p y ly n i e h t m r o f f o s e e r t r o / d n a s a h h ) s e l b a t t a h t are t u l i iz d e o t i p m e v o r e h t ex n o i t u c e e m i t f o qu r e i s e n a d e t a d p u s. e h T ( e c i o h c f o c i h w h e d n i x s e to cr a e te d n a n i a t n i a m is p r a t f o l a c i s y h p e s a b a t a d n g i s e d d n a g n i n u t e e s ( r e t p a h C ) 6 1 d n a s i e h t t i l i b i s n o p s e r y A B D e h t f o .
4. e h T y r e u q g n i s s e c o r p and o i t a z i m i t p o n e l u d o m s i e l b i s n o p s e r r o f s o o h c i g n n a e f f ici t n e r e u q y r e u q h c a e r o f n a l p n o i t u c e x e y s e h t o t d e t t i m b u s y . m e t s h C e e S ( a t p r e ) . 5 1
5. g n i d i v o r P p u k c a B d n a o c e R ve : y r e h T b u s s m e t s y g n i v a h s i h t i l i b i s n o p s e r ty en u s r s e t a h t e v o c e r ry s i e l b i s s o p n i e h t e s a c f o a s m e t s y a r c h s g n i r u d ex n o i t u c e of n o e r o m e r o s n a r t c a s n o i t .
6. g n i d i v o r P e l p i t l u M Us r e t n I erf : s e c a r o F , e l p m a x e e u q ry a l ngu e g a s f r o s a c u l a r e s u s,

<!-- page-break -->

g n i m m a r g o r p lan e g a u g i s e c a f r e t n r o f o i t a c i l p p a n , s r e m m a r g o r p fo s m r an r o / d o c m d n a m u n e m , s r e s u c i r t e m a r a p r o f s e d o c - v i r d s e c a f r e t n i n e f d n a t s r o -a n o l e s r e s u .

7. g n i t n e s e r p e R Co x e l p m s p i h s n o i t a l e R n o m A g : a t a D A S M B D h s o d l u e v a h the t i l i b a p a c y l k c i u q a t a d d e t a l e r e v e i r t e r o t d n a s p i h s n o i t a l e r h c u s t n e s e r p e r o t y.
8. y t i r g e t n I g n i c r o f n E : s t n i a r t s n o C t s o M s n o i t a c i l p p a e s a b a t a d a e r h c u s t a h t e h t e s m n a t s c i s i t a s t i t a h t e r i u q e r a t a d e h t f o ) g n i n a e m , . e . i ( fy ce n i s n o i t c i r t s e r n i a t r o e d r r n e s e k a m o t se . s p a h r e P e h t t s o m n u f d l a t n e m a t n i a r t s n o c n o a d a t a m e t i s i t i s a d ta t , e p y h c i h w p s f i c e i s e

e h t e s r e v i n u f o v s e u l a m o r f h c i h w s t i u l a v e may be . n w a r d E ( . , . g a d a r G e d l e i f d l u o c e b d e n i f e d o t e b of t p y e r G a p y T \_ e d e , h c i h w , sa e w , y e v a h i f e d n d e as l c n i i d u ng preci e s ly t e h A " { t e s e h t n i s e u l a v " A " , -" " , B+" , . . . " , " F }.

- r e h t o n A a r t s n o c f o d n i k i t n s i y t i r g e t n i l a i t n e r e f e r s h c i h w , a s y th t a f i e h t e s a b a t a d c n i l s e d u n a i t n e ty th t a e r f s r e o t r e h t o n a , e n o the r e t t a l i t n e ty t s u m ex t s i n i t e h a d tab . e s a r o F ex , e l p m a if 7 4 5 6 5 R ( , ) 2 0 1 L I C s i a t e l p u in t e h I \_ d e l l o r n E n , n o i t a l e r g n i t a c i d n i a h t t a t n e d u t s h t i w D I 4 5 6 5 R 7 s i g n i k a t a e s r u o c h t i w D I 2 0 1 L I C , e r e h t t s u m e b a e l p u t n i e h t n e d u t S t n i d n o p s e r r o c n o i t a l e r g t a h t h t i w t n e d u t s a o t I . D
9. g n i t t i m r e P g n i c n e r e f n I n a d o i t c A ns Via R l u : s e n I a c u d e d t v i e a t a d base s s y t , m e e n o y a m sp i c e fy v i t a r a l c e d e s e l u r t a h t w o l l a e h t e s a b a t a d o t r e f n i n w e a d t ! a , . g . E Fi e r u g t u o h c i h w s t n e d u t s e r a on a c a de i m c pr b o a i t . n o h c u S s e i t i l i b a p a c d l u o w take e h t l p a e c o f e s i w r e h t o n o i t a m r o f n i h c u s n i a t r e c s a o t d e s u e b d l u o w t a h t s m a r g o r p n o i t a c i l p p a .

A t c v i e e s a b a t a d s r e h t r u f p e t s e n o o g s m e t s y b g n i w o l l a y e l u r e v i t c a " s t a h t " a c n b e s u e d o t l l a c i t a m o t u a s n o i t c a e t a i t i n i y.

## 8 ) s s u c s i D e h t n i a m s c i t s i r e t c a r a h C f o e h t e s a b a t a d r p p a o . h c a How do s e it f i d f r e r f om s e l i f l a n o i t i d a r T y ? s m e t s ` s k r a M 8 / n u J ( , 3 1 0 2 y l u J y l u J / n u J 2 4 1 0 )

## e r a h c a o r p p A e s a b a t a D e h t f o s c i t s i r e t c a r a h C

e S f l - g n i b i r c s e D e r u t a N f o a Dat e s a b a S s y tem - t i s a h a e t e l p m o c d t i n i f e n o i r o e d s r c t p i n o i f o th e e r u t c u r t s e s a b a t a d d n a co i a r t s n n . s t n o i t i n i f e d s i h T s i d e r o t s n i e h t s s y tem c l a t a og, h c i h w s n i a t n o c n o i t a m r o f n i h c u s s a e h t e r u t c u r t s f o e h c a , e l i f e h t t e p y d n a o t s r e g a fo t a m r f o h c a e d a t a , m e t i d n a s u o i r a v s t n i a r t s n o c n o e h t a t a d . s i h T n o i t a m r o f n i d e r o t s n i e h t s m e t s y a c t g o l a s i , d e l l a c e M taa d ta d n a t i s e b i r c s e d h t e c u r t s t e r u f o e h t r p m i ary a d t . e s a b a s i h T s w o l l a e h t S M B D f o s twa e r to s a b a t a d t n e r e f f i d h t i w k r o w i F ( s e g ) 1 . 1

<!-- page-break -->

n o i t a l u s n I n e e w t e b a r g o r P ms d n a a t a D d n a D t a a A s b t c a r t n o i - d e l l a C a r g o r p m- a d ta c n e d n e p e d n i e. s w o l l A i g n a h c ng a t a d e g a r o t s s e r u t c u r t s d n a s n o i t a r e p o t u o h t i w g n i v a h o t e g n a h c e h t S M B D s s e c c a r p o r g ams. e h T e r u t c u r t s f o a t a d s e l i f s i d e r o t s n i e h t M B D S g o l a t a c separatel y g o r p s s e c c a e h t m o r f r . s m a

a t a D b A t s t c a r n o i : A a t a d l e d o m s i d e s u o t e d i h e g a r o t s deta s l i d n a pr t n e s e h t e us s r e wi h t a w e i v l a u t p e c n o c e s a b a t a d e h t f o .

t r o p p u S f o e l p i t l u M s w e i V f o the D t a a - h c a E s r e s u y a m e e s a f i d f t n e r e i v w e f o e h t , e s a b a t a d l n o s e b i r c s e d h c i h w y r e s u t a h t o t t s e r e t n i f o a t a d e h t . i f ( g ) 4 . 1

g n i r a h S f o a t a D d n a i t l u M s u r e n o i t c a s n a r T g n i s s e c o r P - e h t S M B D s u m t c n i l e d u n o c c r r u e y c n c l o r t n o r e s u i t l u m f o t l u s e r e h t t a h t e r u s n e o t e r a w t f o s a c c e r r o c s i s s c e t .

## 9 ) h p d n a l a c i g o L n e e w t e b e c n e r e f f i d e h t n i a l p x E y ? e c n e d n e p e d n I a t a d l a c i s

## s k r a M 8 ( / n u J ) 3 1 0 2 y l u J

e n O t n a t r o p m i c i t s i r e t c a r a h c f o e h t a d t e s a b a h c a o r p p a s a w e h t l u s n i t a n o i f o p a r g o r s m d n a h C e e s ( a t a d a t p r e 1) . t o w t e n i f e d n a c e W y : e c n e d n e p e d n i a t a d f o s e p

l a c i g o l a t a d e d n e p e d n i n e c - the a c p i c a ty o t ch e g n a e h t o c n l a u t p e c c s heme u o h t i w t h v a n i g to o r p n o i t a c i l p p a r o s a m e h c s l a n r e t x e e g n a h c g . s m a r

l a c i s y h P a t a d e c n e d n e p e d n i - e h t i c a p a c ty o t e g n a h c e h t l a n r e t n i c s he e m i w h t u o t h v a n i g to e g n a h c e h t l a u t p e c n o c r o ( ex ) l a n r e t . s a m e h c s s e g n a h C o t e h t l a n r e t n i a m e h c s may be d e d e e n p e m o s e s u a c e b h . d e z i n a g r o e r e b o t d a h s e l i f l a c i s y

- o w T f o n o i t a r e p O e h t n i a l p x E ) c - D R r o f e r u t c e t i h c r a r e v r e S / t n e i l C r e i T BMS ?



a m m a r g o r p t n e i l c A y . s S M B D l a r e v e s o t t c e n n o c

e h t O r v n e i l c f o s n o i t a i r a t e : e l b i s s o p e r a s . . g , s n i o e r o m , s S M B D e m t c n u f i i l a n o t t s i y r f s n a e e r r d o t s t n e i l c g n i d u l c n i a d ta di a n o i t c ry , s n o i t c n u f t p o i i m z n o i t a d n a e v o c e r ry a s s o r c e l p i t l u m , s r e v r e s etc. a m r e v r e s e h t s n o i t a u t i s h c u s n I y e h t d e l l a c e b e S a t a D r r e v

<!-- page-break -->

- . 0 1 e e r h t e h t n i a l p x E - d n a e c n e d n e p e d n i a t a d l a c i g o l e h t s i t a h W . e r u t c e t i h c r a a m e h c s s k r a m 8 ? e c n e d n e p e d n i a t a d l a c i s y h p ) 5 1 0 2 y l u J / e n u J (



e n O t n a t r o p m i c i t s i r e t c a r a h c f o e h t a d ta e s a b h c a o r p p a s a w e h t l u s n i t a n o i f o p a r g o r s m d n a h C e e s ( a t a d a t p r e 1) . t o w t e n i f e d n a c e W y : e c n e d n e p e d n i a t a d f o s e p

l a c i g o l a t a d e d n e p e d n i n e c - the a c p i c a ty o t ch e g n a e h t o c n l a u t p e c c s heme u o h t i w t h v a n i g to o r p n o i t a c i l p p a r o s a m e h c s l a n r e t x e e g n a h c g . s m a r

l a c i s y h P a t a d e c n e d n e p e d n i - e h t i c a p a c ty o t e g n a h c e h t l a n r e t n i c s he e m i w h t u o t h v a n i g to e g n a h c e h t l a u t p e c n o c r o ( ex ) l a n r e t . s a m e h c s s e g n a h C o t e h t l a n r e t n i a m e h c s may be d e d e e n p e m o s e s u a c e b h . d e z i n a g r o e r e b o t d a h s e l i f l a c i s y

<!-- page-break -->

## ) 1 1 e s a b a t a d e h t e n i f e D ? e s a b a t a d e h t f o s e i t r e p o r p t i c i l p m i e h t n i a l p x e y l f e i r b d n a

## ) 5 1 0 2 y l u J / e n u J ( s k r a M 4

b d e t s i l e r a e s a b a t a d a f o s e i t r e p o r p t i c i l p m i n i a m e h T : w o l e

- d e l l a c s e m i t e m o s , d l r o w l a e r e h t f o t c e p s a e m o s s t n e s e r p e r e s a b a t a d A . 1 f o e s r e v i n u r o d l r o w i n i m e h t d l r o w i n i m e h t o t s e g n a h C . ) D o U ( e s r u o c s i d . e s a b a t a d e h t n i d e t c e l f e r e r a
- t n e r e h n i e m o s h t i w a t a d f o n o i t c e l l o c t n e r e h o c y l l a c i g o l a s i e s a b a t a d A . 2 . g n i n a e m
- c i f i c e p s a r o f a t a d h t i w d e t a l u p o p d n a , t l i u b , d e n g i s e d s i e s a b a t a d A . 3 . e s o p r u p

## 1 ) 2 e n i f e D ) 5 1 n a J / 4 1 c e D ( s k r a m 0 1 : s e l p m a x e h t i w g n i w o l l o f e h t

- t e s e u l a V ) i s e u l a v f o t e s f o s t s i s n o c t i
- s e t u b i r t t a x e l p m o C ) i i o v n i t a h t e t u b i r t t a n a o t r e f e r e W s s e v l i t l u m f o n o i t a n i b m o c e m o - d e u l a v n a d c t i s o p m o ene a s a s s x e l p m o c t t a r . e t u b i
- l e d o m a t a D ) i i i a n o i t c e l l o c f o n o c c s t p e t a h t n a c e b d e s u o t d e b i r c s e e h t l / l a u t p e c n o c o c i g a e s a b a t a d a f o e r u t c u r t s l - - - r a s s e c e n e h t s e d i v o r p y s i h t e v e i h c a o t s n a e m o i t c a r t s b a n
- s t c u r t s n o c a m e h c S ) v i h c i h w s i d e i f i c e p s g n i r u d s e d i n g d n a s i t o n ex d e t c e p o t e g n a h c e t f o n .
- a t e M ) v a t a d , . e . i ( a t a d t u o b a ) a t a d s i st d e r o n i t e h so- a c l l d e m e t s y s a c talog,

<!-- page-break -->

## T I N U - I I

## y t i t n E - l e d o M p i h s n o i t a l e R

- . 1 t s i L e h t su r a m m y f o e h t n s n o i t a t o for ER di r g a a . s m e d u l c n I s l o b m y s u e s d n i ER r i e h t d n a m a r g a i d e m a g n i n . s k r a M 8 ( y l u J / n u J 2 4 1 0 )
- 2 ) h t i W R E o t t c e p s e r m a x e h t i w n i a l p x e l e d o m . e l p s k r a M 4 n a J / c e D ( 0 2 3 1 )
- i) g n o r t S y t i t n e : r a l u g e R i t n e ty t s e p y t a h t o d e v a h a key e t u b i r t t a are s e m i t e m o s d e l l a c p y t y t i t n e g n o r t s e . s
- ) i i k a e W y t i t n e : y t i t n e t s e p y t a h t o d t o n e v a h y e k s e t u b i r t t a f o r i e h t n w o e r a c d e l l a k a e w e s e p y t y t i t n
- ) i i i n o i t a p i c i t r a P : s t n i a r t s n o c t I sp i c e e i f s r e h t e h w t e h ex e c n e t s i of an i t n e ty s d n e p e d n o s t i g n i e b e r l d e t a o t o n a t r e h i t n e ty a i v e h t r p i h s n o i t a l e typ . e s i h T t s n o c r t n i a c e p s ifi e h t s e m u m i n i m r e b m u n f o p i h s n o i t a l e r s e c n a t s n i t a h t h c a e i t n e ty n a c pa i c i t r p e t a n i m i n i m e h t d e l l a c s e m i t e m o s s i d n a t i l a n i d r a c m u y . t n i a r t s n o c



<!-- page-break -->

- v i ) y t i l a n i d r a C t a r i : o e h T i l a n i d r a c ty r o i t a o f r a a n i b ry r p i h s n o i t a l e c e p s ifies the t i t n e n a t a h t s e c n a t s n i p i h s n o i t a l e r f o r e b m u n m u m i x a m y n i e t a p i c i t r a p n a c .
- v) g n i r r u c e R s n o i t a l e r h : s p i n I e m o s s e s a c e h t a s me i t n e ty type p i c i t r a p e t a s e r o m n a h t e c n o n i a p i h s n o i t a l e r t e p y in di e f f r n e t e l o r . s n I h c u s s e s a c e h t e l o r a n me s e m o c e b h c a e f o g n i n a e m e h t g n i h s i u g n i t s i d r o f l a i t n e s s e n o i t a p i c i t r a p . h c u S t p i h s n o i t a l e r y s e p t a l e r e v i s r u c e r d e l l a c e r a i p i h s n o

## : e t u b i r t A c i m o t A

p m i S . e t u b i r t t a c i m o t a r o e l p m i s d e l l a c e r a e l b i s i v i d t o n e r a t a h t e t u b i r t t A . e l

. e t u b i r t t a e t i s o p m o c f o n o i s i v i d e h t . e . i . r e b m u n \_ r o o D r o e m a n \_ t e e r t S , e l p m a x e r o F

## e p y T p i h s n o i t a l e R e v i s r u c e R

e p y t y t i t n e g n i t a p i c i t r a p e m a s e h t h t i w e s o h w e p y t p i h s n o i t a l e r n A : e l p m a x E s e l o r t c n i t s i d n i : s e l o r t c n i t s i d o w t n i e c i w t s e t a p i c i t r a p E E Y O L P M E p i h s n o i t a l e r N O I S I V R E P U S e h t n I e l o r ) s s o b r o ( r o s i v r e p u s

E E Y O L P M E t c n i t s i d o w t s e t a l e r e c n a t s n i p i h s n o i t a l e r h c a E e l o r ) e t a n i d r o b u s r o ( e e s i v r e p u s : s e i t i t n e

n i e e y o l p m e e n O e l o r e e s i v r e p u s n i e e y o l p m e e n O e l o r r o s i v r e p u s

## s e p y T y t i t n E k a e W

g n i y f i t n e d i n a n i e t a p i c i t r a p t s u m y t i t n e k a e w A . e t u b i r t t a y e k a e v a h t o n s e o d t a h t y t i t n e n A e h t y b d e i f i t n e d i e r a s e i t i t n E . e p y t y t i t n e g n i y f i t n e d i r o r e n w o n a h t i w e p y t p i h s n o i t a l e r m o c o t d e t a l e r e r a y e h t y t i t n e r a l u c i t r a p e h T e p y t y t i t n e k a e w e h t f o y e k l a i t r a p A : f o n o i t a n i b . e p y t y t i t n e g n i y f i t n e d i e h t n i

## . 3 n i a l p x E e o h e l o r s e m a n e r a d e n g i s s a n i e s a c of e v i s r u c e r r t a l e i n o s i h ? s p l I lu e t a r t s t i h s a x e n a h t i w t p e c n o c m l p e. . s k r a M 8 ( / n u J ) 3 1 0 2 y l u J

A p i h s n o i t a l e r n a c e r l e t a o w t s e i t i t n e f o e h t s e m a i t n e ty type ; o f r ex , e l p m a a SUPERVIS N O I

p i h s n o i t a l e r t s e t a l e r e p y M E e n o P E E Y O L n i ( e h t e l o r f o u s p e s i v r e e ) o t an r e h t o EMP E E Y O L (in e h t o r e l f o r o s i v r e p u s ) . t p i h s n o i t a l e r e v i s r u c e r a d e l l a c s i s i h T y e p s k r a M 4 y l u J / n u J ( 2 ) 4 1 0

<!-- page-break -->

4 n i a l p x E ? y e k l a i t r a p y b t n a e m s i t a h W ) .



A k a e w i t n e ty type mu t s e t a p i c i t r a p n i an g n i y f i t n e d i i t a l e r n o s p i h y t pe wi h t an r e n w o r o g n i y f i t n e d i e p y t y t i t n e

d e i f i t n e d i e r a s e i t i t n E b : f o n o i t a n i b m o c e h t y

t y t i t n e k a e w e h t f o y e k l a i t r a p A y e p

i t n e g n i y f i t n e d i e h t n i o t d e t a l e r e r a y e h t y t i t n e r a l u c i t r a p e h T t e p y t y

A k a e w i t n e ty t e p y l a u s u ly s a h a l a i t r a p y e k , h c i h w s i e h t t e s f o t a tri e t u b s t a h t c n a e u q i n u l y i t n e d i fy we k a s e i t i t n e a h t t e r a d e t a l e r o t e h t e m a s ow r e n t n e t i . y r o F , e l p m a x e e m a N f o

e k l a i t r a p e h t s i T N E D N E P E D y

- . 5 e n i f e D n a i t n e ty d n a n a e , e t u b i r t t a x n i a l p e h t n e r e f f i d t typ s e f o t a tri t u b es t a h t c c o ur n i an e n a h t i w , l e d o m m a r g a i d R E x e l p m a ) 4 1 0 2 n a J / c e D , 3 1 0 2 n a J / c e D ( s k r a M 8

d n o c e s e h t n o s i w o n s u c o f r u O h p ase , a u t p e c n o c l n g i s e d o f , r h T h c i h w e E y t i t n - i h s n o i t a l e R p

R E ( ) M d o el h g i h r a l u p o p a s i - e l v a d l a u t p e c n o c l e t . l e d o m a

I a s t p e c n o c n i a m e h t , l e d o m R E e h t n e r n e t y t i , at e t u b i r t , d n a p i h s n o i t a l e r .

r t t A d n a s e i t i t n E ibu s e t

i t n E ty t i t n e n A : y f o s i t a h t ) d l r o w i n i m e h t n i ( " g n i h t " e m o s s t n e s e r p e r , . e . i , s u o t t s e r e t n i t u o b a m o s n i a t n i a m o t t n a w e w h c i h w e t a d a . t i t n e n A y h p a t n e s e r p e r d l u o c y , . g . e ( t c e j b o l a c i s

<!-- page-break -->

, e s u o h a , n o s r e p n a p m o c , . g . e ( t p e c n o c e l b i g n a t s s e l a r o ) t e g d i w , e l i b o m o t u y c i m e d a c a , b o j , ) e s r u o c .

t t A r u b i e t d e b i r c s e d s i y t i t n e n A : b t i g n i z i r e t c a r a h c s e i t r e p o r p e r a h c i h w , s e t u b i r t t a s t i y . h c a E a t u b i r t t e s a h a e u l a v f n w a r d r e m o s m o n i a m o d n i n a e m f o t e s ( g u l a v l u f e . ) s

A : e l p m a x E O S R E P N t i t n e y b d e b i r c s e d e b t h g i m y m a N e , t a D h t r i B e , e S x , s e t u b i r t t a , . c t e , h c a e n i v a h g v r a l u c i t r a p a a u l e.

t i t n e n a s e h s i u g n i t s i d t a h W y r e t t a l e h t t a h t s i e t u b i r t t a n a m o r f f o e s o p r u p e h t r o f y l t c i r t s s i n i b i r c s e d g n a n i , t o n s i d n a r e m r o f e h t e t n i f o , f l e s t i f o d r . s u o t t s e I n a t a h t d i a s s e m i t e m o s s i t t i t n e y . t o n s e o d e t u b i r t t a n a s a e r e h w , e c n e t s i x e t n e d n e p e d n i n a s a h I n i m r o f r e p n g a t a d n i l e d o m g , e b o t s e v r e s e d t p e c n o c r a l u c i t r a p a r e h t e h w r a e l c s y a w l a t o n s i t i , r e v e w o h t i t n e n a s a d e i f i s s a l c y l n o " r o y e t u b i r t t a n a s a " .

: s n o i s n e m i d e s e h t g n o l a s e t u b i r t t a y f i s s a l c n a c e W

- s v c i m o t a / e l p m i s . c t i s o p m o e
- n i s g e l -va u l e s v d . i t l u m - o ( d e u l a v r set-) d e u l a v
- r o t s e s v d . de d e v i r ( r o t c u r t s n i m o r f e t o N : l i a t e d l a n o i t a t n e m e l p m i n a e k i l s m e e s s i h t u o t a h t g i h ( s i h t t a d e r e d i s n o c e b t o n t h g . n o i t c a r t s b a f o l e v e l ) h )

A o c m t i s o p e i t a h t e n o s i e t u b i r t t a s o c m s o p ed e l l a m s f o r s t r a p . n A o t a m c i s i e t u b i r t t a i d n i b i s i v l e r o . e l b a s o p m o c e d n i

- a x E m l p e 1 : A t a D h t r i B e n i e b s a d e w e i v e b n a c e t u b i r t t a g b u s ( f o d e s o p m o c -) a t t r s e t u b i a d , h t n o m r o f y d n a , y . r a e
- a x E m l p e 2 : A n r d d A e s s n i e b s a d e w e i v e b n a c ) 4 6 e g a p , 4 . 3 e r u g i F ( e t u b i r t t a g d e s o p m o c b u s ( f o - t i c , s s e r d d a t e e r t s r o f s e t u b i r t t a ) y e d o c p i z d n a , e t a t s , . n a c s s e r d d a t e e r t s A s t i e f l n i e b s a d e w e i v e b g b m u n a f o d e s o p m o c r e b m u n t n e m t r a p a d n a , e m a n t e e r t s , r e . s A s i h t g u s g r e h s a ( o w t f o h t p e d a o t d n e t x e n a c n o i t i s o p m o c , s t s e ) e r o m r o e . e h t e b i r c s e d o T e t u b i r t t a e t i s o p m o c a f o e r u t c u r t s , n o i t n e m e r o f a e h t n i s a ( e e r t a w a r d n a c e n o e d Fig . ) 4 . 3 e r u s u o t d e t i m i l e r a e w e s a c n I r a m o t s u c s i t i , t x e t g n i y b d e w o l l o f e m a n s t i e t i r w o t y a b u s s t i f o t s i l d e z i s e h t n e r a p - s e t u b i r t t a . e h t r o F e w , e v o b a d e n o i t n e m s e l p m a x e w d l u o w r e t i

<!-- formula-not-decoded -->

p i Z , e t a t S , y t i C , ) m u N t p A , e m a N r t S , m u N r t S ( r d d A t e e r t S ( s s e r d d A )

e l g n i S - s v . mu i t l - d e u l a v d i s n o C : e t u b i r t t a r e a N O S R E P t i t n e y . s a h s t n e s e r p e r t i n o s r e p e h T n o ( e) S S N , ( n o ) e h t r i b f o e t a d u o h t l a , e n o ( , g ) e t i s o p m o c h m a n e , etc. a m n o s r e p t a h t t u B y e v a h r o o r e z n i v i l e l a m a s i n o s r e p e h t f i ( r o , s t n e d n e p e d , s e e r g e d c i m e d a c a e r o m g h a t U n i ) s u o p s e w o H ! s a c n i v s i h t l e d o m e w a s e t u b i r t t a r g e D c i m e d a c A e e s , d n e p e D e s t n , d n a e s u o p S s ? w e n O a w o l l a o t s i y t u b i r t t a h c u s e b o t s e i t l u m - e u l a v d ( h r e p a s p t e s - a v l d e u , ) m r e t r e t t e b a s i e w t a h t y a s o t s i h c i h w l b i s s o p ( a m e h t o t n g i s s a y t p m e y ) s t e s e u l a v f o n i s a n a h t r e h t a r g e l e u l a v . i t l u m a h s i u g n i t s i d o T - e l g n i s a m o r f e t u b i r t t a d e u l a v - r a m o t s u c s i t i , e n o d e u l a v y o t e h t e s o l c n e e u l a v a s a h e t u b i r t t a n a h c u s s a , e s n e s s e k a m h c i h w ( s e c a r b y l r u c n i h t i w r e m r o f d n a , t e s a s i t a h t l r u c y l l a n o i t i d a r t e r a s e c a r b y . ) s t e s e t o n e d o t d e s u U n i s g e h t N O S R E P m o r f e l p m a x e a v o b e e w , r u t c u r t s s t i t c i p e d d l u o w e e t n i x a t s N O S R E P ( r a e Y , y a D , h t n o M ( e t a D h t r i B , e m a N , N S S ) s e e r g e D c i m e d a c A { , ( , l e v e L , l o o h c S r a e Y ) , }

<!-- page-break -->

## { De d n e p e . . . , } s t n )

a h t e m u s s a o t y t r e b i l e h t n e k a t e v a h e w e r e H , l o o h c s a y b d e b i r c s e d s i e e r g e d c i m e d a c a h c a e t d n a , ) . D . h P , . S . B , . g . e ( l e v e l y . r a e , s u h T D c i m e d a c A e e r g es l n o t o n s i y i t l u m - o s l a t u b d e u l a v t i s o p m o c e . i t l u m f o n o i t a n i b m o c e m o s s e v l o v n i t a h t e t u b i r t t a n a o t r e f e r e W - s s e n d e u l a v n a d c t i s o p m o ene a s a s s m o c x e l p t t a r . e t u b i

e t u b i r t t a x e l p m o c a f o e l p m a x e d e t a c i l p m o c e r o m A i s r d d A e n o h P s s e i F n i g 5 6 e g a p ( 5 . 3 e r u ). e r a t a d g n i d r o c e r r o f s i e t u b i r t t a s i h T g n i d r a g s s e n i s u b a f o s r e b m u n e n o h p d n a s e s s e r d d a . e h T o t s s e n i s u b e h t r o f s w o l l a e t u b i r t t a s i h t f o e r u t c u r t s b d e b i r c s e d h c a e , s e c i f f o l a r e v e s e v a h y n a n i r t a h t s r e b m u n e n o h p f o t e s a d n a s s e r d d a g o t a h t o t n i f f i e c . I b n e v i g s i e r u t c u r t s s t y

e n o h P s s e r d d A { ( e n o h P { ( r e b m u N , e d o C a e r A ) s s e r d d A , } ( r d d A r t S ( , e m a N r t S , m u N r t S , ) m u N t p A

) p i Z , e t a t S , y t i C ) }

St r o e s v d . d r e i d e v P : e t u b i r t t a r e ha s p p e d n i e t n e d n a d n i r e d v l b a e o f s m r e t r e t t e b e b d l u o w r e s e h t r o ( n o n -re t n a d n u d a d n re t n a d n u d ). I n a n y a , e s a c i r e d ved e u l a v e s o h w e n o s i e t u b i r t t a ca b n e e n e c n e h d n a , s e t u b i r t t a r e h t o f o s e u l a v e h t m o r f d e t a l u c l a c e b t o n d e r o t s e . d a x E m e l p : g A e c n a c e b alc f d e t a l u r m o t r i B h e t a D c a s i e t a d t n e r r u c e h t t a h t g n i m u s s a , c . e l b i s s e l l u N e h T l a v ue : I t i t n e r a l u c i t r a p a s e s a c e m o s n y a r o f e u l a v e l b a c i l p p a n a e v a h t o n t h g i m r a l u c i t r a p t u b i r t t a e . m e u l a v t a h t r O a n k n u e b y o n w . l u m a f o e s a c e h t n i , r O i t - t t a d e u l a v r e h t , e t u b i t p m e e h t e b t h g i m e u l a v e t a i r p o r p p a y . t e s

a x E m l p e e t u b i r t t a e h T : t a D e D f O e h t a n i v i l a o t e l b a c i l p p a t o n s i g e u l a v t c e r r o c s t i d n a n o s r e p a m y . d e i d e v a h o h w s n o s r e p e m o s r o f n w o n k n u e b

I e u l a v e t u b i r t t a l a i c e p s a e s u e w , s e s a c h c u s n n o n ( - d e l l a c , ) ? e u l a v u n ll . Th e r e b s a h e e m o s n e t c n i t s i d g n i v a h s a h c u s ( h c a o r p p a t n e r e f f i d a r e h t e h w t u o b a e r u t a r e t i l e s a b a t a d e h t n i t n e m u g r a va u l e o f s r l b a c i l p p a t o n e d n a w o n k n u n b d l u o w ) e r o i r e p u s

<!-- page-break -->

## D . 6 e l p m a x e n a h t i w g n i w o l l o f e h t e n i f e . n u J ( s k r a M 0 2 y l u J / 3 1 0 2 ) 5 0 1 2 y l u J / e n u J &amp;

e p y T y t i t n E k a e W s t i t n e n A : y f i l a u q t a h t s e t u b i r t t a f o t e s o n s a h t a h t e p y t y e k a s a y d e l l a c s i a e w k . s e n O ( t a h t o d e r a g n o r t s .) . t i t n e n A y l e u q i n u s i e p y t y t i t n e d i k a e w a f o y y b d e i f i t n e d i e r s i t i h c i h w o t y t i t n e c i f i c e p s e h t d e t a l b ( y o s a - d e l l a c h s n o i t a l e r g n i y f i t n e d i p i s e t a l e r t a h t t i t n e k a e w e h t y ty o s s t i h t i w e p - d e l l a c i t n e d i f g n i y or n w o r e n e t e p y t y t i h t i w n o i t a n i b m o c n i ) t u b i r t t a n w o s t i f o t e s e m o s e c ( s a a d e l l l a i t r a p y e k . )

a x E m l p e: A D N E P E D N E T t i t n e y y b d e i f i t n e d i s i e h t h t i w r e h t e g o t e m a n t s r i f s t i E E Y O L P M E t i t n e y a i v d e t a l e r s i t i h c i h w o t O \_ S D N E P E D N . n d l u o w s i h t t a h t e t o N ( ' o f k r o w t r f r e m r o v a e h y e h t s a , s n o s s ' n a m e r o F e g r o e G n o i p m a h c g n i x o b t h g i e w y ) ! " e g r o e G " e m a n e h t e v a h l l a t y t i t n e k a e w a f o y t i t n e n a e s u a c e B y t t a h t , e s i w r e h t o d e i f i t n e d i e b t o n n a c e p y a s a h e p t l a t o n i a r t s n o c n o i t a p i c i t r a p t ( . i e , . n e d n e p e d e c n e t s i x e cy f i t n e d i e h t o t t c e p s e r h t i w ) y g n i l e r a . p i h s n o i t

t i t n e y n a t a h t n a e m o t n e k a t e b t o n d l u o h s s i h T y t n i a r t s n o c n o i t a p i c i t r a p l a t o t a h c i h w n o e p y t x e k a e w s i s t s i . p s e r h t i w t n i a r t s n o c n o i t a p i c i t r a p l a t o t a s a h T N E M T R A P E D , e l p m a x e r o F c e t o t E G A N A M S w t o n s i t i t u b , a e . k

t y t i t n e k a e w a , m a r g a i d R E n a n I y g n i y f i t n e d i n a d n a e l g n a t c e r e l b u o d a h t i w d e t c i p e d s i e p e l b u o d a h t i w d e t c i p e d s i e p y t p i h s n o i t a l e r o m a i d n d

## n o i t a p i c i t r a P ) i i c t n i a r t s n o

- a p i c i t r a p t n o i : s e i f i c e p s r e h t e h w r o t o n e h t ex e c n e t s i f o n a i t n e ty d s d n e p e n o p u t i s t i t n e r e h t o n a o t d e t a l e r g n i e b y p i h s n o i t a l e r e h t a i v .

l a t o t n o i t a p i c i t r a p (or e c n e t s i x e e p e d d n en ) y c : o T say th t a i t n e ty t p y e A s i c i a r t s n o n d e to e t a p i c i t r a p y l l a t o t n i a l e r t n o i i h s p R s i o t y a s t a h t f i t a ( e m o s t n e m o m n i m i t ) e R's t s n i anc s i t e s e

<!-- formula-not-decoded -->

n e h t t a ( th t a a s me o m m n e t) A s ' n a t s n i ce s t e m s u t be { a1, a2, . . ., am }. n I r e h t o , s d r o w e r e h t a c n e b no r e b m e m f o A s ' a t s n i n e c t e s t a h t s e o d t o n c i t r a p ipate n i t a t s a e l t s n i e n o anc o e f R. g n i d r o c c A o t r u o f n i o l a m r n o i t p i r c s e d f o C , Y N A P M O e v e ry l p m e oyee s u m t o t d e n g i s s a e b e m o s e d p r a t e v e , s i t a h T . t n e m ry l p m e o e c n a t s n i e e y t s u m t r a p i e t a p i c n i t a t s a e l e n o i e c n a t s n of W O F \_ S K R O R, h c i h w s i o t y a s a h t t O L P M E Y E E s e i f s i t a s e h t l a t o t h t o t t c e p s e r h t i w t n i a r t s n o c n o i t a p i c i t r a p e WO O F \_ S K R R rela p i h s n o i t . In n a R E , m a r g a i d f i i t n e ty t e p y A t s u m p e t a p i c i t r a l a t o t ly n i r a l e t p i h s n o i t e p y R, a y b d e t c e n n o c e r a o w t e h t o d e n i l e l b u .

<!-- page-break -->

l a i t r a p i t a p i c i t r a p n o : e h t e c n e s b a f o e h t l a t o t n o i t a p i c i t r a p ! t n i a r t s n o c , . g . E ( t o n e v e ry e e y o l p m e s a h o t p e t a p i c i t r a n i S E G A N A M ; e c n e h e w say , t a h t h t i w e r sp t c e to E G A N A M S, E Y O L P M E E s e t a p i c i t r a p l a i t r a p l . y T s i h s i t o n o t y a s th t a r o f l l a l p m e s e e y o o t e b g a n a m e s r s i t o n ; d e w o l l a t i n o ly s y a s t a h t t i d e e n o n t e b t e h e s a c l l a t a h t o l p m e y . s r e g a n a m e r a s e e

- i) t i l a n i d r a C y o i t a r

s t p e c n o c d l r o w i n i m e h t f o l e d o m e t a r u c c a n a e b e p y t p i h s n o i t a l e r a e k a m o t r e d r o n i , n e t f O t i t a h t t n e s e r p e r o t d e d n e t n i s i r t s n o c n i a t r e c e s o p m i e w , a i s s o p e h t t i m i l t a h t s t n i b e l n i d n o p s e r r o c g l e r a s p i h s n o i t e s t . a m t n i a r t s n o c a , s i t a h T ( y e k a m d i l a v n i " " f o t e s r a l u c i t r a p a a r o f s e c n a t s n i t p i h s n o i t a l e r y ) . e p

r a n i b n o ( s t n i a r t s n o c p i h s n o i t a l e r f o s d n i k n i a m o w t e r a e r e h T y a l e r ) s p i h s n o i t . F r t s u l l i r o a , n o i t t e l R t y t i t n e f o s e c n a t s n i f o s r i a p d e r e d r o f o g n i t s i s n o c t e s p i h s n o i t a l e r a e b y s e p A d n a B, l e v i t c e p s e r y.

Car y t i l a n i d rat o i : e n o ( 1 : 1 -to- n o ) e f o e c n a t s n i o n , t n i a r t s n o c s i h t r e d n U : A n i e t a p c i t r a p y a m e r o m t s n i e n o n a h t a c n e f o R l r a l i m i s ; y f o s e c n a t s n i r o f B. I i , s d r o w r e h t o n f a ( 1 b , 1) d n a (a2 b , 2) o s e c n a t s n i ) t c n i t s i d ( e r a f R e h t i e n n e h t , r a1 a = 2 o n r b1 = b2.

a x E m l p e e v e t a h t s y a s Y N A P M O C f o n o i t p i r c s e d l a m r o f n i r u O : r e n o s a h t n e m t r a p e d y o l p m e y a n a m o h w e e g . t i s e l a e w f I o l p m e n a t a h t e t a l u p i t s o s y a m e e y ) y l s u o e n a t l u m i s ( t o n e d e n o n a h t e r o m r o f r e g a n a m f o e l o r e h t y a l p p t a h t s w o l l o f t i , t n e m t r a E G A N A M S 1 : 1 s i .

e n o ( N : 1 -to-m ) y n a f o e c n a t s n i o n , t n i a r t s n o c s i h t r e d n U : B ma t a p i c i t r a p y e n i e n o n a h t e r o m t s n i a o e c n f R n i t u b , n a t s e c o s f A h c u s o n r e d n u e r a i t c i r t s e r o . n In h t o e r w f i , s d r o (a1 b , 1) an d (a2 b , 2) c n a t s n i ) t c n i t s i d ( e r a e f o s R t i n e h t , c n a n e b t o h t e c s a e h t a t b1 = b2 .

a x E m l p e : L O R T N O C S a m t c e j o r p o n e s u a c e b N : 1 s i y b d e l l o r t n o c e b y n a h t e r o m n o e de m t r a p e t n . e h t n O a l o r t n o c y a m t n e m t r a p e d a , d n a h r e h t o n f o r e b m u n y s i e r e h t o s , s t c e j o r p i h w n i s e c n a t s n i p i h s n o i t a l e r f o r e b m u n e h t n o n o i t c i r t s e r o n ch t n e m t r a p e d r a l u c i t r a p a a m e c n a t s n i y . e t a p i c i t r a p For r a l i m i s r , s n o s a e i N : 1 o s l a s . ( 1 : N m y n a - o t - n o e) h t t s u j s i s i h T : e o w t e h t f o s e l o r h t i w t u b N : 1 s a e m a s e t n ity ty . d e s r e v e r s e p

a x E m l p e : O F \_ S K R O W R d n a O \_ S D N E P E D N e r a . 1 : N

M: y n a m ( N - o t -m ) y n a r t s e r o n e r a e r e h t , t n i a r t s n o c s i h t r e d n U : i s n o i t c . ( n e H c , e m r e t e h t r t s n o c a f o e c n e s b a e h t o t s e i l p p a a ! t n i )

<!-- page-break -->

a x E m l p e : O \_ S K R O W N s i a m e e y o l p m e n a e s u a c e b , N : M y n a n o k r o w y f o r e b m u n s t c e j o r p n a e v a h y a m t c e j o r p a d n a y o l p m e f o r e b m u n y t i n o k r o w o h w s e e . n i n o i t a t o n e h t e c i t o N i l a n i d r a c s ' e p y t p i h s n o i t a l e r h c a e g n i t a c i d n i r o f 2 . 3 e r u g i F t o i t a r y . g n i n g i s e d n i , t a h t e s o p p u S , e s a b a t a d a a n i b a e d u l c n i o t e d i c e d e w r p i h s n o i t a l e r y R a s s e t a l e r h c i h w ( e v o b a d e b i r c s e d t i t n e y ty s e p A d n a B l e v i t c e p s e r , y) . w o h e n i m r e t e d o T R t c e p s e r h t i w , d e n i a r t s n o c e b d l u o h s t i l a n i d r a c o t y s n o i t s e u q e h t , o i t a r y e r a k s a d l u o h s u o

: e s e h t i t n e n e v i g a y a M t o y f t A e p y t f o s e i t i t n e e l p i t l u m o t d e t a l e r e b B e p y ?

i t n e n e v i g a y a M t ? B e p y t f o s e i t i t n e e l p i t l u m o t d e t a l e r e b A e p y t f o y

t i l a n i d r a c e l b i s s o p r u o f e h t o t n i s p a m t e g u o y s r e w s n a f o r i a p e h T y : s w o l l o f s a s o i t a r

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

## r a n r e T ) I V y p i h s n o i t a l e r

o s l A e t o n , t a h t n i r u o C Y N A P M O ex , e l p m a l l a p i h s n o i t a l e r i s n t s e c n a wi l l e b e d r o r d e a p ir , s s a h c a e p i h s n o i t a l e r s e t a i c o s s a n a e c n a t s n i m o r f e n o i t n e ty type h t i w n a e c n a t s n i f o h t o n a er r o ( h t e , e m a s n i e h t e s a c of E S I V R E P U S S) p i h s n o i t a l e r t . e p y h c u S s p i h s n o i t a l e r e r a d i a s o t be r a n i b y, o t r o e v a h e r g e d e . o w t e R l s p i h s n o i t a h t i w e e r g e d e e r h t ( d e l l a c r a n r e t y) or e r o m e r a o s l a pos i s , e l b h g u o h t l a o n t as c m m o . n o

Y L P P U S s p a h r e p ( t o n e h t t s e b e c i o h c r o f a m a n e) s a h s a s e c n a t s n i r e d r o ed t i r l p s e f o l p p u s i , s r e , s t r a p d n a , s t c e j o r p h t i w e h t t n e t n i g n i e b t a h t n o i s u l c n i f o e h t o e r e d r d tri e l p s ( 2, p4, j1), r o f i l p p u s t a h t s e t a c i d n i , e l p m a x e r e s2 i l p p u s e t r a p d p4 o t e j o r p ct j1).

## h s n o i t a l e r e v i s r u c e R ) V i p

n o i t p e c x e n A t i t n e e m a s e h t n e h w s r u c c o e l u r s i h t o t y e h t n i s e l o r ) e r o m r o ( o w t s y a l p e p y t l e r e m a s a p i h s n o i t . u S ( c h r b o t d i a s e r a s p i h s n o i t a l e e i s R U C e r ve h c i h w , I a e b o t d n i f n i d a e l s i m g h t f o e s u a m r e t t . i m m r e t r e t t e b A g b t h e f l e s - l a i t n e r e f e r c a e n i , e l p m a x e r o F ) . h o e c n a t s n i f a E S I V R E P U S S o l p m e e n o , t e s p i h s n o i t a l e r y a l p e e y f o e l o r e h t s u s p r o s i v r e d n a a l p r e h t o e h t y e h t s e l o r f o s i v r e p u s e e .

<!-- page-break -->

## ) 7 n g i s e D n a R E r g a i D am r o f e e k p g n i r t a k c f o n I f i t a m r o n o about Bank t a D b a , e s a Tak 4 t n u o c c a o t n i g n i e i t n tie ? s e D ( s k r a M 8 ) 3 1 0 2 n a J / c



## 8 ) e b i r c s e D o h w o t p a m e h t g n i w o l l o f s ' o i r a n e c S in ER o M del o t c s he , a m with s i u a t bl a x e e m : e l p ) 4 1 0 2 n a J / c e D ( s k r a M 8

## i) n E g n o r t S t y t i :-

- r o F h c a e r a l u g e r ) g n o r t s ( i t n e ty t e p y E n i e h t R E , a m e h c s cr e t a e a r n o i t a l e R t a h t t u b i r t t a e l p m i s e h t l l a s e d u l c n i es .
- s e t u b i r t t a e t i s o p m o c r o F n i , E t r e v n o c m e h t o t e l p m i s r t t a i s e t u b in R by g n i t r e v n o c c a e h o t t n e n o p m o c a n a t u b i r t t e .
- F i t l u m r o - 6 p e t s o t m e h t e v a e l , E n i s e t u b i r t t a e u l a v
- e k e h t f o e n o e s o o h C y t a r a m i r p e h t s a E f o s e t u b i r t y y e k r o f R
- f I e h t o h c s n e key f o E s i , e t i s o p m o c e h t t e s f o e l p m i s s e t u b i r t t a t a h t m r o f t i l l i w t e g o t e h r R f o y e k y r a m i r p e h t m r o f

## i i ) e n O - o t - R e n o e a l t p i h s n o i

- n ( o i t a r y t i l a n i d r a c 1 : 1 h t i w s e p y T n o i t a l e R y r a n i B f o g n i p p a M o n s i n o i t a l e r w e

<!-- page-break -->

) d e t a e r c - r o F h c a e a n i b ry 1 : 1 r a l e t p i h s n o i t e p y R n i e h t R E a m e h c s , t n e d i ify h t e r l e i t a s n o . R n i g n i t a p i c i t r a p s e p y t y t i t n e e h t o t d n o p s e r r o c t a h t T d n a S

- s e h c a o r p p a e l b i s s o p e e r h t e r a e r e h T :
- e K n g i e r o F y e h t f o e n o e s o o h C : h c a o r p p a s n o i t a l e r - a s y S - d n a e k n g i e r o f a e d u l c n i y r a m i r p e h t S n i y e k y . T f o I e t t e b s i t r o t
- t y t i t n e n a e s o o h c y . S f o e l o r e h t n i R n i n o i t a p i c i t r a p l a t o t h t i w e p
- I h t l l a S n i e d u l c n e R m o r f s e t u b i r t t a
- b d e p p a m s i S E G A N A M n o i t a l e r 1 : 1 : e l p m a x E y g n i s o o h c e h t
- e s u a c e b , S f o e l o r e h t n i e v r e s o t T N E M T R A P E D e p y t y t i t n e g n i t a p i c i t r a p
- l a t o t s i e p y t p i h s n o i t a l e r S E G A N A M e h t n i n o i t a p i c i t r a p s t i .

## 9 K l a i t r a P n i a l p x e d n a e n i f e D ) e e h t i w , y x ? e l p m a ) 3 1 0 2 y l u J / n u J , 4 1 0 2 n a J / c e D ( s k r a M 4

t r a P a s i e t u b i r t t a n A n o i t c n u j n o c n i d e s u e b t s u m e p y t y t i t n e d e t a l e r a m o r f y e K a f i y e K l a i . t e s y t i t n e g n i d n o p s e r r o c a f o s e c n a t s n i y f i t n e d i y l e u q i n u o t n o i t s e u q n i e t u b i r t t a e h t h t i w



## 0 1 b t n a e m s i t a h W ) y e l o r f o e c n a t r o p m i e h t t u o g n i r B ? p i h s n o i t a l e r e v i s r u c e r a n n i s e m , p i h s n o i t a l e r e v i s r u c e e l p m a x e n a h t i w ? ) 3 1 0 2 y l u J / n u J ( s k r a M 8

t i t n e e m a s e h t f o s e i t i t n e o w t e t a l e r n a c p i h s n o i t a l e r A y N O I S I V R E P U S a , e l p m a x e r o f ; e p y t t p i h s n o i t a l e r y P M E e n o s e t a l e r e p L r e h t o n a o t ) e e s i v r e p u s f o e l o r e h t n i ( E E Y O P M E L E E Y O n i ( e h t e l o r f o r o s i v r e p u s ) . t p i h s n o i t a l e r e v i s r u c e r a d e l l a c s i s i h T y . e p n a c e p y t p i h s n o i t a l e r A e u l a v s t i ; N O \_ S K R O W f o k e e W r e P s r u o H , e l p m a x e r o f ; s e t u b i r t t a e v a h p i h s n o i t a l e r h c a e r o f M E n a t a h t k e e w r e p s r u o h f o r e b m u n e h t s e b i r c s e d e c n a t s n i PL n o s k r o w E E Y O O R P a JECT. r a n i b a f o ( o i t a r y t i l a n i d r a C : s p i h s n o i t a l e r n o s t n i a r t s n o c l a r u t c u r t S y , N : 1 , 1 : 1 : ) p i h s n o i t a l e r . N : M r o , 1 : N y t i t n e g n i t a p i c i t r a p h c a e n o ( t n i a r t s n o c n o i t a p i c i t r a P t d e l l a c ( l a t o t : ) e p y ) y c n e d n e p e d e c n e t s i x e r o . l a i t r a p r u t c u r t s p i h s n o i t a l e r r o f n o i t a t o n ) x a m , n i m ( e v i t a n r e t l A a l c r t s n o a : s t n i h c a e n o d e i f i c e p S n o i t a p i c i t r a p y t i t n e n a f o t y t p i h s n o i t a l e r a n i E e p y p . R e E n i e y t i t n e h c a e t a h t s e i f i c e p S t a n i s e t a p i c i t r a p l t s a e t s o m t a d n a n i m a m x p i h s n o i t a l e r t s n i anc R n i s e . o n ( t l u a f e D x a m , 0 = n i m : ) t n i a r t s n o c = . n

<!-- page-break -->



<!-- page-break -->

- R E e h t w a r D ) 1 1 - . s e i t i t n e r u o f y n a e m u s s A . m u b l a r o f s m r o f r e p o h w n a i c i s u m f o m a r g a i d ? e d a m e r a t a h t s n o i t p m u s s a d n a s t n i a r t s n o c d n a y e k l l a e t a c i d n I ) 4 1 0 2 y l u J / n u J ( s k r a M 8



<!-- page-break -->

- . 2 1 e k i l s e p y t y t i t n e e l b a t i u s e m u s s A . y n a p m o c e c n a r u s n i n a r o f m a r g a i d R E n a n g i s e D . m e h t n e e w t e b n o i t a l e r e h t d n a T N E M Y A P , Y C I L O P , H C N A R B , T N E G A , R E M O T S U C y l u J / e n u J ( s k r a m 0 1 ) 5 1 0 2 ) 5 1 n a J / 4 1 c e D (



<!-- page-break -->

## e l p m a x e n a h t i w n i a l p x E ? s e p y t p i h s n o i t a l e r n o s t n i a r t s n o c l a r u t c u r t s e r a t a h W 3 1 ? ) 5 1 n a J / 4 1 c e D ( s k r a M 0 1

a p i c i t r a p t n o i : s e i f i c e p s r e h t e h w r o t o n e h t ex e c n e t s i f o n a i t n e ty d s d n e p e n o p u s t i g n i e b r e h t o n a o t d e t a l e r e t i t n y h t a i v e re p i h s n o i t a l .

t l a t o n o i t a p i c i t r a p r o ( e c n e t s i x e y c n e d n e p e d ): o T y a s th t a i t n e ty t e p y A s i d e n i a r t s n o c o t e t a p i c i t r a p y l l a t o t n i p i h s n o i t a l e r R s i o t y a s t a h t f i t a ( o s e m ) e m i t n i t n e m o m R' n a t s n i s ce s i t e s

<!-- formula-not-decoded -->

n e h t t a ( th t a e m a s o m m ) t n e As ' e c n a t s n i s t e t s u m e b { a1, a2, . . ., am }. n I r e h t o , s d r o w e r e h a c n e b o n r e b m e m f o A s ' a t s n i n e c t e s t a h t s e o d t o n i c i t r a p p e t a n i t a e l a e n o t s c n a t s n i e f o R. g n i d r o c c A o t r u o f n i o l a m r n o i t p i r c s e d f o , Y N A P M O C v e ery l p m e o e e y t s u m o t d e n g i s s a e b e m o s e d p r a t e v e , s i t a h T . t n e m ry m e plo t r a p t s u m e c n a t s n i e e y i e t a p i c t a n i t s a e l e n o s n i t e c n a f o \_ S K R O W F R O , h c i h w s i o t say t a h t O L P M E Y E E o t e h t s e i f s i t a s t l a t r a p i i c p n o i t a s n o c tra n i t h t i w t c e p s e r to e h t W S K R O \_F R O r p i h s n o i t a l e . n I n a ER , m a r g a i d f i i t n e ty type A t s u m e t a p i c i t r a p l a t o t ly n i p i h s n o i t a l e r t e p y R, b d e t c e n n o c e r a o w t e h t y a e n i l e l b u o d .

l a i t r a p o i t a p i c i t r a p n: e h t e c n e s b a f o e h t l a t o t t r a p i n o i t a p i c ! t n i a r t s n o c , . g . E ( t o n e v e ry l p m e oyee h s a o t pa e t a p i c i t r n i MAN G A ES; e h e c n we say th , t a h t i w res t c e p o t A M N S E G A , O L P M E Y E E s e t a p i c i t r a p l a i t r a p l . y s i h T s i t o n o t say th t a r o f l l a s e e y o l p m e o t e b s r e g a n a m s i t o n ; d e w o l l a t i n o ly s y a s t a h t t i d e e n not e b t e h e s a c o l p m e l l a t a h t y e r a s e e s r e g a n a m .

## 1 ) 4 i a l p x E ? e p y t y t i t n e k a e w e r a t a h W k a e w f o n g i s e d n i y e k l a i t r a p f o e l o r e h t n ? e p y t y t i t n e 5 ) 5 1 n a J / 4 1 c e D ( s k r a M

n A i t n e ty t e p y t a h t s a h o n t e s f o s e t u b i r t t a t a h t i l a u q fy s a a key s i a c l l e d k a e w . s e n O ( o d t a h t are g n o r t s .) y t i t n e d i k a e w a f o y t i t n e n A t e u q i n u s i e p y l d e i f i t n e d i y b h t y c i f i c e p s e i t n e ty to y b ( d e t a l e r s i t i h c i h w a o s - d e l l a c i y f i t n e d i ng o i t a l e r nship t a h t s e t a l e r e h t k a e w i t n e ty t e p y h t i w s t i so- d e l l a c n i y f i t n e d i g r o r e n w o y t i t n e p y t e) n i n o i t a n i b m o c h t i w e m o s t e s f o its o n w t a t s e t u b i r (c l a l d e a l a i t r a p key) .

a x E m e l p : A D N E P E D ENT i t n e ty is d e i f i t n e d i by s t i t s r i f e m a n to r e h t e g h t i w e h t O L P M E Y E E t n e ity o t h c i h w it s i d e t a l e r a i v DEPE S D N \_ON. e t o N ( t a h t s i h t t ' n d l u o w k r o w r o f m r o f e v a e h r yweig n i x o b t h g r o e G n o i p m a h c g e F n a m e r o ' s a , s n o s s

<!-- page-break -->

D

a

h

e

t y

i

d

d

t

e

e

o

ex



n

a

e

m t

m

a

u

t

p

b t

t

c

e

r

l

e

,

h

a

t any

P

A

e

R

n

t

i

t

M

T

k

y

t e

p

y on

T

E

w . n

d

D

n

o

E

i is t

n

a

l

g

e

n

e

a

a an

i

d

N

I n

n

e

t

a

s

h a

a R

i

f i

E

y n

g

r

d

l

e

i

w a o

t

h

o

i

t

c

h

l

a

p

m

a

s

a

a

t

g

i

r

n

o

h

,

i

p

a

t

t

r

a

t

i

t

a

i

c

w

p

y

l

p

p

a

t

a

i

k

a

i

e

e

s

r

t

o

i

n

n

c

i

p

a

o

c

t

t

n

i

s

on

t

r

a

i

c

n

o

t

n

s

t

i

r

t

a

i

h

n

t

e

r

p

e

e

s

c

x

p

i

e

d t d

d

w

e ty type s

d

p

e

i

i

c

t

e

d

w

i

t

h

i

a

o

u

## T I N U - I I I

## a r b e g l A l a n o i t a l e R d n a l e d o M l a n o i t a l e R

## 1 h c a e r o f e l p m a x e n a h t i w s m r e t g n i w o l l o f e h t e n i f e D ) . ) 4 1 0 2 y l u J / n u J ( s k r a M 8

u S p r e key: A t e s f o s e t u b i r t t a SK f o R h c u s t a h t o n two l p u t s e n i y n a d i l a v n o i t a l e r i r e c n a t s n ( ) R a s e h t e v a h l l i w me . K S r o f e u l a v n a r o f , s i t a h T y l p u t t c n i t s i d e s t1 t d n a 2 n i r(R), t s e l p u t t c n i t s i d o w t y n a r o f 1 t d n a 2 e t a t s n o i t a l e r a n i r of R e w v a h e f o t e s b u s e h t ( s e t u b i r t t a SK c s i a l l e d a p u s e k r ey a m e h c s n o i t a l e r e h t f o R).

i a m o D n: A i n u / t e s v e s r e f o c i m o t a , s e u l a v e r e h w by " c i m o t a " we n a e m p m i s ly t t a h m o r f b i s i v i d n i s i n i a m o d e h t n i e u l a v h c a e e s a b a t a d e h t f o w e i v f o t n i o p e h t l . e

Tuple: A e l p u t s i a i p p a m ng m o r f s e t u b i r t t a o t a v l s e u d w a r n o r f m t e h s e r p t c e i e v s n i a m o d s o h t f o e t t a r t i t n e e m o s e b i r c s e d o t d e d n e t n i s i e l p u t A . s e t u b i y . d l r o w i n i m e h t n i

s l l u N l b a c i l p p a t o n , w o n k t ' n o d s i e u l a v l l u n e h T : e

l a n o i t a l e R e s a b a t a d : a m e h c s t I s i a t e s f o s a m e h c s r o f s t i s n o i t a l e r tog h t e r e w t i h a t e s f o t i r g e t n i y . s t n i a r t s n o c

y t i t n E y t i r g e t n i t s n o c n i a r t: e h T i t n e ty t n i e i r g ty t n i a r t s n o c s e t a t s t a h t o n a m i r p ry ke y e u l a v n a c e b . l l u n s i h T s i e s u a c e b e h t a m i r p ry e k y e u l a v s i d e s u o t y f i t n e d i l a u d i v i d n i s e l p u t n i a : n o i t a l e r g n i v a h l u n l s e u l a v f r o e h t a m i r p ry ke s y s e i l p m i t a h t e w t o n n a c i e d i t n fy o s m e e l p u t s . t i t n e d n a s t n i a r t s n o c y e K y s n o i t a l e r l a u d i v i d n i n o d e i f i c e p s e r a s t n i a r t s n o c .

## 2 a l p x E ) i s m r e t g n i w o l l o f e h t n

## 4 1 0 2 n a J / c e D ( s k r a M 8

## )

n i a m o D a r t s n o c n i t: h c a E e t u b i r t t a t s u m e u l a v e b NU L L r o d w a r n o r f m e h t n i a m o d of t t a h t u b i r t t a e. e t o N t a h t o s me s " S M B D o l l a w u o y to e s o p m i t e h o n t u n l l c n o t s a r i t n n o p u n a

0

C

S

5

4

i

b

l

e

e

d

i

s

t

s

t

c

i

s

o

w

e

n

o

s

a

t e

b

e en e

t

t

k

a

.

k

c

n

e

o

F

r

M N S

t A

i

t

w a

m

o

h

n

d

.

A ,

d

G

o

u

E

b

l

e

a

1

<!-- page-break -->

a s o t s i h c i h w , e t u b i r t t a y a m e t u b i r t t a t a h t y e u l a v e h t e v a h t o n - . l l u n

c i t n a m e S t i r g e t n i y i a r t s n o c n : t e h T se e r a n o i t a c i l p p a f i c e p s ic re t s t c i r n o i s t a h t e r a l e k i l n u y D D n i e l b i s s e r p x e e b o t L.

l a n o i t c n u F n e p e d den y c t n i a r t s n o c : t I s i a n o c s t n i a r t w / b e h t o w t sets of a t t i r t u b s e m o r f r o w t ela . s n o i t

## 3) e n i f e D l a i t n e r e f e r y t i r g e t n i a r t s n o c n i . t n i a l p x E e h t e c n a t r o p m i f o l a i t n e r e f e r y t i r g e t n i s n o c r t t n i a . w o H s i t n i a r t s n o c s i h t e t n e m e l p m i d

## ) 3 1 0 2 y l u J / n u J ( s k r a M 8 ) 5 1 n a J / 4 1 c e D s k r a M 5 (

l a i t n e r e f e R i r g e t n i ty t n i a r t s n o c - e h T l a i t n e r e f e r i r g e t n i ty t s n o c r t n i a s i d e i f i c e p s n e e w t e b o w t s n o i t a l e r d n a s i d e s u o t n i a t n i a m e h t n e t s i s n o c cy g n o m a l p u t es f o e h t two t a l e r n o i . s A t e l p u n i t s u m n o i t a l e r r e h t o n a o t s r e f e r t a h t n o i t a l e r e n o r n i t s i x e n a o t r e f e g t a h t n i e l p u t n o i t a l e r . r o F , e l p m a x e e h t l a v ue f o e t u b i r t t a O N D n i e v e ry M E P E E Y O L t e l p u t s u m mat h c h t e

T N E M T R A P E D e h t n i e l p u t e m o s f o e u l a v R E B M U N D e r la . n o i t



<!-- page-break -->

## 4 : n i a l p x E )

## y l u J / n u J ( s k r a M 2 1 3 1 0 2 )

n i a m o D a r t s n o c n i t: h c a E e t u b i r t t a t s u m e u l a v e b NU L L r o d w a r n o r f m e h t n i a m o d of t t a h t u b i r t t a e. e t o N t a h t o s me s " S M B D o l l a w u o y to p m i o e s t e h o n t u n l l c n o t s a r i t n n o p u n a a s o t s i h c i h w , e t u b i r t t a y a m e t u b i r t t a t a h t y e u l a v e h t e v a h t o n - . l l u n

c i t n a m e S t i r g e t n i y i a r t s n o c n : t e h T se e r a n o i t a c i l p p a f i c e p s ic re t c i r t s n o i s t a h t e r a l e k i l n u y D D n i e l b i s s e r p x e e b o t L.

l a n o i t c n u F y c n e d n e p e d i a r t s n o c nt t I : s i a n o c s t n i a r t w / b e h t o w t sets of a t t i r t u b s e m o r f r o w t ela . s n o i t

## ) 5 x e n a h t i w , n o i t a l e r a f o s c i t s i r e t c a r a h c e h t s s u c s i D a e l p m ) 3 1 0 2 n a J / c e D ( s k r a M 4

s e l p u T f o g n i r e d r O : A n o i t a l e r s i a set t a i c o s s a r e d r o o n s i e r e h t , e c n e h ; s e l p u t f o e i w d t h h t e . m e k a m t i , s i t a h T n o i t a l e r a n i e l p u t h t 5 e h t , e l p m a x e r o f , o t r e f e r o t e s n e s o n s . n e h W a r l i r a s s e c e n e r a s e l p u t e h t , e l b a t a s a d e t c i p e d s i n o i t a l e y n i d e t s i l m o s e t u b , e s r u o c f o , r e d r o y d l u o h s u o i s o n h c a t t a g r e d r o t a h t o t e c n a c i f i n . l r a l i m i S y e t n e s e r p e r e r a s e l p u t n e h w , a n o d a r o t s g , e c i v e d e e h t y n i d e z i n a g r o e b t s u m m o s e a m t i d n a , n o i h s a f y a m o r f , s u o e g a t n a v d a e b a w a n i m e h t e z i n a g r o o t , t n i o p d n a t s e c n a m r o f r e p y . t n e t n o c r i e h t n o p u s d n e p e d t a h t

u b i r t t A f o g n i r e d r O e t s n i p p a m a s a d e w e i v t s e b s i e l p u t A : g b i r t t a s t i m o r f e h t , . e . i ( s e t u name b d e y a l p s e l o r e h t o t e v i g e w s y n i d n o p s e r r o c e h t o t ) e l p u t e h t g n i s i r p m o c s e u l a v e h t g s e u l a v . l e r r i s i e l b a t a n i d e t s i l e r a s e t u b i r t t a e h t h c i h w n i r e d r o e h t , e c n e H eva t n . , t a h t e t o N (

l e t a n u t r o f n u y l e r n i s n o i t a r e p o c i t e r o e h t t e s e h t , a e n i f e d N &amp; E w o h t s a e l t a ( a r b e g l a l a n o i t ) m e h t e h t f o r e d r o e h t f o e s u t i c i l p m i e k a m a t u b i r t t es . g n i e b s a s e t u b i r t t a w e i v N &amp; E , e c n e H n a r r a g ) . t e s a n a h t r e h t a r e c n e u q e s a s a d e

t t A f o s e u l a V r t u b i es n i e b o t n o i t a l e r a r o F : m r o F l a m r o N t s r i F r t t a s t i f o h c a e , m o d e t u b i a s n i i t l u m r o n e t i s o p m o c r e h t i e n ( c i m o t a f o t s i s n o c t s u m - u l a v e v ) d a u l es . y r o e h t e h t f o h c u M n o i t p m u s s a s i h t n o p u d e s a b s a w l e d o m l a n o i t a l e r e h t g n i y l r e d n u .

e h T l u N l s u : e u l a v e d f r o w o n k t ' n o d , b a c i l p p a t o n le .

o n o i t a t e r p r e t n I f n o i t a l e R a h c a E : b n a c n o i t a l e r e i v e a s a d e w t a c i d e r p e n i e l p u t h c a e d n a a h t t ( d e i f s i t a s s i e t a c i d e r p t a h t h c i h w r o f n o i t r e s s a n a s a d e w e i v e b n a c n o i t a l e r i e u l a v s a h , . e . r t ue) i n i s e u l a v f o n o i t a n i b m o c e h t r o f t . I f a s t n e s e r p e r e l p u t h c a e , s d r o w r e h t o n c a t . x E a e l p m e h T : n i v a h t n e d u t s a s t s i x e e r e h T : s n a e m d e t s i l e l p u t t s r i f g e m a n n i m a j n e B r e y a B , n i v a h g S S N 5 0 3 - 1 6 - 4 2 5 3 n i v a h , g ag . c t e , 9 1 e t n e s e r p e r s n o i t a l e r e m o s t a h t d n i m n i p e e K . e ( s e i t i t n e t u o b a s t c a f g s r e h t o s a e r e h w ) s t n e d u t s , . s p i h s n o i t a l e r t u o b a s t c a f t n e s e r p e r ( e w t e b e t i t n e n e i ) s . . e ( g e s e s r u o c d n a s t n e d u t s , . c ) s n o i t .

<!-- page-break -->

e h T o i t p m u s s a d l r o w d e s o l c n l n o e h t t a h t s e t a t s y e s o h t e r a d l r o w i n i m e h t t u o b a s t c a f e u r t b d e t n e s e r p e r y l t n e r r u c s e l p u t r e v e t a h w y e s a b a t a d e h t e t a l u p o p .

a t o N l e d o M l a n o i t a l e R t n o i : e g a p 2 5 1 A ( R 1 A , 2 , . . ., An) e e r g e d f o a m e h c s l a n o i t a l e r a s i n n i t o n e d g n o i t a l e r a s i e r e h t t a h t R n i v a h g s e t u b i r t t a s t i s a A1 A , 2 , . . . A , n.

- By , n o i t n e v n o c Q , R d n a , S m a n n o i t a l e r e t o n e d e . s
- By , n o i t n e v n o c q , r, d n a s l e r e t o n e d a t s n o i t ate , e l p m a x e r o F . s r( ) R s e t o n e d e n o e l b i s s o p f o e t a t s e r la n o i t R. I f R e r o m , n e t t i r w e b d l u o c s i h t , t x e t n o c m o r f d o o t s r e d n u s i l p m i s y s a ,
- By , n o i t n e v n o c t , u, d n a v t o n e d e l p u t e . s
- e h T " n o i t a t o n t o d " . R A . e ( g , . m a N . T N E D U T S e , e m a n e t u b i r t t a n a y f i l a u q o t d e s u s i ) l l a u s u y o p r u p e h t r o f e m a s a m o r f t i g n i h s i u g n i t s i d f o e s - n o i t a l e r t n e r e f f i d a n i e t u b i r t t a d e m a n

```
. e ( g , . m a N . T N E M T R A P E D e) .
```

) 6 l f e i r B y e s a b a t a d l a n o i t a l e r n o s n o i t a r e p o e t a d p u f o s e p y t t n e r e f f i d e h t s s u c s i d . w o h s n a t i r g e t n i l a i t n e r e f e r f o n o i t a l o i v a f o e l p m a x e y n i f o h c a e n o i t a r e p o e t a d p u e h t F r o a e c o h f e h t t a d p u e , e t e l e D , t r e s n I ( s n o i t a r e p o e d i s n o c e w , ) e t a d p U d n a r s d n i k t a h w l p p a m o r f t l u s e r y a m s n o i t a l o i v t n i a r t s n o c y . t c a e r o t e s o o h c t h g i m e w w o h d n a t i g n i

) 4 1 0 2 n a J / c e D , 3 1 0 2 n a J / c e D ( s k r a M 8

## e s n I rt:

- i a m o d e u l a v e t u b i r t t a e m o s : n o i t a l o i v t n i a r t s n o c n i r o c f o t o n s r m o d t c e a n i
- t i r g e t n i y t i t n e y e k : n o i t a l o i v y s i e l p u t w e n f o l u n l
- e k y e k : n o i t a l o i v t n i a r t s n o c y e n o g n i t s i x e s a e m a s s i e l p u t w e n f o
- e l p u t w e n f o y e k n g i e r o f : n o i t a l o i v y t i r g e t n i l a i t n e r e f e r n o n o t s r e f e r - e l p u t t n e t s i x e

r t o t y t i n u t r o p p o r e s u e v i g r O ! t r e s n i o t t p m e t t a e h t t c e j e r : t i h t i w g n i l a e d f o s y a W y h t i w n i a g a t n e r e f f i d a t u b i r t t e . s e u l a v

## Del t e e :

- i r g e t n i l a i t n e r e f e r t . s t s i x e e n o d e t e l e d e h t o t g n i r r e f e r e l p u t a : n o i t a l o i v y

n o i t p o e e r h T i l a e d r o f s n i h t i w g : t

- h t t c e j e R e dele n o i t
- t t A e o t t p m d a c s a c e r o ( pr t a g a p o e ) b t a h t e s o h t s u l p ( s e l p u t g n i c n e r e f e r y n a g n i t e l e d y

<!-- page-break -->

t e , m e h t e c n e r e f e r c , . etc ) .

- f i d o m y e k n g i e r o f e h t y o t s e l p u t g n i c n e r e f e r n i s e u l a v e t u b i r t t a n l l u s o t r o ome d i l a v e u l a v e l p u t t n e r e f f i d a g n i c n e r e f e r

## a d p U te:

- e K y r a m i r p : n o i t a l o i v t n i a r t s n o c y e k y r e h t o n a s a e m a s e m o c e b o t s a o s d e g n a h c s i s ' e l p u t
- i r g e t n i l a i t n e r e f e r t : n o i t a l o i v y
- o e l p u t t n e t s i x e n o n o t s r e f e r e n o w e n d n a d e g n a h c s i y e k n g i e r o f
- o g n a h c s i y e k y r a m i r p e n o s i h t o t d e r r e f e r d a h t a h t s e l p u t r e h t o w o n d n a d e e t a l o i v e h t c t s n o r t n i a

## ) 7 d i l a v n i n a d n a e t a t s d i l a v s i t a h W h t i w , e t a t s a d a o t t c e p s e r t e s a b a

) 3 1 0 2 y l u J / n u J , 4 1 0 2 n a J / c e D ( s k r a M 4

A e s a b a t a d e t a t s t a h t s e o d t o n b o ey l l a i r g e t n i ty c s t n i a r t s n o s i d e l l a c n a d i l a v n i a t s te d n a a e t a t s n i s t n i a r t s n o c e h t l l a s e i f s i t a s t a h t I e t a t s d i l a v d e l l a c s i C .

## 8) e n o y n a s s u c s i D ? n o i t a l e r f o s c i t s i r e t c a r a h c e h t t s i L ? ) 4 1 0 2 y l u J / n u J ( s k r a M 4

## s c i t s i r e t c a r a h C o n o i t a l e R f

- A l p u t e n a c b d e r e d i s n o c e t e s a s a of ( a &lt; t r t b i ut &gt; e , ) &gt; e u l a v &lt; a p irs. e h t s u h T g n i w o l l o f t o w s e l p u t r a e d i e l a c i t n :
- 1 t = , e m a N ( &lt; B a B . y 5 0 3 , N S S ( , ) r e - 1 6 - , ) 6 1 6 1 3 7 3 , e n o h P H ( , ) 5 3 4 2 1 9 2 , s s e r d d A ( B e u l L 3 2 , e g A ( , ) l l u n , e n o h P W ( , ) e n a ),( &gt; ) 5 2 . 3 , A P G
- l l u n , e n o h P W ( , ) 6 1 6 1 3 7 3 , e n o h P H ( &lt; = 2 t ),( , e m a N B . a B y , ) 3 2 , e g A ( , ) r e e u l B 1 9 2 , s s e r d d A ( L 5 0 3 , N S S ( , ) e n a - 1 6 - &gt; ) 5 2 . 3 , A P G ( , ) 5 3 4 2
- l p u T e g n i r e d r o s i t o n a p t r a f o , n o i t a l e r a h t t is e h t o f l l w o i g n e r la i t n o s i c i t n e d i al o t t a h t f o

k a t e l b a T e b n e o l w.



<!-- page-break -->

## p u t d n a s e t u b i r t t a e h T l S n o i t a l e r a f o s e D U T E T N

## 9) t s u o i r a V s s u c s i D y f o s e p I s n o i t a r e p O n i o J r e n n

## ?

) 4 1 0 2 y l u J / n u J ( s k r a M 8 ) 5 1 n a J / 4 1 c e D s k r a m 5 (

## n i o j r e n n i

a i s e t r a c e h T n c u d o r p t e l p m a x e o b a ve e n i b m o c d h c a e l p m e oyee h t i w ea h c e d p r a m t n e t. f I n o e w l p e e k y s o h t e e n i l s wh r e e the de t p e t u b i r t t a for h t e p m e loyee s i q e ual o t the n d r e h t ( e d p t r a m t n e ) r e b m u n f o e h t t r a p e d m , t n e e w t e g a e c i n t s i l f o e h t l p m e o , s e e y d n a the t r a p e d m t n e .

- r e v A y . n o i t a r e p o l u f e s u d n a n o m m o c
- b d e w o l l o f t c u d o r p n a i s e t r a c a o t t n e l a v i u q E y t c e l e s a .
- e d i s n I e r a l l a n o i t a B D M s i t i , S l a u s u ly mu h c o m re t n e i c i f f e to a c lc l u ate a j n i o di c e r tl , y i s n t a e d f o a w a g n i w o r h t n e h t d n a t c u d o r p n a i s e t r a c a g n i t a l u c l a c y . s e n i l e h t f o t s o m
- e t o N t a h t e h t e m a s L Q S e u q ry n a c e b a r t n d e t a l s o t l a r e v e s e f f i d r t n e l a n o i t a l e r e g l a b s n o i s s e r p x e a r . t l u s e r e m a s e h t e v i g l l a h c i h w ,
- f I e w e m u s s a t a h t e s e h t l a n o i t a l e r al e g b a r ex e r p s s n o i s e r a ex , d e t u c e i s n i de a r l a n o i t a l e D S M B h c i h w s e s u l a n o i t a l e r a r b e g l a s n o i t a r e p o s a s t i r e w o l - e l v l e l a n r e t n i i t a r e p o o , s n t n e r e f f i d l a n o i t a l e r n a c s n o i s s e r p x e a r b e g l a r e v e k a t y r o m e m d n a ( e m i t t n e r e f f i d y e t u c e x e o t ) . a m e h c s g n i w o l l o f e h t r e d i s n o C

l a S ( r o l i a S - l a S , d i - l a S ( s e v r e s e R ) e g a , g n i t a r , e m a n - t a o B , d i - d , d i a t a o b , d i \_ t a o B ( s t a o B ) y - ) r o l o c , e m a n

- I. F d e l l a c , s t a o b l l a d e v r e s e r e v a h o h w , s r o l i a s f o s e m a n e h t d n i I ? e k a l r e t n

e S l a S t c e l - b s t a o B , r s e v r e s e R , s r o l i a S m o r f e m a n whe e r

l a s . r - l a s . s = = d i - t a o b . r d n a d i - t a o b . b = = d i - t a o b d n a d i - " = e m a n I ; " e k a l r e t n

- II. e s e r t ' n e v a h o h w 0 2 r e v o e g a h t i w r o l i a s e h t f o d i S e h t d n i F r . t a o b e h t d e v

t c e l e S d i s m o r f r o l i a s s e r e h w T O N EXIS t c e l e s ( S T l a S . S - d i R F M O Sa l i r o S ,R s e v r e s e r t a o b . b = d i b . r e r e h w b s t a o B , - ) d i a e g a d n &gt; ; 0 2

- III F o w T t s a e l t a d e v r e s e r e v a h o h w , s r o l i a s f o s e m a n e h t d n i B s t a o

t c e l e S l a s . S - e m a n m o r f s r o l i a s r e s e R , S v s e s t a o b , r b e h w re l a s . r i l a s . s = d - d i d n a b. o b att a o b . r = d i - n i v a h d i g o c t n u ( ) * = &gt; 2

<!-- page-break -->

## 0 1 e k n g i e r o F n i a l p x E ) y e c n a t r o p m i s t i d n a . n o , t s i x e y e k n g i e r o f n a C l e l b a t e l g n i s r o f y ex n i a l p ? ) 3 1 0 2 y l u J / n u J ( s k r a M 8

e k y r a m i r p e h t o t s t n i o p t a h t ) s d l e i f r o ( d l e i f a s i y e k n g i e r o f A y e l b a t r e h t o n a f o . s o p r u p e h T e e h t f o g i e r o f e k n y t i r g e t n i l a i t n e r e f e r e r u s n e o t s i y l n o , s d r o w r e h t o n I . a t a d e h t f o y t a h t s e u l a v o t d e s o p p u s e r a p e r a e s a b a t a d e h t n i r a e p p a r e t t i m e . d

## O E L B A T E T A E R C RD S R E

e d r O ( r n i D I \_ e t ge , r

d r O r e a D \_ t t a d e e,

m o t s u C e I S \_ r D n i e t , r e g

, e l b u o d t n u o m A

P y r a m i r K I \_ r e d r O ( y e , ) D

F I S ( R E M O T S U C s e c n e r e f e r ) D I S \_ r e m o t s u C ( y e K n g i e r o ) D ; )

e k n g i e r o f s e Y y s i x e n a c t n i s a r o f s g . e l b a T e l

- 1 1 n a w o H ) I n i s u d e t n e m e l p m i e b n a c r o t a r e p O n o i t c e s r e t n g s u n i M d n a n o i n U r e p o a ? r o t

y l u J / n u J ( s k r a M 8 3 1 0 2 )

s o n l l o R t c e l e F m o r (

m m u d S A 1 t c e l e S y w o h S e g a t S m o r F o n l l o R ,

A n o i n U L L

m m u d S A 2 t c e l e S y s t r o p S m o r F o n l l o R ,

B p u o r g X ) y 2 = ) * ( t n u o c g n i v a h o n l l o R

- 2 1 e u q e t i r W ) g l A l a n o i t a l e R n i s e i r e r b a? ) 3 1 0 2 n a J / c e D ( s k r a M 8
- ) i o l p m e n a r o f s t n e d n e p e d f o r e b m u n e h t e v e i r t e R y M A R " e e "?

N m a e , N S S , D ( e m a n E ( 2 N S S = N S S m y o l p e x e a n D , 2 N S S m ) ) s t n e d n e p e D ( e



- i i ) ? t n e m t r a p e d h c a e f o r e g a n a m f o e m a n e h t d n i F \

De m t r a n

p e t MG S S = N S S R N o l p m E y e e

- ) i i i o l p m e f o s e m a n e h t e v e i r t e R y ? " J A R " f o t a h t s a t n e m t r a p e d e m a s n i s k r o w o h w e e

<!-- page-break -->

<!-- formula-not-decoded -->

## . 3 1 t n i a r t s n o c h t i w l a e d n o i t a l e r a n o s n o i t a r e p o e t a d p u t n e r e f f i d e h t w o h s s u c s i d y l f e i r B ? s n o i t a l o i v ) 5 1 0 2 y l u J / e n u J ( s k r a m 8

s n o c f o s e p y t e e r h t e r a e r e h T : e s a b a t a d l a n o i t a l e r n o s t n i a r t

- s t n i a r t s n o C n i a m o D ·
- s t n i a r t s n o C y e K y r a m i r P ·
- s t n i a r t s n o C y t i r g e t n I ·

## : s t n i a r t s n o C n i a m o D

g n i d n o p s e r r o c e h t m o r f y l n o e u l a v c i m o t a n a n i a t n o c t s u m n o i t a l e r a n i e t u b i r t t a h c a e t a h t s e i f i c e p s t I p s t n i a r t s n o c n i a m o D . s n i a m o d e h t f o e c n a t s n i h c a e n o t u p o t t n a w e w t a h t n o i t i d n o c e h t s e i f i c e h t i w d e t a i c o s s a n i a m o d e h t m o r f n w a r d e b t s u m n m u l o c h c a e n i r a e p p a t a h t s e u l a v e h t o S . n o i t a l e r . n m u l o c t a h t

## : s t n i a r t s n o C y e K

u t h c a e n i e u l a v e t u b i r t t a y e k e h t t a h t s e t a t s s t n i a r t s n o c s i h T s e l p u t o w t o n , . e . i , e u q i n u e b t s u m e l p o t d e s u s i y e k y r a m i r p e h t f o e u l a v e h t e s u a c e b s i s i h T . e t u b i r t t a y e k e h t r o f e u l a v e m a s e h t n i a t n o c . n o i t a l e r e h t n i s e l p u t e h t y f i t n e d i

## : s t n i a r t s n o C y t i r g e t n I

: s t n i a r t s n o c y t i r g e t n i f o s e p y t o w t e r a e r e h T

- y t i t n E · t n i a r t s n o C y t i r g e t n I
- t n i a r t s n o C y t i r g e t n I l a i t n e r e f e R ·

## : t n i a r t s n o C y t i r g e t n I y t i t n E

y f i t n e d i o t d e s u s i y e k y r a m i r p e h t e s u a c e b s i s i h T . l l u n e b n a c e u l a v y e k y r a m i r p o n t a h t s e t a t s t I y f i t n e d i o t e l b a e b t o n l l i w e w o S . n o i t a l e r e h t n i e l p u t l a u d i v i d n i l l u n g n i n i a t n o c y l e u q i n u s d r o c e r e h t . s e t u b i r t t a y e k y r a m i r p e h t r o f s e u l a v

## : t n i a r t s n o C y t i r g e t n I l a i t n e r e f e R

n i e l p u t g n i t s i x e n a o t r e f e r t s u m n o i t a l e r r e h t o n a o t s r e f e r t a h t n o i t a l e r e n o n i e l p u t e h t t a h t s e t a t s t I c e p s s i t n i a r t s n o c s i h T . n o i t a l e r t a h t . t c n i t s i d y l i r a s s e c e n t o n , s n o i t a l e r o w t n o d e i f i

<!-- page-break -->

## a m e h c s e h t e v i G 4 1

## ) 5 1 n a J / 4 1 c e D ( s k r a m 0 1



## U T I N - V I

<!-- formula-not-decoded -->

## y l u J / n u J ( s k r a M 4 1 3 1 0 2 ) 5 1 0 2 y l u J / e n u J &amp;

, e m a n L , e m a n F ( P M E N S S ) o n D , N S S r e p u S , y r a l a S , x e S , s s e r d d A , e t a d B ,

, e m a n D ( T P E D r e b m u n D , ) e t a d t r a t s r G M , N S S r g M

T P E D - ( C O L c o l D , r e b m u n D O R P ) J , e m a n P ( T C E r e b m u n P ) m u n D , c o l P ,

S K R O W - ( N O S S E o N P , N ,H s r u o )

e a r b e g l a n o i t a l e r e h t e v i G x g n i w o l l o f e h t r o f n o i s s e r p :

## . 1 e 0 2 = o n D m o r f s e e y o l p m e e l a m e f t s i L a m g n i n r o 0 0 0 5 n a h t e r 0

<!-- formula-not-decoded -->

- 1 e h c s e h t n e v i G ) m a

<!-- page-break -->

## . 2 n e m t r a p e d ' E S C ' t s i L t s l i a t e d .

<!-- formula-not-decoded -->

3. r t e R i e v e e h t t s r i f na , e m t s a l e m a n d n a y r a l a s of l l a m e pl s e e y o who w r o k u n l a t n e m t r a p e d n i m 0 5 r e b

<!-- formula-not-decoded -->

- . 4 t n e m t r a p e d h c a e f o r e g a n a m e h t f o e m a n e h t e v e i r t e R .

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

- . 5 e l l a f o s s e r d d a d n a e m a n e h t e v e i r t e R m k r o w o h w s e e y o l p . t n e m t r a p e d s t r o p s r o f

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

- 2 a x e h t i w n i a l p x e , L Q S o t t c e p s e r h t i W ) e l p

## m . ) 3 1 0 2 n a J / c e D ( s k r a M 4

- i) Dr p o t : e l b a a B ( n o i t a l e r a e v o m e r o t d e s u s i t I s d s t i d n a ) e l b a t e e n o i t i n i f . e h T n o i t a l e r n a c o n r e g n o l e b e s u d r o f , g n i y r e u q s e t a d p u r o any r e h t o n a m m o c ds e c n i s s t i r e g n o l o n n o i t p i r c s e d e s t s i x
2. i i ) r e t l A e l b a t : t I s i d e s u o t d d a n a e t u b i r t t a o t e n o f o t e h e s a b t a l e r n o i s. e h T w e n e t u b i r t t a l l i w e v a h ' L L U N s n i l l a s e l p u t of h t e a l e r i t n o ri h g t a e t f r h t e co m m d n a is L U N T O N e h t e c n e h , d e t u c e x e L w o l l a t o n s i t n i a r t s n o c e t u b i r t t a n a h c u s r o f d e.

b a t p o r D : x E l p e d e e ; t n e d n

: x E o l p m E e l b a t r e t l A y ; ) 2 1 ( 2 r a h c r a v B O J d d a e e

## 3 a x e n a h t i w s n o i t a r e p o S T S I X E d n a N I n i a l p x E ) m e l p .

## u J / n u J ( s k r a M 6 1 0 2 y l 3 y l u J / n u J , 3 1 0 2 )

S T S I X E s i d e s u o t k c e h c r e h t e h w e h t t l u s e r f o a d e t a l e r r o c n d e t s e e u q ry s i p m e ty ( s n i a t n o c no s e l p u t ) . t o n r o

: x E y r e u Q : e v e i r t e R e h t e m a n f o c a e h l p m e o e e y h w o s a h a e d pe d n n e t w t i h e h t a s me o l p m e e h t s a e m a n t s r i f y . e e

: T C E L E S

Q

A N F E M , L E M A N

F M O R P M E LO E E Y

E R E H W

S T S I X E T C E L E S ( *

<!-- page-break -->

## F M O R T N E D N E P E D E R E H W N S S = N S S E N A D F N \_ T N E D N E P E D = E M A N A ) E M

e h T n o s i r a p m o c t a r e p o or N I p m o c a s e r a e u l a v v h t i w a t e s r o ( i t l u m - ) t e s f o a v l s e u , V d n a V n i s t n e m e l e e h t f o e n o s i v f i E U R T o t s e t a u l a v e

: x E i r t e R e v e e h t e m a n f o h c a e l p m e o e e y o h w s a h a t n e d n e p e d h t i w e h t sa e m t s r i f e m a n as t e h o l p m e y . e e

E S : Q L T C E

F M O R

. E F , E M A N . E L E M A N

P M E LO E E Y ASE

E R E H W

N S S . E IN

E S ( L T C E

N S S E

F M O R

T N E D N E P E D

E R E H W

N S S E = N S S . E D N A

. E FNA E M = ) E M A N \_ T N E D N E P E D

- 4) w o H s e o d L Q S t n e m e l p n i e h t e y t i t n i r g e t n i ty s t n i a r t s n o c of l a n o i t a l e r a t a D l e d o M ? Ex n i a l p l p m a x e n a h t i w e?

) 3 1 0 2 y l u J / n u J , 4 1 0 2 n a J / c e D ( s k r a M 4 ) 5 1 n a J / 4 1 c e D s k r a m 8 (

n I , l a r e n e g n a e t a d p u n o a w e i v on d e n i f e d n o a e l g n i s e l b a t o / w any g g a r e t a g e s n o i t c n u f n a c be h t n o e t a d p u n a o t d e p p a m e s a b e ta e l b

o M re s w e i V n o

n i w o l l o f e h t e k a m n a c e W g v r e s b o a : s n o i t

- A w e i v h t i w a g n i s le f e d i g n i n e l b a t s i e l b a t a d p u if e w view n o c tain PK or CK f o t e h base ta l b e
- n i s u s e l b a t e l p i t l u m n o w e i V g d p u t o n e r a s n i o j a e l b a t
- g a / g n i p u o r g g n i s u d e n i f e d w e i V g e l b a t a d p u t o n e r a e t a g e r
- f i c e p S y s t n i a r t s n o C l a r e n e G g n i
- s a h c u s s t n i a r t s n o c n i a t r e c y f i c e p s n a c s r e s U e s m s t n i a r t s n o c s c i t n a

T R E S S A E T A E R C I A S N O L T N I A R T S N O C \_ Y R A

C E H C K ( O N T X E I S T S ( T C E L E S * FROM P M E L E E Y O E, P M E L E E Y O , M T N E M T R A P E D D A S . E E R E H W L M &gt; Y R A . A S L Y R A D N A O N D . E = M U N . D B R E D N A ) ) N S S . M = N S S R G M . D

## n i w o l l o f e h t r e d i s n o C ) 5 g n i w o l l o f e h t f o t l u s e r e h t w o h s 2 T d n a 1 T s e l b a t o w t g

<!-- page-break -->

## s n o i t a r e p o

1 T ∞ T = p . 1 T 2 A . 2 T

T1∞ B . 2 T = Q . 1 T 2 T

1 T ∞ T = p . 1 T 2 A . 2 T

## 2 T U 1 T

## N U E R A 2 T D N A 1 T E M U S S A ( I L I B I T A P M O C N O I Y T )

) 4 1 0 2 y l u J / n u J , 3 1 0 2 n a J / c e D ( s k r a M 8

e l b a T 2 T

e l b a T 1 T

|   P | Q   |   R | A   | B   |   C |
|-----|-----|-----|-----|-----|-----|
|  10 | a   |   5 | 0 1 | b   |   6 |
|  15 | b   |   8 | 5 2 | c   |   3 |
|  25 | a   |   6 | 0 1 | b   |   5 |

## e t a e r c u o y n e h w , d e i f i c e p s e b n a c t a h t s t n i a r t s n o c c i s a b e h t , e l p m a x e n a h t i w n i a l p x E . 6 . L Q S n i e l b a t a ) 4 1 0 2 y l u J / n u J ( s k r a M 4

s e l p u T n i t e h e r e f e r n g n i c e r lat n o i R1 h e v a attri e t u b s K F ( l a c l d e i e r o f n g y e k ) s e t u b i r t t a th t a e c n e r e f e r e h t a m i r p ry k y e s e t u b i r t t a K P f o e h t e r f r d e c n e r e e n o i t a l R2. A p u t le t1 in R1 is d i a s to f e r ere c n e a e l p u t t2 n i R2 if

<!-- formula-not-decoded -->

A l a i t n e r e f e r i r g e t n i ty co t n i a r t s n n a c e b l p s i d a d e y n i a l a n o i t a l e r e s a b a t a d a m e h c s s a a d e t c e r i d c r a f o r m R1 K F . o t R2.

- y t i t n E y t i r g e t n i s n o c t a r n i t - e h T i r g e t n i y t i t n e ty co t n i a r t s n s e t a t s a h t t o n r p i a m ry key l a v ue n a c e b n l u . l s i h T s i e s u a c e b e h t a m i r p ry key l a v ue s i d e s u o t i t n e d i fy i d n ivi a u d l tu l p s e i a n : n o i t a l e r i v a h ng l l u n v s e u l a r o f e h t a m i r p ry ke s y m i s e i l p t a h t we c n n a ot i e d i t n fy o s me e l p u t s . t i t n e d n a s t n i a r t s n o c y e K y s n o i t a l e r l a u d i v i d n i n o d e i f i c e p s e r a s t n i a r t s n o c .
- l a i t n e r e f e R y t i r g e t n i s n o c t a r n i t - e h T l a i t n e r e f e r i i r g e t n ty t s n o c r t n i a s i d e i f i c e p s w t e b e n e o t d e s u s i d n a s n o i t a l e r o w t n i a t n i a m t e h y c n e t s i s n o c g n o m a u t l p s e f o e h t t o w t a l e r n o i . s A e l p u t n i e n o n o i t a l e r a h t t s r e f e r o t r e h t o n a i t a l e r on t s u m r e f e r o t an exi t s g n i tu l p e n i h t t a rela . n o i t

<!-- page-break -->

- n g i e r o F y e k s i a t e s f o s e t u b i r t t a f o e n o e r l n o i t a R1 o h w se a v l s e u r a e e r qui e r d o t m h c t a o s e u l a v e k e t a d i d n a c e m o s f y l e r e m o s f o a R n o i t 2 .

r o F , e l p m a x e e h t l a v ue f o e t u b i r t t a O N D n i e v e ry M E P E E Y O L t e l p u t s u m mat h c h t e T N E M T R A P E D e h t n i e l p u t e m o s f o e u l a v R E B M U N D e r la . n o i t

- 7 ) B p u o r g w o h n i a l p x E y a E R E H W n e e w t e b e c n e r e f f i d e h t s i t a h W ? s k r o w e s u a l c d n ? g n i v a H n I a m ny , s e s a c e w t n a w o t p p a ly the g g a r t a g e e s n o i t c n u f o t s p u o r g b u s f o s e l p u t n i a e r lat n o i h c a E r g b u s o p u f o s e l p u t s t s i s n o c f o e h t t e s of tup s e l t a h t a h ve h t e a s me e u l a v for h t e i p u o r g ng e t u b i r t t a (s)

## 4 1 0 2 n a J / c e D ( s k r a M 8 5 1 0 2 y l u J / e n u J &amp; )

l t n e d n e p e d n i p u o r g b u s h c a e o t d e i l p p a s i n o i t c n u f e h T y

L Q S s a h a P U O R G Y B e s u a l c for p s e i c f i y ng e h t i p u o r g ng , s e t u b i r t t a i h w ch u m st al o s e p p a ar in E S e h t L a l c T C E e s u

E S L ) * ( T N U O C , E M A N P , R E B M U N P T C E

, T C E J O R P M O R F WO N O \_ S K R

R E B M U N P E R E H W =PN O

P U O R G B E M A N P , R E B M U N P Y

n I e h t M E P E E Y O L s e l p u t e r a d e d i v i d o t n i h c a e s p u o r g p u o r g i v a h ng the same a v l e u r o f e h t G g n i p u o r t t a r e t u b i O N D e h T T N U O C d n a G V A s n o i t c n u f e r a d e i l p p a to h c a e su h c p u o r g of t s e l p u s a p e ratel e h T . y e s u a l c T C E L E S s e d u l c n i n o ly e h t g n i p u o r g r t t a i e t u b d n a e h t s n o i t c n u f o t e b d e i l p p a n o h c a e r g l p u t f o p u o es . n i d e s u e b n a c n o i t i d n o c n i o j A i p u o r g h t i w n o i t c n u j n o c ng .

- 8) w o H s e o d L Q S t n e m e l p m i e h t y t i t n e i r g e t n i ty s t n i a r t s n o c of l a n o i t a l e r a t a D l e d o M ? Ex h t i w n i a l p l p m a x e n a e? ) 3 1 0 2 y l u J / n u J ( s k r a M 8 (

n I , l a r e n e g n a e t a d p u n o a w e i v n o d e n i f e d n o a e l g n i s e l b a t o / w any g g a r e t a g e s n o i t c n u f n a c be h t n o e t a d p u n a o t d e p p a m e s a b e ta e l b

o M re s w e i V n o

n i w o l l o f e h t e k a m n a c e W g v r e s b o a : s n o i t

- A w e i v h t i w a g n i s le f e d i g n i n e l b a t s i e l b a t a d p u if e w view n o c tain PK or CK f o t e h base ta l b e
- n i s u s e l b a t e l p i t l u m n o w e i V g d p u t o n e r a s n i o j a e l b a t
- n i p u o r g g n i s u d e n i f e d w e i V g g a / gr e l b a t a d p u t o n e r a e t a g e
- f i c e p S y s t n i a r t s n o C l a r e n e G g n i
- s a h c u s s t n i a r t s n o c n i a t r e c y f i c e p s n a c s r e s U e s m s t n i a r t s n o c s c i t n a

<!-- page-break -->

T R E S S A E T A E R C I A S N O L T N I A R T S N O C \_ Y R A

C E H C K ( T O N X E I S T S ( T C E L E S * FROM P M E L E E Y O E, P M E L E E Y O , M

T N E M T R A P E D D

A S . E E R E H W L M &gt; Y R A . SAL Y R A D N A O N D . E = M U N . D B R E D N A ) ) N S S . M = N S S R G M .

D

## 9) e i f i c e p s e r a t a h t s n o i t p o e l b i s s o p l l a n i a l p x E d e f e r n e h w r y t i r g e t n i l a i t n e t s n o c r s i t n i a s n o i t p o l l a r o f e l p m a x e e l b a t i u s g n i s u d e t a l o i v ? y l u J / n u J ( s k r a M 8 3 1 0 2 ) 4 1 0 2 y l u J / n u J ,

l a n i g i r o e h t o t n o i t i d d a n A r a m i r p f o n o i t a c i f i c e p s s w o l l a d r a d n a t s y e k e t a d i d n a c d n a y d n a s e k n g i e r o f y e h t f o t r a p s a s l b a t e t a e r c e : d n a m m o c

- i r p mar y e k y r a m i r p e h t g n i m r o f s e t u b i r t t a f o t s i l a s e d u l c n i e s u a l c y e k y.
- i n u q k e u ey n a c a g n i m r o f s e t u b i r t t a f o t s i l a s e d u l c n i e s u a l c e k e t a d i d y.
- k n g i e r o f ey n i m r o f s e t u b i r t t a f o t s i l a s e d u l c n i e s u a l c g e h t f i e r o g e k n y e m a n e h t d n a , b d e c n e r e f e r n o i t a l e r e h t f o y e k n g i e r o f e h t y .
- t i r g e t n i l a i t n e r e f e r a n e h W y e h t t c e j e r o t s i e r u d e c o r p l a m r o n e h t , d e t a l o i v s i t n i a r t s n o c ac n o i t . a t u B e k n g i e r o f y L Q S n i e s u a l c - f i c e p s n a c 2 9 y e h t e g n a h c o t n e k a t e b o t s p e t s . t n i a r t s n o c e h t e r o t s e r o t n o i t a l e r d e c n e r e f e r e h t n i s e l p u t

## l p m a x E e.

a e r c t e l b a t e t n u o c c a

y e k n g i e r o f ( m a n b e ) c n e r e f e r es n a r b ch

d n o e e l t e c e d a c s a

e s n i n o r t c s a c d a e,

I d a f e e t e l f o a n i e l p u t br h c n a s t n i a r t s n o c y t i r g e t n i l a i t n e r e f e r g n i d e c e r p e h t n i s t l u s e r g n i e b ' e d a c s a c ` ` e t e l e d e h t t u b , d e t c e j e r t o n s i e t e l e d e h t , d e t a l o i v ' e h t o t t n u o c c a , n o i t a l e r l e d e g n i t t e l e d s a w t a h t h c n a r b e h t o t s r e f e r t a h t e l p u t e h t ed . c e b l l i w e t a d p U e h t o t d e d a c s a ne v w a e u l r b e h t f o a ! h c n

- Q S Le h t s w o l l a o s l a 2 9 k n g i e r o f ey f i c e p s o t e s u a l c y h c u s , e d a c s a c n a h t r e h t o s n o i t c a t l u a f e d a o t r o , l l u n o t d l e i f g n i c n e f e r e h t g n i t t e s s a v t s n o c e h t f i , e u l a r d e t a l o i v s i t n i a .
- n g i e r o f f o n i a h c a s i e r e h t f I e k y r o n o i t e l e d a , s n o i t a l e r e l p i t l u m s s o r c a s e i c n e d n e p e d

<!-- page-break -->

a p o r p n a c n i a h c e h t f o d n e e n o t a e t a d p u g i t n e e h t s s o r c a e t a r e cha r o e t a d p u g n i d a c s a c a f I . n i b d e l d n a h e b t o n n a c t a h t n o i t a l o i v t n i a r t s n o c a s e s u a c e t e l e d y , n o i t a r e p o g n i d a c s a c r e h t r u f a e t s y s e h t s t i d n a n o i t c a s n a r t e h t y b d e s u a c s e g n a h c e h t l l a d n a n o i t c a s n a r t e h t s t r o b a m e n o d n u e r a s n o i t c a g n i d a c s a c . y a w e h t f o e r u t a n y r a r t i b r a d n a y t i x e l p m o c d n a n e v i G l l a t a h t e r u s n e o t t s e b e h t s i t i , s e u l a v l l u n h t i w e v a h e b L Q S n i s t n i a r t s n o c c s n m u l o f o q i n u ue a d n r o f e n g i e k y e r a s n o i t a c i f i c e p s r a l c e d e b o t d e n o n . l l u n

## 0 1 ) Q S n i s e i r e u q e t i r W L n i w o l l o f e h t r o f g

) 4 1 0 2 n a J / c e D , 3 1 0 2 n a J / c e D ( s k r a M 8

P M E l l a t c e l e S L P M E f o s n o i t a n i b m o c l l a d n a , s N S S E E Y O L d n a N S S E E Y O E M T R A P E D N D T N A E M ?

E S L T C E E M A N D , N S S

O R F M P

M E L T N E M T R A P E D , E E Y O

o l p m e y r e v e f i s e i r a l a s g n i t l u s e r e h t w o h S y ' X t c u d o r P ' e h t n o g n i k r o w e e s i t c e j o r p g r t n e c r e p 0 1 a n e v i a . e s i

E S L T C E , E M A N F L Y R A L A S * 1 . 1 , E M A N

F M O R P M E L T C E J O R P , N O \_ S K R O W , E E Y O

E R E H W = N S S E P D N A N S S = E M A N P D N A R E B M U N P = O N ' X t c u d o r P ';

o l p m e n a e v l o v n i t a h t s t c e j o r p r o f s r e b m u n t c e j o r P f o t s i l a e k a M y s o h w e e e s i e m a n t s a l t a h t t n e m t r a p e d e h t f o r e g n a m a s a r o r e k r o w a s a r e h t i e , ' h t i m S ' c h t s l o r t n o e e j o r p ct

E S L D T C E I R E B M U N P T C N I T S T C E J O R P M O R F B M U N P E R E H W N I R E R E B M U N P T C E L E S ( , T C E J O R P M O R F M E , T N E M T R A P E D P E E Y O L E R E H W D N A R E B M U N D = M U N D ' h t i m S ' = E M A N L D N A N S S = N S S R G M

<!-- page-break -->

## ) 0 1 ? . e l p m a x e e v i g d n a L Q S n i s e t u b i r t t a r o f e l b a l i a v a s e p y t a t a d c i s a b e h t n i a l p x e d n a t s i L

## ) 5 1 0 2 y l u J / e n u J ( s k r a m 5

| e p y t a t a D                                               | n o i t p i r c s e D                                                                                                                                                                                                                                                                           |
|---------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ) n ( R E T C A R A H C                                       | d e x i F . g n i r t s r e t c a r a h C - n h t g n e l                                                                                                                                                                                                                                       |
| r o ) n ( R A H C R A V ) n ( G N I Y R A V R E T C A R A H C | n h t g n e l m u m i x a M . h t g n e l e l b a i r a V . g n i r t s r e t c a r a h C                                                                                                                                                                                                       |
| ) n ( Y R A N I B                                             | d e x i F . g n i r t s y r a n i B - n h t g n e l                                                                                                                                                                                                                                             |
| N A E L O O B                                                 | s e u l a v E S L A F r o E U R T s e r o t S                                                                                                                                                                                                                                                   |
| r o ) n ( Y R A N I B R A V ) n ( G N I Y R A V Y R A N I B   | n h t g n e l m u m i x a M . h t g n e l e l b a i r a V . g n i r t s y r a n i B                                                                                                                                                                                                             |
| ) p ( R E G E T N I                                           | ) l a m i c e d o n ( l a c i r e m u n r e g e t n I p n o i s i c e r P .                                                                                                                                                                                                                     |
| T N I L L A M S                                               | 5 n o i s i c e r P . ) l a m i c e d o n ( l a c i r e m u n r e g e t n I                                                                                                                                                                                                                     |
| R E G E T N I                                                 | 0 1 n o i s i c e r P . ) l a m i c e d o n ( l a c i r e m u n r e g e t n I                                                                                                                                                                                                                   |
| T N I G I B                                                   | 9 1 n o i s i c e r P . ) l a m i c e d o n ( l a c i r e m u n r e g e t n I                                                                                                                                                                                                                   |
| ) s , p ( L A M I C E D                                       | n a s i ) 2 , 5 ( l a m i c e d : e l p m a x E . s e l a c s , p n o i s i c e r p , l a c i r e m u n t c a x E a h t a h t r e b m u l a m i c e d e h t r e t f a s t i g i d 2 d n a l a m i c e d e h t e r o f e b                                                                       |
| ) s , p ( C I R E M U N                                       | ) L A M I C E D s a e m a S ( . s e l a c s , p n o i s i c e r p , l a c i r e m u n t c a x E                                                                                                                                                                                                 |
| ) p ( T A O L F                                               | p x e 0 1 e s a b n i r e b m u n g n i t a o l f A . p n o i s i c e r p a s s i t n a m , l a c i r e m u n e t a m i x o r p p A s e h T . n o i t a t o n t g n i y f i c e p s r e b m u n e l g n i s a f o s t s i s n o c e p y t s i h t r o f t n e m u g r a e z i n o i s i c e r p |
| L A E R                                                       | 7 n o i s i c e r p a s s i t n a m , l a c i r e m u n e t a m i x o r p p A                                                                                                                                                                                                                   |
| T A O L F                                                     | 6 1 n o i s i c e r p a s s i t n a m , l a c i r e m u n e t a m i x o r p p A                                                                                                                                                                                                                 |

<!-- page-break -->

| N O I S I C E R P E L B U O D   | 6 1 n o i s i c e r p a s s i t n a m , l a c i r e m u n e t a m i x o r p p A                                                                           |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| A D E T                         | s e u l a v y a d d n a , h t n o m , r a e y s e r o t S                                                                                                 |
| E M I T                         | s e u l a v d n o c e s d n a , e t u n i m , r u o h s e r o t S                                                                                         |
| P M A T S E M I T               | s e u l a v d n o c e s d n a , e t u n i m , r u o h , y a d , h t n o m , r a e y s e r o t S                                                           |
| L A V R E T N I                 | n i d n e p e d , e m i t f o d o i r e p a g n i t n e s e r p e r , s d l e i f r e g e t n i f o r e b m u n a f o d e s o p m o C f o l a v r e t n i |
| Y A R R A                       | t e s A - s t n e m e l e f o n o i t c e l l o c d e r e d r o d n a h t g n e l                                                                         |
| T E S I T L U M                 | e l b a i r a v A - s t n e m e l e f o n o i t c e l l o c d e r e d r o n u d n a h t g n e l                                                           |
| L M X                           | a t a d L M X s e r o t S                                                                                                                                 |

## 1 1 e h c s e h t n e v i G ) m a

## ) 5 1 n a J / 4 1 c e D ( s k r a M 2 1

, e m a n L , e m a n F ( P M E N S S ) o n D , N S S r e p u S , y r a l a S , x e S , s s e r d d A , e t a d B ,

, e m a n D ( T P E D r e b m u n D , ) e t a d t r a t s r G M , N S S r g M

T P E D - ( C O L c o l D , r e b m u n D O R P ) J , e m a n P ( T C E r e b m u n P ) m u n D , c o l P ,

S K R O W - ( N O N S S E o N P , ,H s r u o )

e a r b e g l a n o i t a l e r e h t e v i G x g n i w o l l o f e h t r o f n o i s s e r p :

## . 1 e 0 2 = o n D m o r f s e e y o l p m e e l a m e f t s i L a m g n i n r o 0 0 0 5 n a h t e r 0

m e T p σ d n a 0 2 = o n D s r a l a y 0 0 0 0 5 &lt; (E ) P M

p m e T 2 σ ' = x e s F' ) p m e T (

Re t l u s П L , e m a n F e m a n ) 2 p m e T (

. 2 n e m t r a p e d ' E S C ' t s i L t s l i a t e d .

Re t l u s σ ' E S C ' = e m a n D ) t n e m t r a p e D (

3. r t e R i e v e e h t t s r i f na , e m t s a l e m a n d n a y r a l a s of l l a m e pl s e e y o who w r o k

<!-- page-break -->

## u n l a t n e m t r a p e d n i mb 0 5 r e

<!-- formula-not-decoded -->

- . 4 t n e m t r a p e d h c a e f o r e g a n a m e h t f o e m a n e h t e v e i r t e R .

R G M S П n S S r g M ) t n e m t r a p e D (

Re t l u s П L S R G M ( e m a n F , e m a n ) P M E ∞

- . 5 e l l a f o s s e r d d a d n a e m a n e h t e v e i r t e R m k r o w o h w s e e y o l p . t n e m t r a p e d s t r o p s r o f

<!-- formula-not-decoded -->

t r o p S - s p m E t r o p S ( - t p e d ∞ ) P M E

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

- . 1 a x e h t i w L Q S n i s t n e m e t a t s e t a d p u d n a e t e l e d , t r e s n i n i a l p x E m . e l p

## 8 s k r a M n a J / c e D ( 0 2 0 2 y l u J / e n u J &amp; 3 1 5 1 )

## t r e s n I e h T Ope n o i t a r

s i h T n o i t a r e p o n a c o i v l e t a l l a t s n o c r s t n i a n i a l a n o i t a l e r a t a d b o D . e s a ma n i n o c t s a r i s t n can be d e t a l o i v f i n a e t u b i r t t a e u l a v s i n e v i g t a h t s e o d t o n r a e p p a n i e h t e r r o c s g n i d n o p o d mai . n e K y s t n i a r t s n o c n a c e b a l o i v t d e f i a key e u l a v in e h t w e n e l p u t e r l a ady e s t i x n i a t o n e h r t e l p u in t e h n o i t a l e r . R i t n E ty s n o c t s t n i a r a c n be d e t a l o i v if e h t p a m i r ry key of t e h e n w t e l p u s i u n l . l

l a i t n e r e f e R i r g e t n i ty n a c e b d e t a l o i v f i e h t e u l a v of any n g i e r o f key n i t e r f s r e o t a e l p u t t a h t s e o d

e t o n n o i t a l e r d e c n e r e f e r e h t n i t s i x . e p o s i h t f o s e l p m a x E a r : n o i t

- 5 0 / 4 0 / 0 6 ` , l l u n , ' r a b b a J ` , ' d a m h A ` &lt; t r e s n I ' P M E o t n i &gt; 4 , l l u n , 0 0 0 8 2 , F , L E E Y O .

i r g e t n i y t i t n e e h t s e t a l o i v n o i t r e s n i s i h T t a r t s n o c y i . ) l l u n = N S S ( s t n

<!-- formula-not-decoded -->

e k e h t s e t a l o i v n o i t r e s n i s i h T y ) s t s i x e y d a e r l a s i 7 7 7 7 8 8 9 9 9 = N S S ( t n i a r t s n o c .

- t r e s n I , M , ' 5 0 / 4 0 / 0 6 ` , ' 9 8 9 8 7 6 7 7 6 ` , ' r a b b a J ` , ' d a m h A ` &lt; 2 3 4 5 6 7 8 9 ` , 0 0 0 8 2 1 , ' 7&gt; P M E o t n i LOY . E E

<!-- page-break -->

s i h T n o i t r e s n i s e t a l o i v l a i t n e r e f e r n i te i r g ty ( N D , 7 = O e h t re s i o n E B M U N P E D R 7 = in o i t a l e r T N E M T R A P E D n) .

- I s n r e t ' 7 8 9 7 8 9 7 8 9 ` , ' r a b b a J ` , ' d a m h A ` &lt; , 4 , l l u n , 0 0 8 2 , M , ' 9 2 / 3 0 / 9 6 ` &gt; t n i o P M E LOY . E E

e l b a t p e c c a s i n o i t r e s n i s i h T .

## t e l e D e h T e p O e n o i t a r

l n o e t a l o i v n a c n o i t a r e p o s i h T y t i r g e t n i l a i t n e r e f e r y. e p o e t e l e d f o s e l p m a x E a r i t o : n

- = N S S h t i w e l p u t N O \_ S K R O W e h t e t e l e D ` 9 8 7 6 5 4 3 2 1 ' a 1 = O N P d n

e l b a t p e c c a s i n o i t e l e d s i h T

- . .
- = N S S h t i w e l p u t E E Y O L P M E e h t e t e l e D ` 7 7 7 7 8 8 9 9 9 ' .

s i h t o t r e f e r N O \_ S K R O W n i s e l p u t ( y t i r g e t n i l a i t n e r e f e r e h t s e t a l o i v n o i t e l e d s i h T . ) e l p u t

- = N S S h t i w e l p u t E E Y O L P M E e h t e t e l e D ` 5 5 5 5 4 4 3 3 3 ' .

s i h T n o i t e l e d s e t a l o i v l a i t n e r e f e r t n i e i r g ty p u t ( l s e n i M E P , E E Y O L P E D AR , T N E M T

) e l p u t s i h t o t r e f e r T N E D N E P E D d n a , N O \_ S K R O W .

## h T e e t a d p U Ope n o i t a r

y t a t a d t c e r r o c e h t f o e b t s u m e u l a v w e n e h T p e an n i a m o d d . a d p u f o s e l p m a x E t p o e era : n o i t

- P M E e h t f o Y R A L A S e h t e t a d p U L 0 0 0 8 2 o t ' 7 7 7 7 8 8 9 9 9 ` = N S S h t i w e l p u t E E Y O

b a t p e c c a s i e t a d p u s i h T e

- . l .
- P M E e h t f o O N D e h t e t a d p U L 7 7 7 7 8 8 9 9 9 ` = N S S h t i w e l p u t E E Y O ' . 7 o t

s i h T e t a d p u s e t a l o i v l a i t n e r e f e r i r g e t n i ty t ( h r e e is o n 7 = R E B M U N D n i DEPARTM T N E rela n o i t ).

- t a d p U e h t e SSN f o e h t P M E LO E E Y e l p u t t i w h S S = N ` 7 7 7 7 8 8 9 9 9 ' o t ` 1 2 3 4 5 6 7 8 9 '.

## . 2 L Q S n i s n o i t c n u f e t a g e r g g a n o e t o n a e t i r W L Q S n i s w e i V d n a w . s e l p m a x e h t i

s k r a M 4 y l u J / n u J ( 2 ) 5 1 0 2 y l u J / e n u J &amp; 4 1 0

## S N O I T C N U F E T A G E R G G A ( )

s n o i t c n u F h c u s s a , M U S U O C N , T , E G A R E V A M , N I X A M e r a f o t n e d e i l p p a to e s ts f o s e u l a v s n o i t a c i l p p a e s a b a t a d n i s e l p u t f o s t e s r o

n i p u o r g &lt; g t u b i r t t a es&gt; (R) l n o i t c n u f &lt; i &gt; t s l a n o i t p o e r a s e t u b i r t t a g n i p u o r g e h T

<!-- page-break -->

: ) d e d e e n g n i p u o r g o n ( s e e y o l p m e l l a f o y r a l a s e g a r e v a e h t e v e i r t e R : 1 e l p m a x E

<!-- formula-not-decoded -->

e l p m a x E : 2 r o F h c a e dep e m t r a n , t r t e r i e v e h t e e d p t n e m t r a , r e b m u n the u n m r e b of em l p oye , s e

d n a

r a l a s e g a r e v a e h t y : ) t n e m t r a p e d e h t n i (

<!-- formula-not-decoded -->

s i O N D c l l a e h t d e p u o r g i t t a g n ri t u b e e e v o b a e h t n i x e l p m a

## L Q S s w e i V

n o d e s a b e l b a t l a u t r i v a s i w e i v a , L Q S n I t l u s e r e h t - . t n e m e t a t s L Q S n a f o t e s

e r o m r o e n o m o r f s d l e i f e r a w e i v a n i s d l e i f e h T . e l b a t l a e r a e k i l t s u j , s n m u l o c d n a s w o r s n i a t n o c w e i v A . e s a b a t a d e h t n i s e l b a t l a e r

S A e m a n \_ w e i v W E I V E T A E R C

) s ( e m a n \_ n m u l o c T C E L E S

e m a n \_ e l b a t M O R F

n o i t i d n o c E R E H W

L Q S s e l p m a x E W E I V E T A E R C

S A ] t s i L t c u d o r P t n e r r u C [ W E I V E T A E R C

e m a N t c u d o r P , D I t c u d o r P T C E L E S

s t c u d o r P M O R F

o N = d e u n i t n o c s i

D E R E H W

## 3) w o H s i a w e i v d e t a e r c and ? d e p p o r d t a h W p o r b s m e l e r a a i c o s s a t d e wi h t updat n i g f o s w e i v ? 1 1 c e D ( n a J / 12) / 4 1 c e D s k r a m 6 ( ) 5 1 n a J

n i s a o t s r e f e r w e i v A g l b a t r e h t o m o r f d e v i r e d s i t a h t e l b a t e l es

V E T A E R C I R O W W E K O \_ S N1

M A N L , E M A N F T C E L E S S A E S R U O H , E M A N P ,

P M E M O R F L , T C E J O R P , E E Y O N S S E = N S S E R E H W N O \_ S K R O W A D N R E B M U N P = O N P

o l e b n w o h s s a d e p p o r d e b n a c w e i v A w

V P O R D I 1 N O \_ S K R O W W E

<!-- page-break -->

## s w e i V f o g n i t a d p U

g n i t a d p U e h t s w e i v n a c e b d e t a c i l p m o c d n a b m a ig u o u s n I , l a r e n e g n a e t a d p u n o a w e i v n o d e n i f e d n o a i s n e l g t e l b a o / w any g g a r e t a g e n u f c s n o i t n a c e b e p p a m d o t n a up a d te n o t e h b e s a e l b a t A w e i v h t i w a e l g n i s f e d i g n i n e l b a t s i p u d e l b a t a f i e w w e i v n o c ta n i PK r o CK f o h t e a b s e ta l b e View n o e l p i t l u m s e l b a t s u ing j n i o s e r a t o n a d p u ta l b e w e i V d e n i f e d i s u ng e r a e t a g e r g g a / g n i p u o r g n e l b a t a d p u t o

- 4) t a h W s i d e d d e b m e Q S L? h t i W n a e l p m a x e n i a l p x e o h w w d l u o u o y t c e n n o C o t a s d r o c e r h c t e f , e s a b a t a d a nd di y a l p s . o r p d e r o t s f o t p e c n o c e h t n i a l p x e o s l A c n i e r u d e f e i r b . c e D ( 1 1 n a J / 13 4 1 0 2 n a J / ) ) 5 1 n a J / 4 1 c e D s k r a m 0 1 (

e h T d e d d e b m e SQL st t n e m e t a s i h s i u g n i t s i d ed m o r f r p o i m m a r g ng la e g a u g n s t n e m e t a t s b g n i x i f e r p y t i h t i w a l a i c e p s r e t c a r a h c r o a m m o c nd o s t a h t a o s s e c o r p e r p r n a c ex t c a r t h t e S t a t s L Q eme . s t n n I L P /I e h t s d r o w y e k C E X E L Q S e c e r p de any Q S L . t n e m e t a t s n I , s n o i t a t n e m e l p m i e m o s L Q S s s t n e m e t a t e r a s a p s d e as t e m a r a p e s r n i e r u d e c o r p . s l l a c e W l l i w e s u L A C S A P s a e h t t s o h p g n i m m a r g o r a l ngua , e g and a " $ " si n g o t i t n e d i fy SQL e t a t s m s t n e n i e h t m a r g o r p . n i h t i W n a d e d d e b m e SQL , d n a m m o c e w may e f e r r o t r p og m a r e l b a i r a v , s h w i h c r a e d e x i f e r p by a " % " n g i s . e h T r p o r e m m a r g d l u o h s e r a l c e d r p o m a r g v i r a a s e l b o t mat h c h t e a d ta t e p y s f o h t e a t a d b s a e s e t u b i r t t a h t t a h t e r p ogram will r p o . s s e c e s e h T r p o m a r g s e l b a i r a v may or a m y e r a t a h t s e m a n e v a h t o n n i d n o p s e r r o c r i e h t o t l a c i t n e d i g s e t u b i r t t a

p m a x E l : e e t i r W a r p o m a r g e s g t n e m o l ( op) t a h t s d a e r a c o s i l a y t i r u c e s e b m u n r d n a s t n i r p t u o e m o s n o i t a m r o f n i m o r f e h t r r o c n o p s e g n i d P M E E E Y O L e l p u t

```
1 E : = : P O O L ; ' Y ' e l i h w P O O L = ' Y ' o d n i g e b t u p n i ' ( n l e t i r w l a i c o s y t i r u c e s ; ) ' : r e b m u n ; ) M U N _ C E S _ C O S ( n l d a e r T C E L E S $ , E M A N F , T I N I M , E M A N L , N S S , E T A D B E R D D A S O T N I , E M A N F . E % , T I N I M . E % , E M A N L . E % , N S S . E % , E T A D B . E % , S S E R D D A . E % S . E % L A Y R A M O R F E E Y O L P M E E R E H W M U N _ C E S _ C O S % = N S S ; ( n l e t i r w , E M A N F . E , T I N I M . E , E M A N L . E , N S S . E
```

A D B . E T

<!-- page-break -->

e r o m ' ( n l e t i r w l a i c o s y t i r u c e s s r e b m u n Y ( r o ? ) N ; ) '

) P O O L ( n l d a e r

; d n e

e c o r p d e r o t S d s e r u a b a t a d e h t e r a s u d o m m a r g o r p e l o r p , s e c e r u d e s r o t s e r a t a h t s n o i t c n u f e r o d n a d b d e t u c e x e y . r e v r e s e s a b a t a d e h t t a S M B D e h t

## u d e c o r p d e r o t s f o s e g a t n a v d A r s e

1. l s u o e n a t l u m i s s m a r g o r p n o i t a c i l p p a y n a m y b d e k o v n i e b n a c t I y .
2. I r e v r e s d n a t n e i l c w / b t s o c n o i t a c i n u m m o c d n a r e f s n a r t a t a d e c u d e r n a c t .
3. t i n a c a h n e n e c e d o m i l ng r e w o p d e d i v o r p by vi s w e by i w o l l a ng e r o m c x e l p m o ty s e p . a t a d d e v i r e d f o
4. ) 5 n i a l p x E e h t s a t n y x f o a T C E L E S a t s t t n e m e in Q S e t i r w . L e h t Q S L query for h t e f l l o w o i g n l a n o i t a l e r g n o i s s e r p x e a r b e . / Y A M ( J Y L U 3 1 0 2 4 1 0 2 / ) ) 5 1 n a J / 4 1 c e D s k r a M 4 (
5. r d d a , e t a d b * l p m E ( ' h t i m s ' = e m a n L d n a ' n h o J ' = e m a n F σ ( s s e o ) ) e e y

S T C E L E S e h T t e t a m t n e

s e h T y : s i d n a m m o c s i h t f o x a t n

L E S E T C

u b i r t t a &lt; te s i l t&gt;

FROM

s i l e l b a t &lt; t&gt;

E H W RE

i t i d n o C &lt; o &gt; n ;

: E S L S S E R D D A , E T A D B T C E

F M O R P M E L E E Y O

D N A ' n h o J ' = E M A N F E R E H W D N A ' B ' = T I N I M L M S ' = E M A N I H T '

## 6) e l p m a x e n a h t i w d n a m m o c p o r d e h t n i a l p x E

/ Y A M ( J Y L U 3 1 0 2 )

f e d s t i d n a ) e l b a t e s a b ( n o i t a l e r a e v o m e r o t d e s U i n o i t i n

e h T n o i t a l e r n a c o n r e g n o l e b d e s u n i u q e , s e i r up , s e t a d r o any t o r e h comm d n a s e c n i s t i s e r e g n o l o n n o i t p i r c s e d s t s i x

e l p m a x E :

E L B A T P O R D ; T N E D N E P E D

## . 7 s e l b a t g n i w o l l o f e h t r e d i s n o C :

A S , E M A N C , E M A N P ( S K R O W L ) Y R A

) Y T I C , T E E R T S , E M A N P ( E V I L

I D E T A C O L - C , E M A N C ( N I I ) Y T

M ( y a J / y l u 3 1 0 2 C E D , 4 1 0 2 n a J / )

<!-- page-break -->

## N P ( R E G A N M A N R G M , E M A ) E M

r e u q l q s e h t e t i r W y : g n i w o l l o f e h t r o f

- e h t d n i F ) i t i c n i e v i l o h w s n o s r e p l l a f o s e m a n y . ' i a b m u m '
- s r d n a 0 0 0 , 0 3 . s r n e e w t e b s i y r a l a s e s o h w ' s i s o f n I f o s n o s r e p l l a f o s e m a n e h t e v e i r t e R ) i i . 0 0 0 , 0 5
- t i c e m a s e h t n i k r o w d n a e v i l o h w s n o s r e p l l a f o s e m a n e h t d n i F ) i i i y.
- o h w e l p o e p e h t f o s e m a n e h t t s i l ) v i e h t s e i t i c e h t h t i w g n o l a ' o r p i w ' r o f k r o w y . n i e v i l
- v) r a l a s e g a r e v a e h t d n i f y ' l l a f o I ' s n a i s o f n

L , R E G A N M m o r f e m a n P t c e l e S I C e r e h w E V I A B M U M ' = Y T I ; '

t c e l e S e m a n p m o r f MN R E G A M ,W K R O S W W E H RE W a n p . me =M. n p ame A S d n a L Y R A IN

e r e h w s k r o W m o r f y r a l a s t c e l e S r a l a s d n a 0 0 0 0 3 &gt; y r a l a s ( y ) 0 0 0 0 5 &lt;

l e S ect m a n p e m o r f E G A N M R E V I L , M L K R O W , W e r e h w

e m a n P . L = e m a n p . M d n a i C ty ( n i t c e l e S e m a n p r f m o O L C D E T A where t i C y ; ' y a b m o B ' =

t c e l e S y t i c , e m a n P m o r f s k r o W d e t a c o L , W - n i 1 L e r e h w W e m a n p . = p . 1 L na e m a d n N C A E M ' = . ' o r p i w

v a t c e l e S r a l a S ( g y s o f n i ' = E M A N C e r e h w W s k r o W m o r f ) y ; ' s

## 8 ) L g n i m m a r g o r P B D o t s e h c a o r p p a e h t t s i . n i m m a r g o r P B D n i d e v l o v n i s e u s s i n i a M g?

c e D ( n a J / 1 1 4 1 0 2 n a J / )

d e d d e b m E c m m o a : s d n

- l a r e n e g a n i d e d d e b m e e r a s d n a m m o c e s a b a t a D - n a l g n i m m a r g o r p e s o p r u p g e g a u
- r b i L r a y : s n o i t c n u f e s a b a t a d f o
- n a l t s o h e h t o t e l b a l i a v A g n a s a n w o n k ; s l l a c e s a b a t a d r o f e g a u I P A
- I P A e c a f r e t n I m a r g o r P n o i t a c i l p p A r o f s d r a d n a t s
- l l u f , w e n d n a r b A - a u g n a l d e g d e l f ge
- m s i m e c n a d e p m i s e z i m i n i M atch

## 9) t a h W s i e c n e d e p m I h c t a m s i M ? m e l b o r p h c i h W f o e h t e e r h t g n i m m a r g o r p r p p a o c a h s e m i n i m i ? m e l b o r p s i h t s e z 1 c e D ( 2 n a J / 13)

- In s e i t i l i b i t a p m o c n e e w t e b a t s o h r p ogr g n i m m a lan u g a e g n a d e h t da e s a b a t mod , l e t , . g . e y h c a e r o f g n i d n i b w e n a s e r i u q e r ; s e i t i l i b i t a p m o c n i d n a h c t a m s i m e p e g a u g n a l

<!-- page-break -->

- t e s s v . d r o c e r - t a -ai s s e c o r p e m i t n g
- l a i c e p s d e e n s r o t a r g e t n i e u q r e v o p o o l o t r s e u l a v l a u d i v i d n i e t a l u p i n a m d n a s t l u s e r y

## : s p e t S

- o r p t n e i l C gram op n o i t c e n n o c a s n e e v r e s e s a b a t a d e h t o t r
- o r p t n e i l C gram s t i m b u s q a d p u r o / d n a o t s e i r e u t s e h t e b a t a d a e s
- n e h W e s a b a t a d s s e c c a s i o n r e g n o l , d e d e e n c t n e i l g o r p ram s e s o l c (t e t a n i m r e s) e h t n n o c c e n o i t

## L Q S d e d d e b m E

- t s o M SQL s t n e m e t a t s n a c e b d e b m e d d e n i a l a r e n e g - o p r u p se t s o h r p o g n i m m a r g a l n u g a e g a v a J , C , L O B O C s a h c u s
- n A d e d d e b m e L Q S t n e m e t a t s s i i d d e h s i u g n i t s m o r f e h t t s o h u g n a l a e g e t a t s m s t n e b y g n i s o l c n e t i bet n e e w EX C E L Q S r o C E X E L Q S N I G E B d n a a matchi g n D N E - C E X E r o

L Q S C E X E E D N s r o ( e i m c ) n o l o

- a m x a t n y S y e g a u g n a l h t i w y r a v
- l a u s u ) s e g a u g n a l h t o b n i d e s u ( s e l b a i r a v d e r a h S l h t i w d e x i f e r p y L Q S n i ) : ( n o l o c a

## 0 1 ) L Q S n i d e n i f e d s n o i t r e s s a d n a s r e g g i r T e r a w o H ? n i a l p x E 1 1 c e D ( n a J / 13)

t s n o C a r s n o i t r e s s A s a s t n i

l a r e n e G : s t n i a r t s n o c s t n i a r t s n o c t a h t o d t o n t i f n i e h t c i s a b L Q S a c t g e o s e i r d e t n e s e r p ( n i e M cha : m s i n N O I T R E S S A T A E R C s t n e n o p m o C d u l c n i e :

- a c , e m a n t n i a r t s n o
- b d e w o l l o f y , K C E H C
- b d e w o l l o f y n o i t i d n o c a

e h T a l a s ry f o an p m e o l e e y t s u m t o n be a e r g t r e a h t n e h t s a l a ry f o t e h manager f o e h t o l p m e e h t t a h t t n e m t r a p e d y ' ' r o f s k r o w e e

N O I T R E S S A T A E R C A L A S R R T S N O C \_ Y A T N I

S T S I X E T O N ( K C E H C T C E L E S ( *

M E , E E E Y O L P M E M O R F P , M E E Y O L

E D P T R A M D T N E

E H W R &gt; Y R A L A S . E E M A L A S . R D N A Y

. D = O N D . E N D N A R E B M U

) ) N S S . M = N S S R G M . D

<!-- page-break -->

Q S L Tr : s r e g g i

: g n i w o l l o f e h t e d u l c n i d n a s n o i t r e s s a o t r a l i m i s x a t n y s a n i d e s s e r p x e e r a s r e g g i r T

t n e v E

, d e t e l e d , t r e s n i n a s a h c u S r e p o e t a d p u r o a n o i t

o i t i d n o C n

n o i t c A

d e i f s i t a s s i n o i t i d n o c e h t n e h w n e k a t e b o T

A r e g g i r t to e r a p m o c n a l p m e o ' e e y s a l a s ry o t hi r e h / s o s i v r e p u s r u d ring ins r e t or t a d p u e r e p o a : s n o i t

N I R E G G I R T E T A E R C F U S \_ M R O P R O S I V R E

E B F F O E T A D P U R O T R E S N I E R O

U S , Y R A L A S PE M E N O N S S \_ R O S I V R P E Y O L E

F W O R H C A E R O

E H W N

Y R A L A S T C E L E S ( &gt; Y R A L A S . W E N ( F M E M O R P E E Y O L

W E N = N S S E R E H W S . UP O S I V R E R ) ) N S S \_

U S \_ M R O F N I P U S . W E N ( R O S I V R E P ) N S S . W E N , N S S \_ R O S I V R E ;

- 1 1 i s e h t s s u c s i D ) g f i c e p s o t n o i t r e s s a n a e t i r W ? n o i t r e s s a f o e c n a c i f i n y h c u s t n i a r t s n o c t e h t t a h r a l a s e h t n a h t r e t a e r g e b t o n t s u m e e y o l p m e n a f o y r a l a s y e h t f o r e g a n a m e h t f o t a h t t n e m t r a p e d o l p m e y r o f s k r o w s e e ? N A J / C E D ( 3 1 0 2 N A J / - 4 1 0 2 )

CREAT ASSERTION SALARY\_CONSTRAI T N CHEC ( K N T O EXISTS (SELEC T *FROM EMPL E Y O E , E EMPLO E E Y , M E D PAR M T T N E DWHER E E.SALARY &gt; M.SALARY AND . EDNO=D.N M U BER A D N DM . GRSSN=M.SS ) N )

Q S f o e c e i p a s i n o i t r e s s a n A L n i e b n o i t c a s p o t s t i r o d e i f s i t a s s i n o i t i d n o c a e r u s s e k a m h c i h w g take n a n o c e j b o e s a b a t a d t . I e h t n e v e r o e l b a t e l o h w e h t t u o g n i k c o l n a e m d l u o c t l o h w e data s a b e .

n i s u f n o c e r o m s r e t t a m e k a m o T g - g i r t a g t n i a r t s n o c k c e h c a e c r o f n e o t d e s u e b d l u o c r e a n i d n e m o s g n i w o l l a y b ( n o i t r e s s a n a f o e c a l p e h t e k a t n a c s B D y n u e d o c n u r o t u o - n i e b e l b a t e h t o t d e t a l e r g d e i f i d o m ) . s r e n n i g e b r o f e k a t s i m n o m m o c A r t a n e h w t n i a r t s n o c k c e h c a e s u o t s i i s i r e g g r o d e r i u q e r g i r t a g r t s n o c k c e h c a n e h w r e a i u q e r s i t n i r . d e

<!-- page-break -->

## M e c n e d n e p m I s i t a h W . 2 1 i h c t a m s ? n i a l p x E

## N A J / C E D ( 3 1 0 2 )

0 7 9 1 n i d e p o l e v e d s e g a u g n a l y r e u q f o t p e c n o c e h T - i l a s r e v i n u c i t a m g a r p o n d e m u s s a s e i t ty. , r e v e w o H a c i l p p a l a e r n i e l b a t i v e n i s i y t i l a s r e v i n u h c u s y l l a u t n e v e e s u a c e b t a t a h t n o i t p m u s s a n a s a w e r e h t , s n o i r e u q y n a l g a u g l a s r e v i n u a n i d e d d e b m e e b o t s i t a h t " e g a u g n a l b u s " a s i e n a l g n i m m a r g o r p g a u g A . e b u s " - n a l g a t a d a o t s s e c c a e h t s e n i m r e t e d " e g a u l n o e s a b y. r e h T e o t s f e b o t s a h n o i t a c i l p p a e r i t n e e h t t a n i d e m m a r g o r p y e g a u g n a l g n i m m a r g o r p l a c i p . r e u q a g n i n i o j s e r i u q e r n o i t p m u s s a s i h T y e g a u g n a l a w a h c u s n i e g a u g n a l g n i m m a r g o r p a h t i w y : t a h t

i r e u Q e n a c s be g o r p e d i s n i d e s u r ; s m a

a r a p e b n a c s e i r e u Q ; s m a r g o r p n i h t i w d e t a l u c l a c s e u l a v h g u o r h t d e z i r e t e m

o r p o t d e s s a p e b o t e r a s e i r e u q f o s t l u s e R g s m a r .

i s e s u a c s t p e c n o c e g a u g n a l n e e w t e b e c n e r e f f i D g i f i n a c n i s e i t l u c i f f i d l a c i n h c e t t n n i h s i l p m o c c a g n n o c f o d n i k s i h t c e n o i t . r e t u p m o c d n a s r e m m a r g o r p f o t o l A s l a n o i s s e f o r p were a b d e t n i o p p a s i d o s l y e h t f o n o i t a d a r g e d l a u t p e c n o c d n a c i t e h t s e a , l a c i n h c e t e h t g n i m m a r g o r p n e m n o r i v n e t . l n o m m o c s i n o i t a d a r g e d s i h T y s a o t d e r r e f e r e c n a d e p m i h c t a m s i m . t s i h T r e e r a t a h t s e r u t a e f s u o e g a t n a v d a s i d f o h c n u b a s e t o n e d m l p m i d e i b e h t y a u g n a l g n i m m a r g o r p a h t i w ) L Q S r a l u c i t r a p n i ( e g a u g n a l y r e u q a f o x i m c i t c e l c e g s a h c u s ( e ) a v a J r o + + C , C . w o l e B e w u t a e f e s e h t t n e m m o c d n a t s i l e r s.

x a t n y S : I d n a s e l y t s g n i m m a r g o r p o w t e s u t s u m r e m m a r g o r p e h t e d o c e m a s e h t n t s u m f f i d o w t w o l l o f g t n e r e r s r a m m a . l t n e r e f f i d d e t o n e d e r a s t p e c n o c r a l i m i S y , e c n a t s n i r o f ( Q S n i , " … " n i h t i w n e t t i r w e r a C n i s g n i r t s L - d e t o n e d e r a s t p e c n o c t n e r e f f i d d n a ) ' … ' l r a l i m i s y Q S n i , t n e m n g i s s a n a s e t o n e d = C n i , e c n a t s n i r o f ( L - . ) n o s i r a p m o c a

n i p y T g T : y d d n a s e p r e u q y b d e m u s s a s e p y t f o s n o i t a t o n e y g n i m m a r g o r p d n a s e g a u g n a l f f i d r e , a s a e l u r . c t e , n a e l o o b , l a e r , r e g e t n i s a h c u s s e p y t c i m o t a s n r e c n o c s i h T . t c i m o t a f o n o i t a t n e s e r p e R y n i m m a r g o r p n i s e p g n a l g e b n a c s e s a b a t a d n i d n a s e g a u n e v e , t n e r e f f i d y l t n a c i f i n g i s t e h t f i y e k e m a s e h t y b d e t o n e d e r a s e p y g . e , d r o w . g e t n i er . A e m o s y l p m i t h g i m d n a e l b i s s o p m i e b d l u o c s e p y t h c u s n e e w t e b n o i s r e v n o c s s e l s s o l

o f r e p rmanc d a e h r e v o e . a t a d c i s a b a ( s e l b a t s a h c u s , s e p y t x e l p m o c s n r e c n o c o s l a s i h T e p y t Q S n i r o t c u r t s n o c L e s b a , o r p n i t n g n i m m a r g n a l g ) s e g a u . m a r g o r p r a l u p o P m s e g a u g n a l g n i t ) e m i t e l i p m o c ( c i t a t s e c u d o r t n i y i h w , g n i k c e h c e p c . e e l b i s s o p m i s i h g . Q S n i L e s u a c e b ( r e u q y d n o d e s a b e r a s e g a u g n a l y n i d n i b c i t a t s n a h t r e h t a r c i m a n g . )

e S m g i d a r a p e g a u g n a l d n a s c i t n a ms o c e h T : a u g n a l h t o b f o s c i t n a m e s f o t p e c n g s i s e l l a t o t y t n e r e f f i d . ( e l y t s e v i t a r a l c e d e h t n o d e s a b e r a s e g a u g n a l y r e u Q t a h w b o t s i e e r d e v e i r t r e h t a r n a h t o h w s e v i t a r e p m i e h t n o d e s a b e r a s e g a u g n a l g n i m m a r g o r p e l i h w , ) tyl a ( e e c n e u q e s h w , e n i h c a m a o t s d n a m m o c f o c c a h c i o s e h s i l p m t a h w ).

<!-- page-break -->

c a r t s b A t l e v e l n o i t i r o j a m m o r f s r e m m a r g o r p e h t e e r f s e g a u g n a l y r e u Q : y e h t f o s l i a t e d r o , e c n a t s n i r o f , n o i t a t n e m e l p m i d n a n o i t a z i n a g r o a t a d g n i n r e c n o c g f o n o i t a z i n a , s n o i t c e l l o c c n e s e r p e r o a s b e i d n i e c n c . c t e , s e I u g n a l g n i m m a r g o r p n l l a u s u s l i a t e d e s e h t s e g a y a m h g u o h t l a ( t i c i l p x e e r a y b d e r e v o c e b y . ) s e i r a r b i l e m o s

e s a h p g n i d n i B s d n a m s i n a h c e ms r e u Q : y n u r ( e t a l n o d e s a b e r a s e g a u g n a l - ) e m i t n a l g n i m m a r g o r p e l i h w , s e i r e u q n i r u c c o t a h t s e m a n e h t l l a f o g n i d n i b g n o d e s a b e r a s e g a u l r a e y ( n i k n i l d n a e l i p m o c g g n i d n i b ) e m i t . p a f o w e i v f o t n i o p e h t m o r f , s u h T r g o a r s e i r e u q , m l p m i s e r a y n i r t s g . s r e t c a r a h c f o s

l u r e p o c s d n a s e c a p s e m a N es n i r r u c c o s e m a n e e s t o n o d s e i r e u Q : g o r p n i g s m a r and / v v . l l a u t n e v e e s u a c e B y e s r e t n i e m o s e b t s u m e r e h t c i t . e ( s e c a p s e m a n e s e h t f o n o g . o r p gra m s n w o h t i w , s e i t i l i c a f l a n o i t i d d a ) s e i r e u q e z i r e t e m a r a p t s u m s e l b a i r a v y d n a s c i t n a m e s , x a t n a r p g r e r a , s c i t a m e i u q r t i l i b i g e l d n a e z i s e h t r o f n e d r u b e h t e r a s e i t i l i c a f e s e h T . d e y e h t f o m a r g o r p e d o c . a r g o r p n i , r e v o e r o M a g r o e r a s e p o c s e m a n s e g a u g n a l g n i m m niz d e l l a c i h c r a r e i h y b d e s s e c o r p d n a y s k c a t s n o d e s a b s e l u r l a i c e p s . b d e r o n g i e r a s e l u r e s e h T y a r e u q y n a l g e g a u . . e s d a e l s i h T g . c e r u d e c o r p e v i s r u c e r h t i w s m e l b o r p o t a ( s l l a l l e w - n w o n k t a h t s r o s r u c L Q S s n r e c n o c e l p m a x e l e r e v e s y t i l i b i s s o p e h t e c u d e r y ) n o i s r u c e r f o . h t o n A er a t n a v d a s i d g n i r o t c a f e r c i t a m o t u a s n r e c n o c s e c a p s e m a n d e t a r a p e s f o e g r g o r p f o a h c i h w , s m b t o n n a c e e p f r i r e u q n o d e m r o es .

C e l l o c s n o i t e r o t s s e s a b a t a D : c l l o c e . e ( s n o i t g . y b d e s s e c o r p e r a h c i h w ) s e l b a t . s e i r e u q In l e r e v e s r o t n e s b a e r a s n o i t c e l l o c s e g a u g n a l g n i m m a r g o r p y d e t i m i l . s n o i t c e l l o c e c n e H d e n r u t e r b e b t s u m d n a e g a u g n a l g n i m m a r g o r p a n i s t r a p r e t n u o c t c e r i d o n e v a h s e i r e u q y b d e s s e c o r p y s n w o h t i w s t c u r t s n o c l a i c e p s y . s c i t n a m e s d n a x a t n

s e u l a v l l u N D : a r e u q r i e h t d n a s e s a b a t y n a l g r o f s e r u t a e f d e z i l a i c e p s e v a h s e g a u n i r o t s g n i s s e c o r p d n a g v l l u n a s e u l . n i m m a r g o r p n i t n e s b a e r a s e r u t a e f h c u S g n a l g s u h t , s e g a u e m o s r t n i e b t s u m s e t u t i t s b u s o u d c d e . F n a c e s a b a t a d l a n o i t a l e r a n i e u l a v e m o s f i , e c n a t s n i r o e b n a l g n i m m a r g o r p a o t t i g n i p p a m , l l u n g n i r o t s r o f e n o : s e l b a i r a v o w t s e r i u q e r e g a u g n i r o t s r o f e n o r e h t o n a d n a l l u n t u o b a n o i t a m r o f n i g h t e u l a v e.

<!-- page-break -->

## 3 1 a l p s i d l l i w h c i h w w e i V e t a e r C ) y r a l a s l a t o t d n a g n i k r o w s e e y o l p m e f o o n , e m a n d e h t y h c a e f o n e m t r a p e d ? t N A J / C E D ( 3 1 0 2 3 1 0 2 y l u J / )

V E T A E R C I R O W W E K O \_ S N1

E S S A L A S , S R U O H , E M A N P , E M A N L , E M A N F T C E L Y R A

P M E M O R F L N S S E = N S S E R E H W N O \_ S K R O W , T C E J O R P , E E Y O A D N . R E B M U N P = O N P

```
) a L Q S d e d d e b m E ; 1 = p o o l h w i e l ( ) p o o l { o r p m ; ) n s s , " : N S S r e t n E " ( t p Q S C E X E L t c e l e s , E M A N F L A S , S S E R D D A , E M A N L Y R A a l a s : , s s e r d d a : , e m a n l : , e m a n f : o t n i r y P M E m o r f L ; n s s : = = N S S e r e h w E E Y O Q S ( f i L ; ) … , e m a n f ( f t n i r p ) 0 = = E D O C s i x e t o n s e o d N S S " ( f t n i r p e s l e t : " ; ) n s s , ; ) p o o l , " : ) o n = 0 , s e y = 1 ( ? N S S e r o M " ( t p m o r p D N E - C E X E } A cur o s r o t a r e t i ( p u t e l p i t l u m s s e c o r p o t d e d e e n s i ) r l s e F H C T E o s r u c e h t e v o m s d n a m m o c r e h t o t t x e n tuple
```

R O S R U C E S O L C n i s s e c o r p e h t t a h t s e t a c i d n i g r e u q f o y d e t e l p m o c n e e b s a h s t l u s e r n i h t e s e h t l l A g n a l a n i d e d d e b m e e r a s g . e g a u

## U T I N - 6

## n g i s e D e s a b a t a D - 1

- 1 ) t a h W is e h t d e e n r o f ? n o i t a z i l a m r o n n i a l p x E e h t d n o c e s , t s r i f n a d th r i d o n l a m r f s m r o a x e h t i w m s e l p . Y L U J / N U J ( 3 1 0 2 )

## f o e s o p r u p e h T r o n m n o i t a z i l a .

- r h t i w d e t a i c o s s a s m e l b o r p e h T e d t n a d n u d ata.
- e h T n o i t a c i f i t n e d i f o s u o i r a v t s e p y of e t a d p u n a o s e i l a m c u s h s a i s n ert , n o i dele i t , n o

<!-- page-break -->

d n a m o n a n o i t a c i f i d o m a i l e . s

- t i l a u q r o s s e n e t a i r p o r p p a e h t e z i n g o c e r o t w o H y i s e d e h t f o g . s n o i t a l e r f o n
- e h T t p e c n o c f o u f n l a n o i t c n e d n e p e d c , y e h t i a m n l o o t r o f g n i r u s a e m e h t e t a i r p o r p p a ness e t u b i r t t a f o g n i p u o r g . s n o i t a l e r n i s
- w o H u f n l a n o i t c e d p s e i c n e d n e n a c e b e s u d o t r g o p u t a t u b i r tes o t n i r s n o i t a l e t a h t are in a o n n w o n k rma o f l r . m
- l a m r o n e n i f e d o t w o H f r o f s m r o r . s n o i t a l e
- o n f o s s e c o r p e h t e k a t r e d n u o t w o H rma n o i t a z i l .
- w o H o t i t n e d i fy the mo t s n o m m o c ly us d e o n r l a m , s m r o f n e m a ly s r i f t 1 ( N , ) F s d n o c e o B d n a , s m r o f l a m r o n ) F N 3 ( d r i h t d n a , ) F N 2 ( y e c - ) F N C B ( m r o f l a m r o n d d o C .
- f i t n e d i o t w o H y N 5 ( h t f i f d n a , ) F N 4 ( h t r u o f F . s m r o f l a m r o n )

## r o N t s r i F m r o F l a m ) F N 1 (

t s r i F l a m r o n m r o f s i w o n d e r e d i s n o c o t e b t r a p f o e h t l a m r o f n o i t i n i f e d f o a ; n o i t a l e r t s i h r o i l a c l , y t i s a w d e n i f e d o t w o l l a s i d d e u l a v i t l u m , s e t u b i r t t a o p m o c t i s e at r t t u b i , s e and t e h ir o c mb n i t a i . s n o I t s e t a t s t a h t e h t s n i a m o d f o s e t u b i r t t a t s u m e d u l c n i n o ly c i m o t a e l p m i s ( , i d n iv i s i bl ) e a v l s e u n a f o e u l a v e h t t a h t d n a y e b t s u m e l p u t a n i e t u b i r t t a m o r f e u l a v e l g n i s a e t u b i r t t a t a h t f o n i a m o d e h t . l a c i t c a r P : e l u R e t a n i m i l E " g n i t a e p e R G " , s p u o r . i e , . e k a m a e t a r a p e s e l b a t r o f h c a e t e s f o a l e r t d e r a m i r p a e l b a t h c a e e v i g d n a , s e t u b i r t t a y e k y.

l a m r o F : n o i t i n i f e D A n o i t a l e r s i n i t s r i f l a m r o n m r o f ) F N 1 ( f i n a d n o ly f i l a l r e d n u lying s m i pl l n o s e u l a v c i m o t a n i a t n o c s n i a m o d e y.

## r o F l a m r o N d n o c e S m ) F N 2 (

d n o c e S l a m r o n m r o f s i b d e s a n o e h t t p e c n o c f o l u f ly t c n u f i l a n o e d pe d n enc . y A l a n o i t c n u f X

Y s i a l u f ly u f n l a n o i t c e p e d d n n e cy is o m e r v l a f o any t a t u b i r t e A from X m n a e s th t a t e h n e d n e p e d cy s e o d t o n o h ld any mo . e r A n o i t a l e r s a m e h c s i n i 2NF f i every i r p n o n me t a tri e t u b n i n o i t a l e r s i l u f ly l a n o i t c n u f ly t n e d n e p e d n o e h t y r a m i r p key of e h t n o i t a l e r . t I o s l a n a c e b e t a t s e r d : s a a n o i t a l e r c s h a m e s i n i 2 F N f i every m i r p n o n e e t u b i r t t a n i n o i t a l e r s i t o n l a i t r a p ly e d p t n e d n e e k y n a n o y . n o i t a l e r e h t f o

l a c i t c a r P : e l u R e t a n i m i l E " t n a d n u d e R D a t a ," . i e , . f i an e t u b i r t t a d e p e nds n o n o ly part of a . e l b a t e t a r a p e s a o t t i e v o m e r , y e k d e u l a v i t l u m

l a m r o F : n o i t i n i f e D A n o i t a l e r is n i d n o c e s r o n m l a m r o f (2 F N ) f i n a d o l n y f i it is n i 1NF d n a r e v e y l l u f s i e t u b i r t t a y e k n o n y . y e k y r a m i r p e h t n o t n e d n e p e d



<!-- page-break -->



## F l a m r o N d r i h T o F N 3 ( m r )

d r i h T l a m r o n m r o f s i d e s a b n o t e h t p e c n o c f o a r t n i s i t e v e d p n e d n e cy. A n o i t c n u f l a n e d n e p e d cy X

- Y n i a s i n o i t a l e r a s n a r t i i t ve n e p e d d n e cy if e h t re is a se t of t a t e t u b i r s Z t a h t s i t o n a b u s set of an y key t f o he e r l , n o i t a d n a t o b h X d n a Z Z . d l o h Y In r e h t o wo , s d r a t a l e r i n o s i in F N 3 , f i v e n e h w c n e d n e p e d l a n o i t c n u f a r e y
- X A s d l o h n i e h t , n o i t a l e r r e h t i e ) a ( X s i a su k r e p ey f o e h t r a l e i t , n o or ) b ( A is a pr m i e r e h t f o e t u b i r t t a e n o i t a l .

s n m u l o C e t a n i m i l E " : e l u R l a c i t c a r P t o n e d n e p e D nt n o " , y e K , . e . i f i s e t u b i r t t a o d t o n o c t n u b i r te o t e v o m e r , y e k a f o n o i t p i r c s e d a t . e l b a t e t a r a p e s a o t m e h

l a m r o F : n o i t i n i f e D A n o i t a l e r is n i d r i h t l a m r o n m r o f ) F N 3 ( f i d n a n o ly f i t i s i n i F N 2 a d n ever y e k y r a m i r p e h t n o t n e d n e p e d y l e v i t i s n a r t n o n s i e t u b i r t t a y e k n o n y.



1 n i s i R : F N 1 . c i m o t a e r a s e u l a v n i a m o d l l a f f i F N

e k n o n y r e v e d n a F N 1 n i s i R f f i F N 2 n i s i R : F N 2 y e k e h t n o t n e d n e p e d y l l u f s i e t u b i r t t a y.

<!-- page-break -->

: F N 3 R s i n i F N 3 f f i R s i F N 2 d n a e v e ry k n o n ey e t u b i r t t a s i n o n - e v i t i s n a r t ly e d p t n e d n e n o the e k y

## 2 r o f n i n i a l p x E ) m g i s e d l a e h c s n o i t a l e r r o f s e n i l e d i u g n m s

## a . ( n a J / c e D 12)

t i l a u q f o s e r u s a e m l a m r o f n i r u o f e h T y a m e h c s n o i t a l e r r o f

- h t f o s c i t n a m e S e a t u b i r t t es
- n i c u d e R g e h t r s e l p u t n i s e u l a v t n a d n u d e
- s e u l a v l l u n e h t g n i c u d e R s e l p u t n i
- e h t g n i w o l l a s i D t i l i b i s s o p y s e l p u t s u o i r u p s g n i t a r e n e g f o

## s e t u b i r t t a s n o i t a l e r f o s c i t n a m e S

s e i f i c e p S w o h o t t e r p r e t n i e h t s e t u b i r t t a e u l a v s s d e r o t in a tu l p e of the e r la i t . n o n I h t o er d r o w s, a e n o o t e t a l e r e l p u t a n i e u l a v e t u b i r t t a e h t w o h n h t o er .

e n i l e d i u G 1: n g i s e D a n o i t a l e r a m e h c s o s t a h t t i s i a e sy o t n i a l p x e s t i g n i n a e m . o D t o n b m o c i e n n o i t a l e r e l g n i s a o t n i s e p y t p i h s n o i t a l e r d n a s e p y t y t i t n e e l p i t l u m m o r f s e t u b i r t t a . n i c u d e R g d n u d e r a t n



<!-- page-break -->

s e l p u t n i s e u l a v . a r o t s e v a S g u d i o v a d n a e c a p s e m o n a e t a d p a i l e . s

## e t a r t s u l l I ? d a b e r a y e h t y h W . s e i l a m o n a n o i t a c i f i d o m d n a , n o i t e l e d , n o i t r e s n i s s u c s i D . 3 ? e l p m a x e h t i w n a J ( ) 4 1 0 2

- I n o i t r e s n a m o n a i l s e .
- n o i t e l e D a m o n a i l e . s
- c i f i d o M a n o i t a m o n a s e i l .



o T t r e s n i a w e n l p m e oyee e l p u t o t n i , T P E D \_ P M E e w t s u m e d u l c n i ei r e h t t e h a t t i r t u b e a v u l s e fo o l p m e e h t t a h t t n e m t r a p e d t a h t r y . s l l u n r o , r o f s k r o w e e It s ' t l u c i f f i d o t s n i r e t a n w e e d p t n e m t r a t a h t h s a no l p m e oyee s a e y t in h t e M E \_ P E D PT e r la i t . n o e h T n o ly way o t o d h t is s i o t e c a l p l l u n a v l e u s n i t e h t a tri e t u b s r o f em l p oye . e s i h T e s u a c s e s u a c e b m e l b o r p a s i N S S a m i r p e h t r k y ey f o M E P , T P E D \_ d n a e h c a t p u le is e s o p p u s d o t p e r re t n e s o l p m e n a y e e t i t n e y - t i t n e t n e m t r a p e d a t o n y .

## n o i t e l e D s e i l a m o n A

f I e w e d l e t e m o r f P M E \_ T P E D n a l p m e o e e y p u t le t a h t s n e p p a h o t p e r res t n e h t e s a l t em l p oye g n i k r o w e r o f a r a l u c i t r a p , t n e m t r a p e d h t e a m r o f n i t n o i c n o c e g n i n r t a h t depa t r m t n e s i l s o t r f m o the data s a b e .

## n o i t a c i f i d o M s e i l a m o n A

In f i , T P E D \_ P M E we ch o f o e u l a v e h t e g n a n f o e t s e t u b i r t t a e h o f a pa e d r a l u c i t r p t n e m t r a - sa y th e r e g a n a m f o d n e m t r a p e t 5- we t s u m e t a d p u the s e l p u t f o l l a p m e loye s e w o h work in t t a h dep r a m t e . t n

e n i l e d i u G 2: g i s e D n e h t e s a b n o i t a l e r c s h s a m e so a h t t o n i r e s n i t , n o e d let , n o i r o m f i d o i t a c o i n s e i l a m o n a . r u c c o g n i c u d e R e h t l l u n s e u l a v n i s e l p u t . , . g . e f i % 0 1 f o y o l p m e e s e e v a h i f f o c , s e t i s i r e t t e b o t e v a h a e t a r a p e s , n o i t a l e r F O \_ P M E F , E C I r e h t a r n a h t n a e t u b i r t t a OFF E C I \_ R E B M U N n i P M E LOY . E E

<!-- page-break -->

e n i l e d i u G 3: d i o v A pl g n i c a s e t u b i r t t a in a b e s a t a l e r o i n e s o h w a v l s e u are mo t s ly l l u n . n i w o l l a s i D g . s e l p u t s u o i r u p s

s u o i r u p S p u t les - s e l p u t t a h t e r a t o n n i e h t r o i l a n i g r n o i t a l e t u b r e n e g t a d e by n a r u t a l join r b u s d e s o p m o c e d f o ela . s n o i t

m a x E O R P \_ P M E d n a S C O L \_ P M E o t n i J O R P \_ P M E e s o p m o c e d : e l p J . 1

e n i l e d i u G 4: n g i s e D e r l n o i t a s a m e h c s so t a h t th y e a c n e b n l a r u t a ly JO d e N I n o m i r p ary keys or e k n g i e r o f y a w a n i s y d e t a r e n e g e r a s e l p u t s u o i r u p s o n s e e t n a r a u g t a h t .



## 4) h W h c i l a m r o n m r o f s i d e s a b n o e h t c n o c p e t of a r t i s n t v i e depe d n en ? y c E l p x i a n w t i h F N 3 o t n i n o i t i s o p m o c e d e h t e l p m a x e n a y l u J ( 3 1 0 2 n a J / 0 2 13)

d r i h T l a m r o n m r o f s i d e s a b n o t e h t p e c n o c f o a r t n i s i t e v e d p n e d n e cy. A u f l a n o i t c n n e d n e p e d cy X

- Y n i a s i n o i t a l e r a s n a r t i i t ve n e p e d d n e cy if e h t re is a se t of t a t e t u b i r s Z t a h t s i t o n a b u s set of

an y key t f o he e r l , n o i t a d n a t o b h X d n a Z Z . d l o h Y In r e h t o wo , s d r a r t a l e i n o s i n i F N 3 , f i c n e d n e p e d l a n o i t c n u f a r e v e n e h w y X A s d l o h n i e h t , n o i t a l e r r e h t i e ) a ( X s i a su k r e p ey f o t e h rel t a n o i , r o (b) A is a r p m i e r e h t f o e t u b i r t t a e n o i t a l .

<!-- page-break -->

l o C e t a n i m i l E " : e l u R l a c i t c a r P u s n m t o n e d n e p e D nt n o " , y e K , . e . i f i s e t u b i r t t a o d t o n t n o c u b i r te k a f o n o i t p i r c s e d a o t e . e l b a t e t a r a p e s a o t m e h t e v o m e r , y

l a m r o F : n o i t i n i f e D A n o i t a l e r is n i d r i h t l a m r o n m r o f ) F N 3 ( f i d n a n o ly f i t i s i n i F N 2 a d n ever y e k y r a m i r p e h t n o t n e d n e p e d y l e v i t i s n a r t n o n s i e t u b i r t t a y e k n o n y.



## 5 a l p x E ) p e d d e u l a v i t l u m n i e e d n n y c . n i a l p x E N 4 F a x e n a h t i w m l p e y l u J ( 3 1 0 2 / n a J 3 1 0 2 )

A d e u l a v i t l u m c n e d n e p e d y ) D V M ( X ����Y d e i f i c e p s n o , R e r e h w , X d n a Y e r a t o b h R f o s t e s b u s R ( = Z d n a - X ( g n i w o l l o f e h t s e i f i c e p s ) ) Y r ) R ( r n o s n o i t c i r t s e

<!-- formula-not-decoded -->

## m r o F l a m r o N h t r u o F ( ) F N 4

A n o i t a l e r t a h t s i n i e c y o B - o C dd l a m r o N Fo m r a d n s n i a t n o c o n . s D V M F N C B o t F N 4 s e v l o v n i e h t D V M e h t f o l a v o m e r m o r f t e h n o i t a l e r by c a l p i g n ( e t u b i r t t a e h t s) n i a new e r lat n o i a o l ng wi h t a p o c y . ) s ( t n a n i m r e t e d e h t f o

u m o n s i e r e h t d n a F N 3 n i s i t i f i F N 4 n i s i n o i t a l e R A c n e d n e p e d d e u l a v i t l i s e .

<!-- page-break -->

## 6) n o i t a z i l a m r o n r o f d e e n e h t s i t a h w ? m r o f l a m r o n d n o c e s n i a l p x e ) 3 1 0 2 n a J (

## r o N d n o c e S m r o F l a m ) F N 2 (

d n o c e S l a m r o n m r o f s i b d e s a n o e h t t p e c n o c f o f l u ly c n u f i t a n o l e d p e d n e nc . y A l a n o i t c n u f X Y s i a l u f ly u f n l a n o i t c n e p e d d n e cy is o m e r v l a f o any t u b i r t t a e A from X m a e ns t a h t t e h n e d n e p e d cy s e o d t o n o h ld any mo . e r A n o i t a l e r s a m e h c s i n i 2NF f i every i r p n o n me t a tri e t u b n i n o i t a l e r s i y l l u f l a n o i t c n u f ly t n e d n e p e d n o e h t a m i r p ry key of e h t n o i t a l e r . t I o s l a c n a e b d e t a t s e r : s a a n o i t a l e r c s h a m e s i n i F N 2 f i every e m i r p n o n e t u b i r t t a n i n o i t a l e r s i t o n l a i t r a p ly dep t n e d n e e k y n a n o y . n o i t a l e r e h t f o

l a c i t c a r P : e l u R e t a n i m i l E " t n a d n u d e R D a t a ," . i e , . f i an e t u b i r t t a d e p e n s d n o n o ly pa t r of a v o m e r , y e k d e u l a v i t l u m . e l b a t e t a r a p e s a o t t i e

l a m r o F : n o i t i n i f e D A n o i t a l e r is n i d n o c e s r o n m l a m r o f (2 F N ) f i n a d o l n y f i it is n i 1NF d n a r e v e y l l u f s i e t u b i r t t a y e k n o n y . y e k y r a m i r p e h t n o t n e d n e p e d



## 7. r o f d e y o l p m e s e r u s a e m y t i l a u q l a m r o f n i o w T y n a n i a l p x E ? n g i s e D a m e h c s n o i t a l e r a

( n a J - 3 1 0 2 )

I i s e D l a m r o f n g : e r a s e n i l e d i u G n -

R e h t f o s c i t n a m e S e t u b i r t t A n o i t a l es

o i t a m r o f n I t n a d n u d e R s e i l a m o n A e t a d p U d n a s e l p u T n i n

u l a V l l u N e l p u T n i s es

s e l p u T s u o i r u p S

<!-- page-break -->

In l a m r o f l , y h c a e e l p u t in a e r l n o i t a d l u o h s p e r r t n e s e e n o i t n e ty or r t a l e n o i p i h s n i t s an . e c (A i l p p e s e t u b i r t t a r i e h t d n a s n o i t a l e r l a u d i v i d n i o t ) .

s e t u b i r t t A f o t n e r e f f i d en s e i t i t M E ( P s E E Y O L , DE A P R , s T N E M T R P OJ T C E s) d l u o h s n o i t a l e r e m a s e h t n i d e x i m e b t o n

s e i t i t n e r e h t o o t r e f e r o t d e s u e b d l u o h s s y e k n g i e r o f y l n O

t i t n E y . e l b i s s o p s a h c u m s a t r a p a t p e k e b d l u o h s s e t u b i r t t a p i h s n o i t a l e r d n a

m o t t o B i L : e n n g i s e D a a m e h c s t a h t n a c e b ex a l p d e n i i s a e ly r n o i t a l e by e r l . n o i t a e h T s c i t n a m e s

s a e e b d l u o h s s e t u b i r t t a f o y t e r p r e t n i o t .



a m s e i t i t n e e l p i t l u m f o s e t u b i r t t a g n i x i M y s m e l b o r p e s u a c

l t n a d n u d e r d e r o t s s i n o i t a m r o f n I y e g a r o t s g n i t s a w

s e i l a m o n a e t a d p u h t i w s m e l b o r P

- I s e i l a m o n a n o i t r e s n
- l e D e n o i t a m o n a i l es
- c i f i d o M a n o i t a m o n a s e i l

e d i s n o C r h t e r : n o i t a l e

R P \_ P M E O ( J r P , # p m E o , # j ) s r u o h \_ o N , e m a n P , e m a n E

<!-- page-break -->

e t a d p U : y l a m o n A g n i g n a h C the a n me of p t c e j o r r e b m u n 1 P m o r f o t " g n i l l i B " r e m o t s u C " - i t n u o c c A n m " g ay e s u a c t s i h a d p u e t o t e b e d a m o l p m e 0 0 1 l l a r o f y n i k r o w s e e g n o 1 P t c e j o r p .

r e s n I t o n A m : y l a a C n t o n t r e s n i a t c e j o r p n u l s s e n a e l p m oyee is a i s s g . o t d e n

y l e s r e v n I - r e s n i t o n n a C t l p m e n a o s s e l n u e e y n a h e h s / e is s s a igned o t a e j o r p ct .

e t e l e D : y l a m o n A e h W n a t c e j o r p s i l e d et , d e t i i w l l u s e r t l in e d l t e n i g l l a e h t l p m e oye s e o h w k r o w n o t a h t t c e j o r p . e t a n r e t l A l , y f i n a e e y o l p m e s i the e l o s e l p m o e y e n o a p , t c e j o r d g n i t e l e t a h t m e l p oyee n i t e l e d n i t l u s e r d l u o w g n i d n o p s e r r o c e h t g j o r p e . t c



8). e d i s n o C r h t e fo l l o n i w g rela : s n o i t C r a e l a s \_ (c \_ r a n , o e t a d - , d l o s , o n n a m e l a s . ) t n u o c s i d , % n o i s s i m m o c A e m u s s a a c r n a c e b d l o s by m l u i t e l p a s l s e m n a d n a r a m i r p e c n e h y e k y r a c { s i - , o n } n a m s e l a s n e d n e p e d l a n o i t i d d a cie r a s e : Date- d l o s � m s e l a s d n a t n u o c s i d a o n n . ? n o i s s i m m o C N A J ( - ) 4 1 0 2

- F N 1 n i s i n o i t a l e r s i h t s e Y ) I
- ) C ? S ' D F f o s t e s l a m i n i m e h t s s u c s i D

r e v E y t e s l a m i n i m t n e l a v i u q e n a s a h s D F f o t e s

u q e l a r e v e s e b n a c e r e h T i s t e s l a m i n i m t n e l a v

e r e h T s i o n e l p m i s r o g l a i m h t r o f g n i t u p m o c a l a m i n i m t e s f o s D F h t at is u q e v i al n e t t t e s a o F f o F s D

o T s e z i s e h t n y a t e s f o , s n o i t a l e r e w e m u s s a t a h t e w t r a t s w t i h a s t e f o de e d n e p nci s e s i t a h t s t e s l a m i n i m a .

<!-- page-break -->

## 9 e e l b a t i u s g n i s u f n 1 e v e i h c a o t s e u q i n h c e t t n e r e f f i d e e r h t n i a l p x e d n a t s e g g u S ) x ? e l p m a N A J / C E D ( 3 1 0 2 )

; n o i t a l e r a f o n o i t i n i f e d l a m r o f e h t f o t r a p e b o t d e r e d i s n o c w o n s i m r o f l a m r o n t s r i F l l a c i r o t s i h y, r i e h t d n a , s e t u b i r t t a e t i s o p m o c , s e t u b i r t t a d e u l a v i t l u m w o l l a s i d o t d e n i f e d s a w t i . s n o i t a n i b m o c It e h t t a h t s e t a t s l n o e d u l c n i t s u m s e t u b i r t t a f o s n i a m o d y , e l p m i s ( c i m o t a d n a s e u l a v ) e l b i s i v i d n i n a f o e u l a v e h t t a h t y m o r f e u l a v e l g n i s a e b t s u m e l p u t a n i e t u b i r t t a e t u b i r t t a t a h t f o n i a m o d e h t .

n i t a e p e R e t a n i m i l E " : e l u R l a c i t c a r P g , s p u o r G " e l b a t e t a r a p e s a e k a m , . e . i f o t e s h c a e r o f d e t a l e r r a m i r p a e l b a t h c a e e v i g d n a , s e t u b i r t t a y e k y.

: n o i t i n i f e D l a m r o F n o d n a f i ) F N 1 ( m r o f l a m r o n t s r i f n i s i n o i t a l e r A l g n i y l r e d n u l l a f i y l n o s e u l a v c i m o t a n i a t n o c s n i a m o d e l p m i s y.



## 10. P n e e w t e b e t a i t n e r e f f i D n o N d n a e m i r - ? s e t u b i r t t a e m i r p N A J / C E D ( 3 1 0 2 )

A n o n - i r p m t u b i r t t a e e n a o t g n o l e b t o n s e o d t a h t e t u b i r t t a n a s i R f o y e k e t a d i d n a c y A . R f o c n e d n e p e d e v i t i s n a r t y a s i c n e d n e p e d l a n o i t c n u f y h c i h w n i X → Z (X s e n i m r e t e d Z l t c e r i d n i ) y , by

u t r i v e of X →Y d n a Y → Z c e h t t o n s i t i e r e h w ( ase h t at Y →X).

<!-- page-break -->

A-X A n e e w t e b e c n e r e f f i d t e s e h t , a a s i X d n m i r p e t u b i r t t a e , . e . i ( A-X a n i h t i w d e n i a t n o c s i y e k e t a d i d n a c

- A D F d n a R n o i t a l e R e h t r e d i s n o C ) c - C , B &gt; - D &gt; C A , F - D , E &gt; - T A H W ? F &gt; I t s e h g i H D N A Y E K S t i f i ? m r o f l a m r o n i c n e d n e p e d d n a s s e l s s o l s i t a h t n o i t i s o p m o c e d d n i f f n 3 n i t o n s y n i v r e s e r p g?

8 s k r a m

e k e h T : s n A y l n o g n i m o c n i o n s a h t i e s u a c e b E s i e r e h y . s e g d e g n i o g t u o

<!-- formula-not-decoded -->

- o i t c n u f s i t a h w ) 2 1 s e t u b i r t t a e h t r o f s e i c n e d n e p e d l a n o i t c n u f s e i f i c e p s o h W ? s e i c n e d n e p e d l a n

<!-- formula-not-decoded -->

## n g i s e D e s a b a t a D -2

## . 1 u l a v i t l u m n i a l p x E e d n a y c n e d n e p e d d r o n h t r u o f m r o f l a m a x e h t i w F N 4 m . s e l p

<!-- formula-not-decoded -->

A d e u l a v i t l u m y c n e d n e p e d ) D V M ( X � � ��Y d e i f i c e p s n o , R e r e h w , X d n a Y e r a t o b h R f o s t e s b u s R ( = Z d n a - X ( e h t s e i f i c e p s ) ) Y g n i w o l l o f r r n o s n o i t c i r t s e ( ) R

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

## m r o F l a m r o N h t r u o F ( ) F N 4

A n o i t a l e r t a h t s i n i e c y o B - d d o C l a m r o N Fo m r d n a s n i a t n o c o n M D V s. F N C B o t F N 4 s e v l o v n i e h t D V M e h t f o l a v o m e r n o i t a l e r e h t m o r f by c a l p i g n e h t ( e t u b i r t t a s) n i a new e r l t a i n o along w t i p o c a h y . ) s ( t n a n i m r e t e d e h t f o n e d n e p e d d e u l a v i t l u m o n s i e r e h t d n a F N 3 n i s i t i f i F N 4 n i s i n o i t a l e R A cie . s

<!-- page-break -->

## 2) t r e p o r p n i o j s s e l s s o l n i a l p x E y.

## n a J / c e D ( 12)

## n o N ( s s e l s s o L - o c e D a f o y t r e p o r P n i o J ) e v i t i d d a m : n o i t i s o p

: n o i t i n i f e D o L s s e l s s n i o j r e p o r p t : y a d n o i t i s o p m o c e D = , 1 R { , 2 R . . ., } m R f o s a h R t e h s s e l s s o l ) e v i t i d d a n o n ( n i o j o r p p y t r e h t i w t c e p s e r o t e h t t e s e d n e p e d f o n s e i c F n o R , f i r o f ev y r e n o i t a l e r e t a t s r f o R t a h t a s tis s e i f , F t n i w o l l o f e h g e h t s i * e r e h w , s d l o h j l a r u t a n l e r e h t l l a f o n i o a n i s n o i t D:

```
* (π , ) r ( 1 R . . . , πRm = ) ) r ( r
```

: e t o N e h T d r o w s s o l n i s s e l s s o l s r e f e r o t s s o l f o , n o i t a m r o f n i t o n to o l ss f o t s e l p u . n I , t c a f for s s o l " f o i a m r o f n i t " n o a r e t t e b m r e t is " n o i t i d d a f o r o f n i s u o i r u p s m n o i t a "

## h t i r o g l A m n i o J s s e l s s o L r o f g n i t s e T : 1 . 1 1 P e p o r r y t

p n I ut: A l a s r e v i n u n o i t a l e r , R a c e d p m o s o i t i n o D = {R , 1 R , 2 . . ., } m R f o R, d n a f o F t e s a d n e p e d l a n o i t c n u f encies .

1. e t a e r C n a l a i t i n i x i r t a m S h t i w e n o w o r i r o f h c a e n o i t a l e r i R n i , D d n a e n o o c m u l n j r o f h c a e R n i j A e t u b i r t t a .
2. t e S j i b = : ) j , i ( S r o f l l a matrix r t n e i s i j i b h c a e * ( . s e a t c n i t s i d s l o b m y c o s s a iat d e w t i h i d n i e c s , i ( j) . ) *
3. . 3 n i t n e s e r p e r i w o r h c a e r o F g i R a m e h c s n o i t a l e r

```
j A e t u b i r t t a g n i t n e s e r p e r j n m u l o c h c a e r o f { S t e s n e h t ) j A e t u b i r t t a s e d u l c n i i R n o i t a l e r ( f i { ( ; } ; } ; j a = : ) j , i i j a h c a e * ( s t c n i t s i d a s y * ) j ( x e d n i h t i w d e t a i c o s s a l o b m )
```

## h t i r o g l A m n i o J s s e l s s o L r o f g n i t s e T : 1 . 1 1 P e p o r r y t

- . 4 x e p o o l e t e l p m o c a l i t n u p o o l g n i w o l l o f e h t t a e p e R e S o t s e g n a h c o n n i s t l u s e r n o i t u c

c n e d n e p e d l a n o i t c n u f h c a e r o f { y X n i Y F

r o f { l l a s w o r n i S h c i h w h e v a e h t e m a s o b m y s ls n i e h t s n m u l o c g n i d n o p s e r r o c t t a o t r t u b i e s e k a m { X n i e h t s l o b m y s n i h c a e n m u l o c t a h t p s e r r o c o d n o t n a at r t t u b i e n i Y n i e m a s e h t e b s e h t l l a e r s a s w o f : s w o l l o f I any f o e h t s w o r s a h n a " a " s l o b m y r o f e h t o c l , n m u t e s e h t o h t r e

o r w o t s h t a t m a s e " a " s . n m u l o c e h t n i l o b m y f I o n " a " s o b m y l ex s t s i r o f e h t e t u b i r t t a n i any f o e h t , s w o r e s o o h c e n o f o e h t " b " s s l o b m y t a h t r a e p p a n i e n o f o e h t s w o r r o f e h t e t u b i r t t a d n a t e s e h t r e h t o s w o r o t s " b " e m a s t a h t y ; } ; n m u l o c e h t n i l o b m

```
; } ; }
```

5. If a w o r s i e d a m p u e r i t n e ly of " a " s s l o b m y , n e h t e h t n o i t i s o p m o c e d s a h e h t o l s l s s e s

<!-- page-break -->

o j i . t o n s e o d t i e s i w r e h t o ; y t r e p o r p n

L s s e l s s o ) e v i t i d d a n o n ( i o j n t s e t r o f n-ary e d c s n o i t i s o p m o .

- S C O L \_ P M E d n a 1 J O R P \_ P M E o t n i J O R P \_ P M E f o n o i t i s o p m o c e D : 1 e s a C ) a ( f t s l i a t s e .
- r e p o r p n i o j s s e l s s o l e h t s a h t a h t J O R P \_ P M E f o n o i t i s o p m o c e d A ) b ( ty

|    |
|----|



<!-- page-break -->

L s s e l s s o ) e v i t i d d a n o n ( i o j n s e t t r o f n-ary . s n o i t i s o p m o c e d R P , P M E o t n i J O R P \_ P M E f o n o i t i s o p m o c e D : 2 e s a C ) c ( O W d n a , T C E J O f s i t a s N O \_ S K R e i

s t s e t

## 3) c n e d n e p e d d e u l a v i t l u m n i a l p x E y e l p m a x e n a h t i w , m r o f l a m r o n h t r u o f d n a .

<!-- formula-not-decoded -->

## o N h t r u o F d n a s e i c n e d n e p e D d e u l a v i t l u M ) F N 4 ( m r o F l a m r

F N 4 d e t a i c o s s a h t i w a e p e d n n e d cy d e l l a c mu i t l - d e u l a v y c n e d n e p e d . ) D V M ( s D V M n i a n o i t a l e r e r a e u d o t t s r i f l a m r o n m r o f , ) F N 1 ( i h w ch s w o l l a s i d n a e t u b i r t t a n i a w o r m o r f g n i v a h a o t e s f va . s e u l D V M s t n e s e r p e r a d n e d n e p e cy n e e w t e b e t u b i r t t a s r o f ( , e l p m a x e , A , B n a d ) C n i a e r la i t , n o u s ch t a h t r o f h c a e e u l a v f o A t e r e h is a t e s f o s e u l a v o f r , B d n a a t e s f o v e u l a s for C. , r e v e w o H e h t t e s a e f o t n e d n e p e d n i e r a C d n a B r o f s e u l a v f o c e h t o h r D V M . g n i s u n o i t a l e r a n i C d n a , B , A s e t u b i r t t a n e e w t e b a t o n g n i w o l l o f e h t t n o i

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

r o F m c n e d n e p e D d e u l a v i t l u M f o n o i t i n i f e D l a y

A d e u l a v i t l u m y c n e d n e p e d ) D V M ( X � � ��Y d e i f i c e p s n o , R e r e h w , X d n a Y e r a t o b h R f o s t e s b u s R ( = Z d n a - X ( e h t s e i f i c e p s ) ) Y g n i w o l l o f o i t c i r t s e r r n o s n ( ) R

<!-- formula-not-decoded -->

## m r o F l a m r o N h t r u o F ( ) F N 4

A n o i t a l e r a h t t s i n i Bo e c y - d d o C No l a m r m r o F a d n s n i a t n o c o n MVD . s F N C B o t 4NF o v n i v l s e e h t D V M e h t f o l a v o m e r t a l e r e h t m o r f n o i by c a l p i g n e h t ( e t u b i r t t a s) n i a new e r l t a i n o along w t i p o c a h y . ) s ( t n a n i m r e t e d e h t f o

## 4 ) r e p o r p n i o j s s e l s s o l n i a l p x E ty

/ Y A M ( J Y L U 3 1 0 2 )

## n o N ( s s e l s s o L - n i o J ) e v i t i d d a P o c e D a f o y t r e p o r m : n o i t i s o p

: n o i t i n i f e D s s e l s s o L n i o j r e p o r p t : y a d i t i s o p m o c e n o D = , 1 R { , 2 R . . ., } m R f o R

s a h t e h s s e l s s o l ) e v i t i d d a n o n ( n i o j o r p p y t r e h t i w t c e p s e r o t e h t t e s

<!-- page-break -->

e d n e p e d f o n s e i c F n o R , f i r o f ev y r e n o i t a l e r e t a t s r f o R t a h t a s tis s e i f , F t e h n i w o l l o f g l e r e h t l l a f o n i o j l a r u t a n e h t s i * e r e h w , s d l o h a n i s n o i t D:

```
( * π , ) r ( 1 R . . ., πRm = ) ) r ( r
```

: e t o N e h T d r o w s s o l n i s s e l s s o l s r e f e r o t s s o l f o , n o i t a m r o f n i t o n to o l ss f o t s e l p u . n I , t c a f for s s o l " f o i a m r o f n i t " n o a r e t t e b m r e t is " n o i t i d d a f o r o f n i s u o i r u p s m n o i t a "

## h t i r o g l A m n i o J s s e l s s o L r o f g n i t s e T : 1 . 1 1 P e p o r r y t

p n I ut: A l a s r e v i n u n o i t a l e r , R a c e d p m o s o i t i n o D = {R , 1 R , 2 . . ., } m R f o R, d n a a f o F t e s d n e p e d l a n o i t c n u f encies .

1. e t a e r C n a l a i t i n i x i r t a m S h t i w e n o w o r i r o f h c a e n o i t a l e r i R n i , D d n a e n o o c m u l n j r o f h c a e R n i j A e t u b i r t t a .
2. t e S j i b = : ) j , i ( S r o f l l a a m trix r t n e i s i j i b h c a e * ( . s e a t c n i t s i d s l o b m y c o s s a iat d e w t i h i d n i e c s , i ( j) . ) *
3. . 3 n i t n e s e r p e r i w o r h c a e r o F g i R a m e h c s n o i t a l e r

```
j A e t u b i r t t a g n i t n e s e r p e r j n m u l o c h c a e r o f { S t e s n e h t ) j A e t u b i r t t a s e d u l c n i i R n o i t a l e r ( f i { ( ; } ; } ; j a = : ) j , i j a h c a e * ( s t c n i t s i d a s i y * ) j ( x e d n i h t i w d e t a i c o s s a l o b m )
```

## h t i r o g l A m n i o J s s e l s s o L r o f g n i t s e T : 1 . 1 1 P e p o r r y t

- . 4 x e p o o l e t e l p m o c a l i t n u p o o l g n i w o l l o f e h t t a e p e R e S o t s e g n a h c o n n i s t l u s e r n o i t u c

```
c n e d n e p e d l a n o i t c n u f h c a e r o f { y X � n i Y F
```

r o f { l l a s w o r n i S h c i h w e v a h e h t e m a s o b m y s ls n i e h t s n m u l o c g n i d n o p s e r r o c t t a o t r t u b i e X n i s

e k a m { e h t s l o b m y s n i h c a e n m u l o c t a h t p s e r r o c o d n o t n a at r t t u b i e n i Y l l a n i e m a s e h t e b s e h t e r s a s w o f : s w o l l o

f I any f o e h t s w o r s a h n a " a " s l o b m y r o f e h t o c l , n m u t e s e h t o h t o r r e w t s h t o a t m a s e " a " s . n m u l o c e h t n i l o b m y

f I o n " a " s o b m y l ex s t s i r o f e h t e t u b i r t t a n i any f o e h t , s w o r

e s o o h c

e n o f o e h t " b " s s l o b m y t a h t r a e p p a n i e n o f o e h t s w o r r o f e h t e t u b i r t t a d n a t e s e h t r e h t o s w o r o t

s " b " e m a s t a h t y ; } ; n m u l o c e h t n i l o b m

```
; } ; }
```

5. f I a w o r s i e d a m p u e r i t n e ly of " a " s s l o b m y , n e h t e h t n o i t i s o p m o c e d s a h e h t o l s l s s e s o j i n

. t o n s e o d t i e s i w r e h t o ; y t r e p o r p L s s e l s s o ) e v i t i d d a n o n ( i o j n t s e t r o f n-ary e d c s n o i t i s o p m o .

<!-- page-break -->

- S C O L \_ P M E d n a 1 J O R P \_ P M E o t n i J O R P \_ P M E f o n o i t i s o p m o c e D : 1 e s a C ) a ( f s l i a t s e t .
- r e p o r p n i o j s s e l s s o l e h t s a h t a h t J O R P \_ P M E f o n o i t i s o p m o c e d A ) b ( ty



<!-- page-break -->

. s n o i t i s o p m o c e d

- o t n i J O R P \_ P M E f o n o i t i s o p m o c e D : 2 e s a C ) c ( E W d n a , T C E J O R P , P M O N O \_ S K R e i f s i t a s t s e t s

## 5 c n e d n e p e D e v l a v i t l u M s i t a h W .

## y

n a J / c e D ( 1 1 )

- (a) N E : s D V M o w t h t i w n o i t a l e r P M E e h T A E M - N P &gt; &gt; A E M a E M A N E d n -&gt;&gt; . E M A N D
- b ( ) De g n i s o p m o c h t e M E P n o i t a l e r t n i o t o w F N 4 e r s n o i t a l P M E \_ R P O T C E J S n a d . S T N E D N E P E D \_ P M E

e h T n o i t a l e r Y L P P U S wi h t o n s D V M s i n i F N 4 t u b t o n n i F N 5 f i t i s a h e h t J ( D R , 1 2 R , R ) 3 . d ( ) F N 5 e h t o t n i Y L P P U S n o i t a l e r e h t g n i s o p m o c e D 3 R d n a , 2 R , 1 R s n o i t a l e r .



<!-- page-break -->

## 6 ) h t i w e m a s e h t n i a l p x e ? D V M f o t p e c n o c a n o d e s a b s i m r o f l a m r o N h c i h W l p m a x e e?

n a J ( 3 1 0 2 ) 4 1 0 2 n a J / 3 1 0 2 y l u J /

) F N 4 ( m r o F l a m r o N h t r u o F d n a s e i c n e d n e p e D d e u l a v i t l u M

c n e d n e p e d a h t i w d e t a i c o s s a F N 4 y d e l l a c i t l u m -v e p e d d e u l a y c n e d n ) D V M ( . MV n i s D a g n i v a h m o r f w o r a n i e t u b i r t t a n a s w o l l a s i d h c i h w , ) F N 1 ( m r o f l a m r o n t s r i f o t e u d e r a n o i t a l e r a o t e s f va . s e u l c n e d n e p e d a s t n e s e r p e r D V M y ) C d n a , B , A , e l p m a x e r o f ( s e t u b i r t t a n e e w t e b h c u s , n o i t a l e r a n i t A f o e u l a v h c a e r o f t a h t s e u l a v f o t e s a d n a , B r o f s e u l a v f o t e s a s i e r e h r o f C . e v e w o H r h t , e set e f o t n e d n e p e d n i e r a C d n a B r o f s e u l a v f o c a h t o h er. n e e w t e b D V M a t o n g n i w o l l o f e h t g n i s u n o i t a l e r a n i C d n a , B , A s e t u b i r t t a t n o i

<!-- formula-not-decoded -->

e D l a m r o F n e d n e p e D d e u l a v i t l u M f o n o i t i n i f cy

A m d n e p e d d e u l a v i t l u e y c n ( D V M ) X e r a Y d n a , X e r e h w , R n o d e i f i c e p s Y h t o b

R f o s t e s b u s R ( = Z d n a - X ( e h t s e i f i c e p s ) ) Y g n i w o l l o f r n o s n o i t c i r t s e r R ( )

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

## r o N h t r u o F m l a F ) F N 4 ( m r o

o B n i s i t a h t n o i t a l e r A y e c - s D V M o n s n i a t n o c d n a m r o F l a m r o N d d o C . B N 4 o t F N C F v l o v n i e n o i t a l e r e h t m o r f D V M e h t f o l a v o m e r e h t s b w e n a n i ) s ( e t u b i r t t a e h t g n i c a l p y p o c a h t i w g n o l a n o i t a l e r y m r e t e d e h t f o e r e h t d n a F N 3 n i s i t i f i F N 4 n i s i n o i t a l e R A . ) s ( t n a n i i c n e d n e p e d d e u l a v i t l u m o n s i e . s

## 7 i F n i a l p x E . f o N h t r l a m Form

## Y L U J / N U J ( 0 2 3 1 )

A y c n e d n e p e d n i o j (JD b d e t o n e d , ) y R { D J 1, R2, R , … n i f i c e p s , } e n o d e r s n o i t a l c a m e h , R a s e i f i c e p s c t s n o r h t n o t n i a e s e t a t s r of R. r e v e t a h t s e t a t s t n i a r t s n o c e h T y e t a t s l a g e l r o f R d l u o h s o t n i n o i t i s o p m o c e d n i o j s s e l s s o l a e v a h R1, R2 , … R , n o f , s i t a h t ; r e r e v y h c u s r e w e v a h

<!-- formula-not-decoded -->

<!-- page-break -->

s s e l s s o L - t r e p o r p n i o j y l e r a e s o p m o c e d e w n e h w o t s r e f e r s n o i t a l e r o w t o t n i n o i t a - n a c e w i r o e h t e c u d o r p o t s n o i t a l e r g n i t l u s e r e h t n i o j e r g n o i t a l e r l a n i . v e w o H e m o s , r e r e h t s e m i t e h t s i e l e r a e s o p m o c e d o t t n e m e r i u q e r a r o m o t n i n o i t e h t an s n o i t a l e r o w t . u o h t l A g c e s e h t , e r a r h ase s e r a b d e g a n a m y c n e d n e p e d n i o j y a . F N 5 d n

## N 5 F t c e j o r p r o ( - r o n n i o j m ( m r o f l a P ) ) F N J

c n e d n e p e d n i o j o n s a h t a h t n o i t a l e r A y .

p e D e t a l p m e T e d n e i c n es

f i c e p s o t s i s e i c n e d n e p e d e t a l p m e t d n i h e b a e d i e h T y e t a l p m e t a - e l p m a x e r o - s e n i f e d t a h t c n e d n e p e d r o t n i a r t s n o c h c a e y . t o w t e r a e r e h T y t f o s e p e l p u t : s e t a l p m e - s e t a l p m e t g n i t a r e n e g d n a t n i a r t s n o c - s e t a l p m e t g n i t a r e n e g . h f o r e b m u n a f o s t s i s n o c e t a l p m e t A y t a h t s e l p u t s i s e h t o p e r a s n o i t a l e r e r o m r o e n o n i r a e p p a y a m t a h t s e l p u t e h t f o e l p m a x e n a w o h s o t t n a e m . e h T h t o er p r a t e h t s i e t a l p m e t e h t f o t n o i s u l c n o c e t a l p m e . e l p u t r o F -g n i t a r e n e g e h t , s e t a l p m e t t e s a s i n o i s u l c n o c h e h t f i s n o i t a l e r e h t n i t s i x e o s l a t s u m t a h t s e l p u t f o y e r a s e l p u t s i s e h t o p e r e h t . t s n o c r o F a r t n i - t s u m t a h t n o i t i d n o c a s i n o i s u l c n o c e t a l p m e t e h t , s e t a l p m e t g n i t a r e n e g h t n o d l o h h e y s i s e h t o p . s e l p u t

## o D m m r o F l a m r o N y e K n i a

e d i e h T a be d n i h n i a m o d - ( m r o f l a m r o n y e k D ) F N K e h t ) t s a e l t a , y l l a c i t e r o e h t ( y f i c e p s o t s i t e l b i s s o p l l a t n u o c c a o t n i s e k a t t a h t " m r o f l a m r o n e t a m i t l u " y d n a s e i c n e d n e p e d f o s e p . s t n i a r t s n o c l e r A a d i a s s i n o i t b o t e n i DKNF s t n i a r t s n o c l l a f i n e p e d d n a d s t a h t s e i c n e h d l u o e h t n o d l o h l p m i s d e c r o f n e e b n a c n o i t a l e r y y e k d n a s t n i a r t s n o c n i a m o d e h t g n i c r o f n e y b r e h t n o s t n i a r t s n o c ela . n o i t e l p m o c g n i d u l c n i f o y t l u c i f f i d e h t f o e s u a c e b , r e v e w o H x F N K D a n i s t n i a r t s n o c r o t t l u c i f f i d e t i u q e b y a m t i e c n i s , d e t i m i l s i y t i l i t u l a c i t c a r p s t i , n o i t a l e i r g e t n i l a r e n e g y f i c e p s t . s t n i a r t s n o c y

V e r e h w ( ) # N I V , E K A M ( R A C n o i t a l e r a r e d i s n o c , e l p m a x e r o F I e l c i h e v e h t s i # N V ( E R U T C A F U N A M n o i t a l e r r e h t o n a d n a ) r e b m u n n o i t a c i f i t n e d i I , # N r e h w ( ) Y R T N U O C e O C U h t s i Y R T N e r t n u o c y . ) e r u t c a f u n a m f o n i w o l l o f e h t f o e b y a m t n i a r t s n o c l a r e n e g A g " : m r o f I s i E K A M e h t f o T r e h t i e y V e h t f o r e t c a r a h c t s r i f e h t n e h t , s u x e L r o a t o I " a s i # N J f i " r t n u o c e h t y e r u t c a f u n a m f o a d n o H s i E K A M e h t f i ; n a p a J s i V e h t f o r e t c a r a h c d n o c e s e h t , a r u c A r o I a s i # N "J" e h t f i r t n u o c y a w d e i f i l p m i s o n s i e r e h T " . n a p a J s i e r u t c a f u n a m f o y s t n i a r t s n o c h c u s t n e s e r p e r o t t r o h s n i t i r w f o g . m e h t t s e t o t ) s n o i t r e s s a l a r e n e g r o ( e r u d e c o r p a

<!-- page-break -->

## N U IT- I I I V

## t n e m e g a n a M n o i t c a s n a r T

## 1) n o i t c a s n a r t a f o s e i t r e p o r p n i a l p x E ? Y L U J / N U J ( 0 2 5 1 )

n i w o l l o f e h t s e s s o p d l u o h s s n o i t c a s n a r T g C A ( I i t r e p o r p ) D e : s

s n o i t c a s n a r T d l u o h s s s e s s o p l a r e v e s . s e i t r e p o r p T e s e h e r a n e t f o c d e l l a h t e I C A D p o r p e i t r e s, d n a h t ey d l u o h s be f n e o e c r d by the c n o c u e r r ncy o c nt o r l d n a rec v o ery m h t e ods f o h t e DBM . S e h T f l o g n i w o l a e r t e h AC D I prop r e i t : s e

1. t A o : y t i c i m A n a r t s n o i t c a s i n a c i m o t a t i n u f o i s s e c o r p n ; g t i s i r e h t i e d e m r o f r e p n i its t e r i t n e y . l l a t a d e m r o f r e p t o n r o
2. o C n y c n e t s i s t a v r e s e r p i : n o A n o i t c a s n a r t s i s i s n o c n e t cy pr i v r e s e ng if s t i o t e t a t s t n e t s i s n o c e n o m o r f e s a b a t a d e h t ) s ( e k a t n o i t u c e x e e t e l p m o c a h t o n r e .
3. s I l o o i t a n: A n o i t c a s n a r t d l u o h s r a e p p a s a o h t u h g t i s i i e b ng ex e t u c e d in i o s la i t n o r f om r e h t o n a r t s . s n o i t c a Th t a i , s e h t ex n o i t u c e of a a r t n n o i t c a s h s d l u o t o n be n i t f r e e e r d i w h t b l t n e r r u c n o c g n i t u c e x e s n o i t c a s n a r t r e h t o y n a y y.
4. y t i l i b a r u D r o a m r e p n : y c n e e h T a h c n s e g d e i l p p a o t e h t e s a b a t a d by a m m o c t i n o i t c a s n a r t d e t t s u m t s i s r e p n i e h t . e s a b a t a d e s e h T s e g n a h c t s u m t o n e b t s o l e s u a c e b f o an f y a u l i e r .

e h T i c i m o t a ty r e p o r p ty s e r i u q e r t a h t we exe e t u c a t s n a r a t c o i n to o c mpl t e i . n o t I s i i l i b i s n o p s e r e h t ty f o e h t tr n o i t c a s n a e v o c e r ry b u s sys e t m of a DB S M o t en u s e r atom i c i t . y f I a n o i t c a s n a r t s l i a f o t m o c p e t e l r o f e m o s n o s a e r , u s ch s a a s m e t s y a r c sh in the i m d t s f o transa n o i t c n a o d n u t s u m e u q i n h c e t y r e v o c e r e h t , n o i t u c e x e y e h t f o s t c e f f e . e s a b a t a d e h t n o n o i t c a s n a r t

<!-- page-break -->

## . 2 t a h W s i a ? e l u d e h c s p x E l n i a w h t i e l p m a x e i r e s l a , non r e s i l a d n a n o c i l f t c s a i r e i l z l b a e

## l u d e h c s e . s

Y L U J / N U J ( 3 1 0 2 )

A l u d e h c s e (or r o t s i h y) S f o n t s n a r a s n o i t c , 1 T T , 2 . . ., n T s i n a o i r e d r ng of e h t op a r e t n o i s of t e h s n o i t c a s n a r t t c e j b u s o t e h t o c n t n i a r t s , t a h t r o f h c a e s n a r t a n o i t c i T h t t a e t a p i c i t r a p s n i , S e h t s n o i t a r e p o f o i T in S t s u m r a e p p a n i e h t e m a s or r e d n i h c i h w h t ey o c c ur in . i T , e t o N , r e v e w o h t a h t s n o i t a r e p o m o r f r e h t o n a r t sa s n o i t c j T n a c be d e v a e l r e t n i h t i w e h t p o e a r i t s n o f o Ti in S. r o F , w o n r e d i s n o c e h t r e d r o f o o o i t a r e p ns in S to e b a l a t o t n i r e d r o g, h g u o h t l a t i s i e p o e s o h w s e l u d e h c s h t i w l a e d o t y l l a c i t e r o e h t e l b i s s o p m r o f s n o i t a r l a i t r a p d r o e s r .

i h w ch e w l l a c , b S a c n e b r w itt n e as o f l l , s w o if e w r e t f a d e t r o b a 1 T n o i t c a s n a r t t a h t e m u s s a s t i d a e r \_ e t i m(Y) : n o i t a r e p o

o w T s n o i t a r e p o n i a e l u d e h c s e r a d i a s to t c i l f n o c f i y e h t s s i t a fy l l a e e r h t f o e h t n i w o l l o f g : s n o i t i d n o c

- . 1 e h t y ; s n o i t c a s n a r t t n e r e f f i d o t g n o l e b
2. t i e m a s e h t s s e c c a y e h t e m ; X d n a
3. a r e p o e h t f o e n o t s a e l t a t a s i s n o i e t i \_ e t i r w m(X) .

r o F ex , e l p m a n i c s h u d e le , e h t e p o rat s n o i o c n , t c i l f s a o d t e h e p o r t a n o i s

<!-- formula-not-decoded -->

d n a e h t op a r e t s n o i ( 1 w X) n a d ( 2 w X). , r e v e w o H e h t s n o i t a r e p o ( 1 r X) d n a

2 r (X) o d t o n , t c i l f n o c i s n e c h t ey a e r h t o b re d a p o e s n o i t a r ; t e h a r e p o t s n o i w ( 2 X d n a ) w1(Y) o d , t c i l f n o c t o n u a c e b se y e h t op e t a r e n o t c n i t s i d a d ta t i e s m X d n a Y; e h t d n a s n o i t a r e p o ( 1 r X) d n a ( 1 w X) , t c i l f n o c t o n o d t e m a s e h t o t g n o l e b y e h t e s u a c e b r . n o i t c a s n a

- A u d e h c s le S is se l a i r i , f r o f e v e ry t s n a r a t c i n o T l l a e h t t a r e p o i n o s f o T e r a ex d e t u c e e v i t u c e s n o c l e l u d e h c s e h t n i y .
- A u d e h c s le S of n s n a r t act s n o i s i e l b a z i l a i r e s f i t i s i t n e l a v i u q e o t o s me r e s ial c s h d e e l u f o h t e e m a s n r t a s n o i t c a s n

<!-- page-break -->

## n o s e t o n t r o h s e t i r W . 3

## n a J ( 0 2 4 1 0 2 n a J / 3 1 )

## a e t i r W ) i p g o l d a e h r : l o c o t o

n e h W n i - e c a l p a d p u te (i d e m m i e t a r o e d f r e r ) d e is d e s u n e h t g o l s i s s e c e n r a y r o f r o c e very d n a it t s u m e b e l b a l i a v a o t e v o c e r ry a m a n . r e g s i h T s i c a d e v e i h by W e t i r -A d a e h Lo i g g ng ( A W ) L o c o t o r p l. A W L t a h t s e t a t s

r o F : o d n U e r o f e B a a t a d s ' m e t i M I F A s i d e h s u l f o t e h t e s a b a t a d k s i d e v o ( r g n i t i r w t e h F B IM) i s t F B I l ( e r o t s e l b a t s a n o d e v a s e b t s u m g o l e h t d n a g o l e h t o t n e t t i r w e b t s u m M g o . ) k s i d

r o F o d e R : B e r o f e a n o i t c a s n a r t ex e t u c e s s t i o c m i m t a r e p o t o i , n l a l t i s AF s M I m s u t be wr t i n e t to e h t s a n o d e v a s e b t s u m g o l e h t d n a g o l t e r o t s e l b a .

) i n o i t c a s n a r T p p u s ort n i L Q S : A e l g n i s SQL t n e m e t a t s s i w l a a s y o c n d e r e d i s o t e b a i m o t c. r e h t i E e h t t n e m e t a t s t e l p m o c s e ex n o i t u c e t u o h t i w r o r r e r o t i s l i a f d n a l e v a e s e h t data s a b e n a h c n u g . d e With Q S L, r e h t e is o n e t i c i l p x B g e n i T a r s n c a n o i t t a t s eme . t n n o i t c a s n a r T n o i t a i t i n i s i e n o d t i c i l p m i ly wh n e u c i t r a p l r a SQL s t n e m e t a t s e r a . d e r e t n u o c n e e v E ry n a r t s n o i t c a t s u m e v a h n a ex t i c i l p d n e e t a t s m , t n e h c i h w s i e t i r e h a

## M M O C I K C A B L L O R r o T .

Q S n i t n e m e t a t s N O I T C A S N A R T T E S a y b d e i f i c e p s s c i t s i r e t c a r a h C L : 2

R W D A E R r o Y L N O D A E R : e d o m s s e c c A I . E T

E R f o l e v e l n o i t a l o s i e h t s s e l n u E T I R W D A E R s i t l u a f e d e h T A O C N U D M T I T s i D E p s e , d e i f i c n i s i Y L N O D A E R e s a c h c i h w a m u s s ed .

c i t s o n g a i D e z i s , n i c e p s f s e i n a r e g e t n i e u l a v , n in a c i d i t g n e h t r e b m u n f o n o i t i d n o c s t t a h c i t s o n g a i d e h t n i y l s u o e n a t l u m i s d l e h e b n a c . a e r a

n o i t a l o s I l l e v e , &gt; n o i t a l o s i &lt; e r e h w &gt; n o i t a l o s i &lt; n a c e b READ UNCOMM , D E T T I R D A E C M M O I , D E T T E P E R A B A T LE A E R D or R E S I . E L B A Z I L A e h T defa t l u s i R E S I E L B A Z I L A . h t i W E S R E L B A Z I L A I : e h t n i t a e l r e v d e n o i t u c e x e of trans t c a n o i s i w ll e r e h d a o t r u o n o i t o n f o i l a i r e s z i l i b a t . y , r e v e w o H f i any n o i t c a s n a r t ex s e t u c e t a a r e w o l m y t i l i b a z i l a i r e s n e h t , l e v e l . d e t a l o i v e b y a

: s l e v e l n o i t a l o s i r e w o l h t i w m e l b o r p l a i t n e t o P

t r i D y : d a e R

b n e t t i r w s a w t a h t e u l a v a g n i d a e R y . d e l i a f h c i h w n o i t c a s n a r t a

<!-- page-break -->

## r n o N e e R e l b a t a e p a : d

g n i w o l l A r e h t o n a n a r t s n o i t c a o t e t i r w a w e n e u l a v n e e w t e b e l p i t l u m s d a e r f o n o e tr a s n a c . n o i t

A t n o i t c a s n a r 1 T may d a e r a n e v i g l a v ue m o r f a . e l b a t f I r e h t o n a n a r t s c a t n o i 2 T r e t a l a d p u t s e t a h t e u l a v d n a 1 T d a e r s t a h t e u l a v a , n i a g T1 w l i l see a di e f f rent va u l e. r e d i s n o C t a h t T1 d a e r s e h t l p m e oyee s l a ary o f r i m S . h t e N x , t 2 T a d p u t s e e h t a l a s ry r o f h t i m S . f I 1 T s d a e r s ' h t i m S a l a s ry , n i a g a n e h t t i l l i w e e s a e r e f f i d nt r a l a s s ' h t i m S r o f e u l a v y .

w e N : s m o t n a h P s w o r g n i e b d a e r i s u ng e h t sa e m a e r d i w th a d n o c i t i . n o A n o i t c a s n a r t T1 may d a e r a t e s of s w o r o r f m a ta l b , e pe a h r ps bas d e on o s me n o i t i d n o c d e i f i c e p s n i e h t SQL W E R E H cl . e s u a w o N e s o p p u s t a h t a n a r t s t c a i n o 2 T s t r e s n i a w e n w o r t a h t o s l a s e i f s i t a s e h t W E H RE cl u a se i d n o c i t n o f o T1, i o t n e h t e l b a t d e s u by 1 T . f I 1 T s i , d e t a e p e r n e h t 1 T l l i w e e s a w o r t a h t p v e r i u o sly d i d . m o t n a h p a d e l l a c , t s i x e t o n

## w T ) i i i o k c o l e s a h p i g n p : l o c o t o r

## o w T - T g n i k c o L e s a h P e o c l a i t n e s s E : s e u q i n h c m s t n e n o p

( e v i s u l c x e ) b ( d n a ) d a e r ( d e r a h s ) a ( s e d o m s k c o l o w T w t i r ) e d e r a h S . : e d o m d e r a h s o l ck ) X ( . e r o M n a h t n a c n o i t c a s n a r t e n o p p a ly a h s re k c o l n o X o f r re d a ing t i r w o n t u b e u l a v s t i e b n a c k c o l e n a y b X n o d e i l p p a y . n o i t c a s n a r t r e h t o e v i s u l c x E : e d o m W e t i r k c o l . ) X ( n O ly one e t i r w k c o l n o X n a c ex t s i t a any t m i e a d n o n sh d e r a n a y b d e i l p p a e b n a c k c o l y X n o n o i t c a s n a r t r e h t o .



M : r e g a n a M k c o L a n a g n i g . s m e t i a t a d n o s k c o l

k c o L t : e l b a Lo r e g a n a m k c s e s u t i o t e r o t s e h t i t n e d i fy f o tr n o i t c a s n a i k c o l ng a a t a d e t i m, t e h a d t a , m e t i k c o l e d o m d n a o p i r e t n o t t e h e n xt a t a d it m e c o l k . d e e n O e l p m i s y a w o t p m i lem n e t a l k c o

t s i l d e k n i l h g u o r h t s i e l b a t .

<!-- page-break -->

| t a D D I n o i t c a s n a r T e t i a m id lock e d o m Ptr to t x e n d e t i a t a m   | t a D D I n o i t c a s n a r T e t i a m id lock e d o m Ptr to t x e n d e t i a t a m   | t a D D I n o i t c a s n a r T e t i a m id lock e d o m Ptr to t x e n d e t i a t a m   | t a D D I n o i t c a s n a r T e t i a m id lock e d o m Ptr to t x e n d e t i a t a m   |
|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| 1 T                                                                                        | X1                                                                                         | e R ad                                                                                     | N t x e                                                                                    |

l l e w e b d l u o h s s n o i t c a s n a r t l l a t a h t s e r i u q e r e s a b a t a D -forme . d l l e w s i n o i t c a s n a r t A - d e m r o f : f i

- s e t i r w r o s d a e r t i e r o f e b m e t i a t a d e h t k c o l t s u m t I t i o t .
- It t s u m t o n l k c o n a a e r l a dy e k c o l d t a d a s m e t i a d n t i t s u m t o n try to l n u c o k a free a t a d e t i m .

n i w o l l o f e h T g : n o i t a r e p o k c o l e h t s m r o f r e p e d o c

```
B: f i L ) * d e k c o l n u s i m e t i * ( 0 = ) X ( K C O n e h t L X ( K C O ) ← l * ( 1 o ) * m e t i e h t k c n i g e b e s l e d n a ) 0 = ) X ( k c o l l i t n u ( t i a w o l e h t ) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c ; B o t o g e ; d n
```

: n o i t a r e p o k c o l n u e h t s m r o f r e p e d o c g n i w o l l o f e h T

O

L K

C (X) ← c

0

*

(

n

u

l

o

k

t

h

e

i

t

m

e

*

)

e h t g n i t i a w e r a s n o i t c a s n a r t y n a f i n

n i t i a w e h t f o e n o p u e k a w g h t e a s n a r t c ; s n o i t

## i T ) v i m a t s e m g n i r e d r O p :

## i T me a t s mp

A l a c i n o t o n o m ly s a e r c n i i g n e l b a i r a v t n i ( e ) r e g g n i t a c i d n i the a e g f o an e p o r n o i t a r o a t a r ns . n o i t c a A p m a t s e m i t r e g r a l v u l a e s e t a c i d n i a r o m r e n e c e t n e v e t o r e p o ra i t p m a t s e m i T . n o d e s a b al m h t i r o g u c n o c f o n o i t u c e x e e h t e z i l a i r e s o t p m a t s e m i t s e s u r a r t t n e r a s n c s n o i t

## a t s e m i T c i s a B m g n i r e d r O p

1. r e p o ) X ( m e t i \_ e t i r w a s e u s s i T n o i t c a s n a r T a : n o i t

<!-- page-break -->

- a. f I ) X ( S T \_ d a e r &gt; ) T ( S T r o f i ) X ( S T \_ e t i r w &gt; , ) T ( S T n e h t n a u o y nger n o i t c a s n a r t s a h a e r l a dy d a e r e h t a t a d m e t i o s ab t r o d n a o r l l - c a b k T and e p o e h t t c e j e r a r . n o i t

If e h t n o i t i d n o c n i p t r a ) a ( e o d s t o n exi t s , h t n e exe e t u c wr t i e i \_ e t m X ( ) f o T t e s d n a S T o t ) X ( S T \_ e t i r w (T).

2. r e p o ) X ( m e t i \_ d a e r a s e u s s i T n o i t c a s n a r T a : n o i t

n a n e h t , ) T ( S T &gt; ) X ( S T \_ e t i r w f I y d a e r l a s a h n o i t c a s n a r t r e g n u o y o t n e t t i r w o s m e t i a t a d e h t o r d n a t r o b a l l - t c e j e r d n a T k c a b t p o e h a r e . n o i t

f I S T \_ e t i r w ( ) X ≤ , ) T ( S T n e h t e t u c e x e read i \_ e t m ) X ( f o T a d n se t o t ) X ( S T \_ d a e r r a l e h t g t n e r r u c e h t d n a ) T ( S T f o r e rea S T \_ d (X)

## 5 ex n i a l p e h t b o r p lems t a h t n a c oc u c r wh n e c n e r r u c n o t n a r t sac i t n o are ex u c e ted give l p m a x e e s (J 0 2 Y L U 13 4 1 0 2 n a J / 5 1 0 2 y l u J / )

c n e r r u c n o C y h W : d e d e e n s i l o r t n o C y

## b o r P e t a d p U t s o L e h T l m e

s i h T s r u c c o n e h w o w t t s n o i t c a s n a r t a h t acc s s e the a s me d e s a b a t a e t i s m ha e v t e h i s n o i t a r e p o r r e t n i l d e v a e in a way th t a s e k a m the e u l a v of e m o s a d taba e s i m e t n i c . t c e r r o

## ) d a e R y t r i D r o ( e t a d p U y r a r o p m e T e h T P l b o r em

s r u c c o s i h T n e h w n o i t c a s n a r t e n o s e t a d p u a d e s a b a t a item d n a t n e h t e h a r t n c a s i t n o e m o s r o f s l i a f . ) 4 . 1 . 7 1 n o i t c e S e e s ( n o s a e r

e h T d e t a d p u m e t i s i ac e c d e s s by r e h t o n a s n a r t a n o i t c o f e b re t i s i a h c n e g d b k c a to i r o s t i g . e u l a v l a n i

## a m m u S t c e r r o c n I e h T r o r P y m e l b

f I e n o n o i t c a s n a r t s i a c lc g n i t a l u an g g a e r e t a g su a m m ry n o i t c n u f n o a num r e b f o s d r o c e r e l i h w r e h t o n a r t s s n o i t c a e r a i t a d p u ng e m o s f o s e h t e re , s d r o c t e h a g g re a g te n o i t c n u f may a c l e t a l u c s e m o s e u l a v be e r o f h t ey e r a e t a d p u d d n a s r e h t o a r e t f h t e a y e r d p u t a ed

## o w T - T g n i k c o L e s a h P e e u q i n h c s

i k c o L ng s i an n o i t a r e p o h c i h w s e r u c e s ) a ( pe n o i s s i m r to R d a e or (b) perm s s i n o i o t Wr t i e a a t a d m e t i r o f a t a r nsact . n o i : e l p m a x E k c o L ( . ) X a t a D m e t i X s i d e k c o l n i f l a h e b f o e h t n i t s e u q e r g . n o i t c a s n a r t g n i k c o l n U s i n a r e p o at n o i h c i h w s e v o m e r t e h se r e p m s i i s s n o f m o r the a d ta item.

k c o l n U : e l p m a x E (X). a e d a m s i X m e t i a t a D v l i a a s n a r t r e h t o l l a o t e l b a s n o i t c .

<!-- page-break -->

L r e p o c i m o t A e r a k c o l n U d n a k c o a . s n o i t

## o w T - T g n i k c o L e s a h P e o c l a i t n e s s E : s e u q i n h c m s t n e n o p

( d e r a h s ) a ( s e d o m s k c o l o w T ( e v i s u l c x e ) b ( d n a ) d a e r w t i r ) e .

d e r a h S : e d o m d e r a h s o l ck . ) X ( e r o M n a h t e n o n o i t c a s n a r t n a c p p a ly sh e r a k c o l n o X r o f . n o i t c a s n a r t r e h t o y n a y b X n o d e i l p p a e b n a c k c o l e t i r w o n t u b e u l a v s t i g n i d a e r

e v i s u l c x E : e d o m W e t i r k c o l . ) X ( y l n O e n o e t i r w k c o l n o X n a c ex t s i t a any e m i t d n a o n . X n o n o i t c a s n a r t r e h t o y n a y b d e i l p p a e b n a c k c o l d e r a h s

t a m t c i l f n o C r x i m t c i l f n o c atr x i

## o w T - T g n i k c o L e s a h P e o c l a i t n e s s E : s e u q i n h c m s t n e n o p

n i g a n a M : r e g a n a M k c o L g . s m e t i a t a d n o s k c o l

c o L k : e l b a t Lo k c r e g a n a m s e s u t i o t o t s re e h t ide i t n fy of n a r t s t c a i n o k c o l ing a t a d a t i em e h t , a t a d , m e t i k c o l e d o m d n a r e t n i o p o t e h t e n xt a d ta i e t m l c o k . d e e n O e l p m i s way o t t n e m e l p m i t s i l d e k n i l h g u o r h t s i e l b a t k c o l a .

| D I n o i t c a s n a r T   | t a D e t i a m id   | lock e d o m   | Ptr to t x e n d e t i a t a m   |
|-----------------------------|----------------------|----------------|----------------------------------|
| 1 T                         | X1                   | e R ad         | N t x e                          |

## o w T - T g n i k c o L e s a h P e o c l a i t n e s s E : s e u q i n h c m s t n e n o p

e s a b a t a D s e r i u q e r t a h t l l a t c a s n a r t n o i s d l u o h s be l e w l- r o f m . d e A n a r t s o i t c a n s i l e w l-: f i d e m r o f

- s e t i r w r o s d a e r t i e r o f e b m e t i a t a d e h t k c o l t s u m t I t i o t .
- It t s u m t o n k c o l n a a e r l a dy l e k c o d a t a d s m e t i a d n t i t s u m t o n try to l n u c o k a free m e t i a t a d .

: n o i t a r e p o k c o l e h t s m r o f r e p e d o c g n i w o l l o f e h T

<!-- formula-not-decoded -->

<!-- page-break -->

```
) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c o l e h t ; B o t o g e ; d n : n o i t a r e p o k c o l n u e h t s m r o f r e p e d o c g n i w o l l o f e h T O L K C (X) ← c o l n u * ( 0 k ) * m e t i e h t e h t g n i t i a w e r a s n o i t c a s n a r t y n a f i n o p u e k a w n o i t c a s n a r t e h t g n i t i a w e h t f o e n s n i w o l l o f e h T g : n o i t a r e p o d a e r e h t s m r o f r e p e d o c f i : B L h t " d e k c o l n u " = ) X ( K C O en e b g n i L K C O (X) ← d a e r " - ; " d e k c o l e r _ f o _ o n a s d (X) ← 1; d n e f i e s l e O L K C (X) ← d a e r " - o l c d e k " h t en e r _ f o _ o n a s d (X) ← 1 + ) X ( s d a e r _ f o _ o n l e e b e s g d n a " d e k c o l n u " = ) X ( K C O L l i t n u ( t i a w n i ; ) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c o l e h t g B o t o ; d n e n i w o l l o f e h T g : n o i t a r e p o k c o l e t i r w e h t s m r o f r e p e d o c f i : B L d e k c o l n u " = ) X ( K C O " h t en LO K C (X) ← e t i r w " - d e k c o l "; e b e s l e g n i l i t n u ( t i a w L = ) X ( K C O " d e k c o l n u " a d n ; ) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c o l e h t g B o t o ; d n e n i w o l l o f e h T g : n o i t a r e p o k c o l n u e h t s m r o f r e p e d o c f i L e t i r w " = ) X ( K C O - n e h t " d e k c o l e b g n i L K C O (X) ← o l n u " c d e k "; n a f i , s n o i t c a s n a r t e h t f o e n o p u s e k a w y
```

<!-- page-break -->

d n e

```
f i e s l e O L K C (X) ← " d a e r - o l c d e k " h t en beg n i e r _ f o _ o n a s d (X) ← s d a e r _ f o _ o n (X) -1 f i ) X ( s d a e r _ f o _ o n = n e h t 0 beg n i L ; " d e k c o l n u " = ) X ( K C O n a f i , s n o i t c a s n a r t e h t f o e n o p u e k a w y e d n
```

## k c o l e t i r w o t k c o l d a e r g n i t s i x e : e d a r g p u k c o L

d a e r a s a h i T f i - c o l d a e r o n s a h j T d n a ) X ( k - o l k c ) X ( ( i ≠ e h t ) j n

e ; d n v n o c k c o L e n o i s r d a e r t r e v n o c - e t i r w o t ) X ( k c o l - k c o l ( ) X e s l e

s k c o l n u j T l i t n u t i a w o t i T e c r o f X

## o t k c o l e t i r w g n i t s i x e : e d a r g n w o d k c o L r o l d a e c k

t i r w a s a h i T e- o l c k (X) n a e v a h n a c n o i t c a s n a r t o n * ( y ) * X n o k c o l

t r e v n o c e t i r w - o t ) X ( k c o l read- o l c k ( ) X

o w T P s e s a h : . ) g n i k n i r h S ( g n i k c o l n U ) b ( ) g n i w o r G ( g n i k c o L ) a (

g n i k c o L ) g n i w o r G ( e s a h P : A n o i t c a s n a r t s e i l p p a s k c o l d a e r ( or ) e t i r w n o d e r i s e d a d ta t a e n o s m e t i a m i t e .

r h S ( g n i k c o l n U i k n i ) g n P e s a h t i s k c o l n u n o i t c a s n a r t A : e t i a t a d d e k c o l s m . e m i t a t a e n o s

e r i u q e R me : t n r o F a n o i t c a s n a r t e s e h t o w t a h p s s e t s u m e b l a u t u m ly ex l c us v i el , y a h t t s i ,

g n i r u d g n i k c o l a h p se g n i k c o l n u e s a h p t s u m t o n t r a t s d n a i r u d ng k c o l n u ing h p ase l c o i k ng s a h p e e b t o n t s u m g n i .

## o w T -P T g n i k c o L e s a h e h c m h t i r o g l a e h T : s e u q i n

| 1 T                      | 2 T                       | Re l u s t                                    |
|--------------------------|---------------------------|-----------------------------------------------|
| Y ( k c o l _ d a e r ); | e r a o l _ d c ; ) X ( k | I 0 3 = Y ; 0 2 = X : s e u l a v l a i t i n |
| t i _ d a e r e Y ( m ); | m e t i _ d a e r (X);    | i r e s f o t l u s e R a n o i t u c e x e l |
| ( k c o l n u Y ; )      | k c o l n u ; ) X (       | b d e w o l l o f 1 T y 2 T                   |

wr X ( k c o l \_ e t i );

t i \_ d a e r e X ( m );

k c o l \_ e t i r W (Y);

X= Y , 0 5 = 0 8 .

m e t i \_ d a e r (Y);

i r e s f o t l u s e R a n o i t u c e x e l

: X =X+ ; Y

: Y =X+ ; Y

w o l l o f 2 T e b d y 1 T

; ) X ( m e t i \_ e t i r w t i \_ e t i r w e ; ) Y ( m

, 0 7 = X 0 5 = Y

( k c o l n u X ; )

k c o l n u ; ) Y (

<!-- page-break -->

## o w T - T g n i k c o L e s a h P e m h t i r o g l a e h T : s e u q i n h c

T1

2 T

Re l u s t

Y ( k c o l \_ d a e r );

X= Y ; 0 5 = 0 5

t i \_ d a e r e Y ( m );

r e s n o N a c e b e l b a z i l a i u t i e s .

o l n u c ( k Y ; )

o w t d e t a l o i v - c i l o p e s a h p y.

wr t i e o l \_ c ; ) X ( k

t i \_ d a e r e X ( m );

: X =X+ ; Y

t i \_ e t i r w e m (X);

o l n u c ( k X ; )

## o w T -P n i k c o L e s a h T g e m h t i r o g l a e h T : s e u q i n h c

## ' T 1 T'2

( k c o l \_ d a e r ) Y ;

; ) X ( k c o l \_ d a e r 1 T a t w o l l o f 2 T d n woe s a h p

e r a t i \_ d e Y ( m );

; ) X ( m e t i \_ d a e r c i l o p y e h t t u b y o t t c e j b u s e r a

wr X ( k c o l \_ e t i );

o l \_ e t i r W c k (Y);

de i h w , k c o l d a c m h u e b t s

o l n u c ( k Y ; )

k c o l n u ; ) X (

e d a t l w . h t i

e r a t i \_ d e X ( m );

e r a m e t i \_ d (Y);

Y + X = : X ;

: Y =X+ ; Y

o l \_ d a e r c ( k ) X ;

t i \_ d a e r e X ( m );

o l n u c ( k X ; )

t i r w e o l \_ c ; ) Y ( k

t i \_ d a e r e Y ( m );

: Y =X+ ; Y

t i \_ e t i r w e m (Y);

o l n u c ( k Y ; )

wr t i \_ e t i e m (X);

o l n u c ( k X ; )

t i r w e t i \_ e ; ) Y ( m

k c o l n u ; ) Y (

<!-- page-break -->

o w T - c i l o p e s a h p y . e v i t a v r e s n o C ) b ( d n a c i s a B ) a ( s m h t i r o g l a g n i k c o l o w t s e t a r e n e g

s n o C e v r a : e v i t s t n e v e r P k c o l d a e d by i k c o l ng all d e r i s e d a t a d s m e t i b f e e r o n a r t sa t c o i n e b g x e s n i c e . n o i t u

: c i s a B n o i t c a s n a r T c o l ks a t a d s m e t i l a t n e m e r c n i l . y s i h T y a m c e s u a e d a k c o l d h c i h w i s d a e . h t i w t l

: t c i r t S A e r o m r e t c i r t s n o i s r e v f o c i s a B al m h t i r o g e r e h w g n i k c o l n u s i d e m r o f r e p f a t r e a n o i t c a s n a r t a n i m r e t t s e s t i m m o c ( r o s t r o b a d n a rolled-) k c a b . s i h T s i e h t t s o m m o c m n o ly u d e s o w t - l a g n i k c o l e s a h p g . m h t i r o

## . 6 t i l i b i z i l a i r e S s i t a h W y f i t s u J ? y t i l i b a z i a i r e s n a c w o H ? y ? r e w s n a r u o y

1 c e D ( / 1 y l u J 13 4 1 0 2 N A J / )

## f o y t i l i b a z i l a i r e S s e l u d e h c S

f I o n g n i v a e l r e t n i f o s n o i t a r e p o s i , d e t t i m r e p e r e h t e r a n o ly o w t e l b i s s o p a r r a n e g m t n e r o f tr s n a a 2 T d n a 1 T s n o i t c .

e t u c e x E l l a e h t s n o i t a r e p o f o 1 T n i ( n e u q e s c ) e f d e w o l l o by l l a t e h r e p o i t a s n o f o 2 T n i ( u q e s ence).

b d e w o l l o f ) e c n e u q e s n i ( 2 T f o s n o i t a r e p o e h t l l a e t u c e x E y 1 T f o s n o i t a r e p o e h t l l a

A u d e h c s le S is se l a i r , f i r o f e v e ry t i t c a s n a r n o T l l a e h t t a r e p o i s n o of T e r a ex d e t u c e l e v i t u c e s n o c y . e l u d e h c s e h t n i

A u d e h c s le S of n s n a r t a s n o i t c s i z i l a i r e s e l b a f i t i s i t n e l a v i u q e o t o s me r e s ial s e l u d e h c f o h t e e m a s n . s n o i t c a s n a r t

## . 7 s e t o N t r o h s a e t i r W

c e D ( n a J / 1 1 )

## P 2 ) a L L : k c o

i k c o L ng s i an n o i t a r e p o h c i h w s e r u c e s ) a ( pe n o i s s i m r to R d a e or (b) perm s s i n o i o t Wr t i e a a t a d m e t i r o f a n a r t s c a ti . n o a x E : e l p m k c o L ) X ( . a t a D m e t i X s i d e k c o l n i a h e b lf f o t e h n i t s e u q e r g . n o i t c a s n a r t g n i k c o l n U s i n a a r e p o t n o i h c i h w s e v o m e r t e h se r e p m s i i s s n o f m o r the a d ta item.

<!-- page-break -->

k c o l n U : e l p m a x E (X). a e d a m s i X m e t i a t a D v l i a a s n a r t r e h t o l l a o t e l b a s n o i t c .

L e r a k c o l n U d n a k c o e p o c i m o t A a r . s n o i t

v i s u l c x e ) b ( d n a ) d a e r ( d e r a h s ) a ( s e d o m s k c o l o w T e (w t i r ) e .

d e r a h S : e d o m d e r a h s o l ck . ) X ( e r o M n a h t e n o n o i t c a s n a r t n a c p p a ly sh e r a k c o l n o X r o f s t i g n i d a e r . n o i t c a s n a r t r e h t o y n a y b X n o d e i l p p a e b n a c k c o l e t i r w o n t u b e u l a v

s u l c x E e v i : e d o m e t i r W k c o l . ) X ( y l n O e n o e t i r w k c o l n o X n a c ex t s i t a any e m i t d n a o n d e r a h s b d e i l p p a e b n a c k c o l y . X n o n o i t c a s n a r t r e h t o y n a

a n a M : r e g a n a M k c o L g n i g . s m e t i a t a d n o s k c o l

k c o L t : e l b a Lo r e g a n a m k c s e s u t i o t e r o t s e h t i t n e d i fy f o tr n o i t c a s n a k c o l ing a a t a d e t i m, t e h a d t , m e t i a k c o l e d o m d n a o p i r e t n o t t e h e n xt a t a d it m e c o l k . d e e n O e l p m i s y a w o t p m i lem n e t a l k c o t s i l d e k n i l h g u o r h t s i e l b a t .

| t a D D I n o i t c a s n a r T e t i a m id   | lock e d o m   | Ptr to t x e n d e t i a t a m   |         |
|------------------------------------------------|----------------|----------------------------------|---------|
| 1 T                                            | X1             | e R ad                           | N t x e |

## o w T - T g n i k c o L e s a h P e i n h c o c l a i t n e s s E : s e u q m s t n e n o p

n i w o l l o f e h T g : n o i t a r e p o k c o l e h t s m r o f r e p e d o c

B: f i L ) * d e k c o l n u s i m e t i * ( 0 = ) X ( K C O

<!-- formula-not-decoded -->

n i g e b e s l e

<!-- formula-not-decoded -->

) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c o l e h t ;

Y ( );

B o t o g

e ; d n

Dea d L : s k c o

## De o l d a ck

T'1 T'2

( k c o l \_ d a e r ) Y ;

1 T a w o l l o f d i d 2 T d n two- h p a e s e r a t i \_ d e m

<!-- page-break -->

```
k c o l d a e d e r a y e h t t u b y c i l o p X ( k c o l _ d a e r ) ; t i _ d a e r e Y ( m ); wr X ( k c o l _ e t i ) ; ( a w s t i f ) X r o wr Y ( k c o l _ e t i ) ; w ( a s t i f ) Y r o
```

T d n a 1 ' T ( k c o l d a e D ' ) 2

## v e r p k c o l d a e D ent n o i

A n o i t c a s n a r t s k c o l l l a a t a d s m e t i t i s r e f e r o t e r o f e b t i be s n i g ex u c e i t . n o s i h T y a w f o g n i k c o l s t n e v e r p l d a e d c o k e c n i s a n a r t s n o i t c a e n v r e s t i a w r o f a a t a d i e t m. e h T r e s n o c v e v i t a t o w - n i k c o l e s a h p g a o r p p a s i h t s e s u c . h

## n o i t u l o s e r d n a n o i t c e t e d k c o l d a e D

n I s i h t , h c a o r p p a l d a e d o s k c e r a d e w o l l a o t a h p p e . n e h T r e l u d e h c s s n i a t n i a m a t i a w - r o f - h p a r g r o f e d t i t c e ng c . e l c y f I a c e l c y , s t s i x e n e h t e n o n o i t c a s n a r t d e v l o v n i in e h t c c y le s i d e t c e l e s d e l l o r d n a ) m i t c i v ( -ba . k c

A t i a w -for- h p a r g s i cr a e t d e g n i s u the k c o l tabl . e s A n o o s s a a t s n a r ac i t n o s i l b , d e k c o it is

d e d d a o t e h t . h p a r g n e h W a n i a h c : e k i l i T t i a w s r o f j T s t i a w r o f k T i a w ts r o f Ti or Tj , s r u c c o c a s e t a e r c s i h t n e h t y . e l c n o i t c a s n a r t e h t f o e n O c e h t f o y d e l l o r d n a d e t c e l e s s i e l c . k c a b

## e c n a d i o v a k c o l d a e D

T e r e h e r a a m ny v o i t a i r a ns f o o w t -ph e s a i k c o l ng al r o g i h t m. e m o S d i o v a k c o l d a e d by o n t

g n i t t e l e h t c e l c y o t co e l p m t . e t a h T s i s a n o o s s a e h t g l a o h t i r m di c s v o s r e t a h t b o l k c ing a n o i t c a s n a r t s i e k i l ly o t e t a e r c a c , e l c y t i s l l o r a b ck e h t . n o i t c a s n a r t d n u o W - t i a W d n a Wa t i - g n i l l o r y b s k c o l d a e d d i o v a o t s p m a t s e m i t e s u s m h t i r o g l a e i D - m i t c i v k c a b

## n o i t a v r a t S

n o i t a v r a t S s r u c c o wh n e a r a l u c i t r a p n o i t c a s n a r t t n e t s i s n o c ly s t i a w r o t s e r a d e t r d n a e n v r e

s t e g a ch e c n a o t d e e c o r p . . r e h t r u f n I d n u o W - t i a W e m e h c s a u o y n r e g a s n a r t n o i t c y a m n I a k c o l d a e d e l b i s s o p s i t i n o i t u l o s e r t a h t e h t e m a s tra n o i t c a s n may t n e t s i s n o c ly be l e s e d e t c s a vic i t m d n a d e l l o r - . k c a b s i h T n o i t a t i m i l s i t n e r e h n i n i l l a i r o i r p ty a b s d e l u d e h c s i g n mech n a is s m alwa s y ) d e t r o b a ( d e d n u o w e b b r e d l o g n i n n u r g n o l a y m h c i h w n o i t c a s n a r t a y . n o i t a v r a t s e t a e r c



- R A I : S E e h T M I F A do s e t o n e t i r w r e v o s t i M I F B u b t re o c r e d d at r e h t o n a pl c a e n o t e h i d . k s , s u h T t a an y e m i t a a d ta m e t i s a h M I F A d n a BF M I w o d a h S ( copy of h t e data i ) m e t at t o w f f i d e e r t n pl e c a s h t n o e . k s i d

: Y d n a X

e i p o c w o d a h S s m e t i a t a d f o s

X` Y d n a ` :

s m e t i a t a d f o s e i p o c t n e r r u C

<!-- page-break -->

o T e g a n a m s s e c c a f o data s m e t i by c n o c u t n e r r tr s n o i t c a s n a o w t t c e r i d o e i r s r u c ( re t n d n a sh ) w o d a e r a s u e . d . w o l e b d e t a r t s u l l i s i t n e m e g n a r r a y r o t c e r i d e h T m e t i a t a d a s i e g a p a e r e H



## 8 s e g a t n a v d a s i d s t i d n a l o c o t o r P g n i k c o L e s a h P o w t n i a l p x E ?

## N A J / C E D ( 3 1 0 2 4 1 0 2 n a J / )

i k c o L ng s i an n o i t a r e p o h c i h w s e r u c e s ) a ( pe n o i s s i m r to R d a e or (b) perm s s i n o i o t Wr t i a e a t a d m e t i r o f a n a r t s c a ti . n o : e l p m a x E k c o L ) X ( . a t a D m e t i X s i d e k c o l n i a h e b lf f o t e h n i t s e u q e r g r t a . n o i t c a s n

g n i k c o l n U s i n a a r e p o t n o i h c i h w s e v o m e r t e h se r e p m s i i s s n o f m o r the a d ta item.

o l n U : e l p m a x E c k (X). a e d a m s i X m e t i a t a D v l i a a s n a r t r e h t o l l a o t e l b a s n o i t c .

## o w T - T g n i k c o L e s a h P e o c l a i t n e s s E : s e u q i n h c m s t n e n o p

: n o i t a r e p o k c o l e h t s m r o f r e p e d o c g n i w o l l o f e h T

B: f i L ) * d e k c o l n u s i m e t i * ( 0 = ) X ( K C O

) n o i t c a s n a r t e h t p u s e k a w r e g a n a m k c o l e h t ;

n e h t L X ( K C O ) ← l * ( 1 o ) * m e t i e h t k c n i g e b e s l e d n a ) 0 = ) X ( k c o l l i t n u ( t i a w B o t o g e ; d n

<!-- page-break -->

## 9 i r e d r o p m a t s e m i T n i a l p x E n a g l m h t i r o g .

( 0 2 N A J 13)

- ) a i r e d r o p m a t s e m i T n a g l m h t i r o g .

A l a c i n o t o n o m ly s a e r c n i i g n e l b a i r a v n i ( te ) r e g g n i t a c i d n i the a e g f o an e p o r n o i t a r o a t a r ns n o i t c a

.

A p m a t s e m i t r e g r a l v u l a e s e t a c i d n i a r o m r e n e c e t n e v e t o r e p o ra i t d e s a b p m a t s e m i T . n o al m h t i r o g u c n o c f o n o i t u c e x e e h t e z i l a i r e s o t p m a t s e m i t s e s u r a s n a r t t n e r c s n o i t

## a t s e m i T c i s a B m g n i r e d r O p

1. r T : n o i t a r e p o ) X ( m e t i \_ e t i r w a s e u s s i T n o i t c a s n a

f I ) X ( S T \_ d a e r &gt; ) T ( S T r o f i ) X ( S T \_ e t i r w &gt; , ) T ( S T n e h t n a u o y nger n o i t c a s n a r t s a h a e r l a dy d a e r e h t a t a d m e t i o s ab t r o d n a r l l o - c a b k T and e p o e h t t c e j e r a r . n o i t

f I e h t n o i t i d n o c n i p t r a ) a ( e o d s t o n ex s i t, h t n e exe e t u c wr t i e i \_ e t m X ( ) f o T X ( S T \_ e t i r w t e s d n a ) o t S T (T).

2. r e p o ) X ( m e t i \_ d a e r a s e u s s i T n o i t c a s n a r T a : n o i t

n a n e h t , ) T ( S T &gt; ) X ( S T \_ e t i r w f I y d a e r l a s a h n o i t c a s n a r t r e g n u o y o t n e t t i r w d n a t r o b a o s m e t i a t a d e h t l l o r - t c e j e r d n a T k c a b t p o e h a r e . n o i t

f I t i r w S T \_ e ( ) X ≤ , ) T ( S T n e h t e t u c e x e read i \_ e t m ) X ( f o T a d n se r a l e h t o t ) X ( S T \_ d a e r t g r e r r u c e h t d n a ) T ( S T f o e t n rea S T \_ d (X

## . 0 1 m h t i r o g l A S E I R A

( y l u J 3 1 0 2 )

r e v o c e R S E I R A e h T y : n o d e s a b s i m h t i r o g l A

1. A W L ) g n i g g o L d a e h A e t i r W (
2. o t s i h g n i t a e p e R r : o d e r g n i r u d y AR E I a t a d e h t f o s n o i t c a l l a e c a r t e r l l i w S b e s a sy h s a r c e h t n e h w e t a t s e s a b a t a d e h t t c u r t s n o c e r o t h s a r c e h t o t r o i r p m e t s o c c urre . d
3. : o d n u g n i r u d s e g n a h c g n i g g o L e h t g n i t a e p e r m o r f S E I R A t n e v e r p l l i w t I

<!-- page-break -->

n i r u d s r u c c o e r u l i a f a f i s n o i t a r e p o o d n u d e t e l p m o c g r e v o c e r y a s e s u a c h c i h w , r e v o c e r e h t f o t r a t s e r y . s s e c o r p

R A e h T I r e v o c e r S E y : s p e t s e e r h t f o s t s i s n o c m h t i r o g l a

1. s i s y l a n A t r i d e h t s e i f i t n e d i p e t s : y f o t e s e h t d n a r e f f u b e h t n i s e g a p ) d e t a d p u ( c f o e m i t e h t t a e v i t c a s n o i t c a s n a r t a r . h s p p a e h T r e t a i r p o o l e h t n i t n i o p g h w ere s i t r a t s o t s i o d e r a d o s l ete . d e n i m r
2. d e R o: a s s e c e n r . d e i l p p a e r a s n o i t a r e p o o d e r y
3. o d n U t a e v i t c a s n o i t c a s n a r t f o s n o i t a r e p o e h t d n a s d r a w k c a b d e n n a c s s i g o l : e h t o e s r e v e r n i e n o d n u e r a h s a r c f o e m i t rd r e .

## u q e S g o L d n a g o L e h T e u N e c n m ) N S L ( r e b

) d ( , t r o b a n o i t c a s n a r t ) c ( , t i m m o c n o i t c a s n a r t ) b ( , e t a d p u a t a d ) a ( r o f n e t t i r w s i d r o c e r g o l A a s n a r t ) e ( d n a , o d n u c n o i t e . d n I n i t a s n e p m o c a o d n u f o e s a c e h t n g o l g . n e t t i r w s i d r o c e r A e u q i n u L r e v e h t i w d e t a i c o s s a s i N S y d r o c e r g o l . LS l l a c i n o t o n o m s e s a e r c n i N y d n a s e t a c i d n i o l e h t f o s s e r d d a k s i d e h t g s i t i d r o c e r d e t a i c o s s a w . h t i I e h t s e r o t s e g a p a t a d h c a e , n o i t i d d a n L n i d n o p s e r r o c d r o c e r g o l t s e t a l e h t f o N S g n a h c a o t g a p t a h t r o f e g . e ) a ( s e r o t s d r o c e r g o l A t a h t f o N S L s u o i v e r p e h t e h t ) b ( , n o i t c a s n a r t t ) c ( d n a , D I n o i t c a s n a r t e h t y d r o c e r g o l f o e p .

## o l A g o c e r r r o t s d e : s

- . 1 : n o i t c a s n a r t t a h t f o N S L s u o i v e r P l e h t s k n i l t I o d r o c e r g o i t c a s n a r t h c a e f on. I e k i l s i t a s n a r t e m a s e h t f o d r o c e r s u o i v e r p e h t o t s t n i o p r e t n i o p k c a b a . n o i t c
- . 2 n a r T D I n o i t c a s
3. Ty . d r o c e r g o l f o e p
4. e g a P I m e t i e h t s e d u l c n i t a h t e g a p e h t r o f D
5. n e L g m e t i d e t a d p u e h t f o h t
6. I a p e h t f o g n i n n i g e b e h t m o r f t e s f f o s t ge
7. m e t i e h t f o M I F B

<!-- page-break -->

8. F A I m e t i e h t f o M

: g n i w o l l o f e h t s e o d g n i t n i o p k c e h c A

- . 1 s e t i r W a k c e h c \_ n i g e b t n i o p h t n i d r o c e r e g o l
- . 2 s e t i r W a n t n i o p k c e h c \_ d n e h t n i d r o c e r e o l g. s t n e t n o c e h t d r o c e r s i h t h t i W f o s n a r t a n o i t c t r i d d n a e l b a t y a p g . g o l e h t f o d n e e h t o t d e d n e p p a e r a e l b a t e
- . 3 e h t s e t i r W L e h t f o N S b t n i o p k c e h c \_ n i g e i c e p s a o t d r o c e r a l f . e l i c e p s s i h T i f l a il e is e v o c e r g n i r u d d e s s e c c a r k c e h c t s a l e h t e t a c o l o t y p . n o i t a m r o f n i t n i o